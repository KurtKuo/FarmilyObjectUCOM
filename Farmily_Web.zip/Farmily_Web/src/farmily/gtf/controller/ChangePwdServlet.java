package farmily.gtf.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;

/**
 * Servlet implementation class ChangePwdServlet
 */
@WebServlet("/member/update/changepwd.do")
public class ChangePwdServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ChangePwdServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		HttpSession session	= request.getSession();
		//import javax.servlet.http.HttpSession;
		List<String> errorList = new ArrayList<>();
		//import java.util.List; import java.util.ArrayList;
		String emailCaptcha = (String) session.getAttribute("emailCaptcha");
		//1.利用 request 讀取前端 Form Data 的name值 被指派給相對應的參數
				//id,password,name,gender,birthday,email,address,phone,captcha,subscribe
				String newPassword = request.getParameter("newPassword");
				String email = request.getParameter("email");
				String captcha = request.getParameter("inputCaptcha");
		
		if(emailCaptcha==null) {
			errorList.add("驗證碼無效，等待時間過長！");
			request.getRequestDispatcher("/forgotPwd.jsp");
			return;
		}
		if(newPassword==null|| newPassword.length()>Customer.PWD_MAX_LENGTH || newPassword.length()<Customer.PWD_MIN_LENGTH){
			errorList.add(String.format("新密碼輸入不正確，請輸入%d~%d字，謝謝",Customer.PWD_MIN_LENGTH, Customer.PWD_MAX_LENGTH));
		}
		if(captcha==null || captcha.length()==0) {
			errorList.add("請輸入驗證碼，謝謝");		
		}else {
			//字串與字串相比並且忽略大小寫equalsIgnoreCase
			if(!captcha.equals(emailCaptcha)) {
				errorList.add("驗證碼不正確，謝謝");
			}	
		}//session.removeAttribute("emailCaptcha");//未來在刪除
		

		//2.檢查無誤才呼叫商業邏輯
		if(errorList.isEmpty()) {
			CustomerService cservice = new CustomerService();
			try {
				
			Customer c = cservice.useEmailLogin(email);
			c.setPassWord(newPassword);
			cservice.forgetPassword(c);
			
				System.out.println(c);
				//3.1 forward至 成功註冊畫面
				session.setAttribute("member",c);
				RequestDispatcher dispatcher = request.getRequestDispatcher("/index.jsp");
				//調度員 import javax.servlet.RequestDispatcher;
				dispatcher.forward(request, response);
				//交棒給jsp
				return;
			} catch (GTFException e) {
				this.log(e.getMessage(),e);//寫給admin,tester 給管理者or開發人員
				errorList.add(e.getMessage()); //輸出給網頁上
			} catch(GTFDataInvalidException e) {
				errorList.add(e.getMessage()); //輸出給網頁上
			}catch(Exception e) {
				this.log("會員註冊發生非預期錯誤",e);//寫給admin,tester 給管理者or開發人員
				errorList.add(e.getMessage()+"，請聯絡系統管理員"); //輸出給網頁上
			}	
		}
		System.out.println(errorList); //Console
		
		//3.2 資料檢查有錯或商業邏輯執行失敗，切換成/update.jsp
		RequestDispatcher dispatcher = request.getRequestDispatcher("/member/update/changePwd.jsp");
		request.setAttribute("errors", errorList);
		dispatcher.forward(request, response);
		
		}

	}
