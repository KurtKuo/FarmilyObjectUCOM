package farmily.gtf.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;

/**
 * Servlet implementation class UpdateServlet
 */
@WebServlet(name="UpdateServlet",urlPatterns="/member/update/update.do")
public class UpdateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;     
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {	
		
	HttpSession session	= request.getSession();
	//import javax.servlet.http.HttpSession;
	List<String> errorList = new ArrayList<>();
	//import java.util.List; import java.util.ArrayList;
	Customer member = (Customer) session.getAttribute("member");
	//必須要登入才能修改
	if(member==null) {
		errorList.add("請重新登入，謝謝");
		request.getRequestDispatcher("/member/login/login.jsp");
		return;
	}
	request.setCharacterEncoding("utf-8");
	//1.利用 request 讀取前端 Form Data 的name值 被指派給相對應的參數
			//id,password,name,gender,birthday,email,address,phone,captcha,subscribe
			String id = request.getParameter("id");
			String pwd = request.getParameter("password");
			String changePwd = request.getParameter("changePwd");
			String newpassword = request.getParameter("newpassword");
			String name = request.getParameter("name");
			String gender = request.getParameter("gender");
			String birthday = request.getParameter("birthday");
			String email = request.getParameter("email");
			//非必要欄位
			String address = request.getParameter("address");
			//必要欄位
			String phone = request.getParameter("phone");
			String captcha = request.getParameter("captcha");
			//非必要欄位
			String subscribe = request.getParameter("subscribe");
		//這裡優先檢查是否與登入資料相同
		//檢查必要欄位
	if(id==null || !id.equals(member.getId())) {
		 errorList.add("帳號不得更改，謝謝");
	}
	if(pwd==null || !pwd.equals(member.getPassWord())) {
		errorList.add("原密碼錯誤，謝謝");
	}
	//if(checkblx觸發才執行)
	if(changePwd!=null) {
		if(newpassword==null || newpassword.length()>Customer.PWD_MAX_LENGTH || newpassword.length()<Customer.PWD_MIN_LENGTH) {
			errorList.add(String.format("新密碼輸入不正確，請輸入%d~%d字，謝謝",Customer.PWD_MIN_LENGTH, Customer.PWD_MAX_LENGTH));
		}else if(newpassword.equals(pwd)) {
			errorList.add("新密碼與原密碼相同，謝謝");
		}
	}
	if(name==null || name.length()==0) {
		errorList.add("請輸入姓名，謝謝");
	}
	if(gender==null || gender.length()!=1) {
		errorList.add("請選擇性別，謝謝");
	}		
	if(phone==null || phone.length()==0) {
		errorList.add("請選擇輸入手機，謝謝");
	}
	if(birthday==null || birthday.length()!=10) {//iso-8601
		errorList.add("請選擇生日，謝謝");
	}		
	if(email==null || email.length()==0) {
		errorList.add("請輸入email，謝謝");
	}		
	if(captcha==null || captcha.length()==0) {
		errorList.add("請輸入驗證碼，謝謝");		
	}else {
		String oldcaptcha= (String) session.getAttribute("captcha");
		//字串與字串相比並且忽略大小寫equalsIgnoreCase
		if(!captcha.equals(oldcaptcha)) {
			errorList.add("驗證碼不正確，謝謝");
		}	
	}
	session.removeAttribute("captcha");
	//2.檢查無誤才呼叫商業邏輯
	if(errorList.isEmpty()) {
		try {
		Customer c = new Customer();
				c.setId(member.getId());
				if(changePwd==null) {
					c.setPassWord(member.getPassWord());
				}else { //修改密碼
					c.setPassWord(newpassword); //新密碼設定至Customer物件中
					pwd = newpassword; //新密碼值指派給舊密碼之後登入用
				}
				c.setName(name);
				c.setGender(gender.charAt(0));
				c.setPhone(phone);
				c.setBirthday(birthday);
				c.setEmail(email);
				c.setAddress(address);
				c.setSubscribed(subscribe!=null); //如果有給值為true 沒給值為null 即為false
		
		CustomerService service = new CustomerService();
		//try {
			service.update(c); //會員修改
			Customer newMember = service.login(member.getId(), pwd);
			
			session.setAttribute("member",newMember); //將新的資料傳自前端 並建立物件session
			
			request.setAttribute("customer", c);//註冊成功但為登入進入 成功畫面
			//session.setAttribute("member",c);//註冊成功且登入
			System.out.println(c);
			//3.1 forward至 成功註冊畫面	
			RequestDispatcher dispatcher = request.getRequestDispatcher("/member/signup/signupTransfer.jsp");
			//調度員 import javax.servlet.RequestDispatcher;
			dispatcher.forward(request, response);
			//交棒給jsp
			return;
		} catch (GTFException e) {
			this.log(e.getMessage(),e);//寫給admin,tester 給管理者or開發人員
			errorList.add(e.getMessage()); //輸出給網頁上
		} catch(GTFDataInvalidException e) {
			errorList.add(e.getMessage()); //輸出給網頁上
		}catch(Exception e) {
			this.log("會員註冊發生非預期錯誤",e);//寫給admin,tester 給管理者or開發人員
			errorList.add(e.getMessage()+"，請聯絡系統管理員"); //輸出給網頁上
		}	
	}
	System.out.println(errorList); //Console
	
	//3.2 資料檢查有錯或商業邏輯執行失敗，切換成/update.jsp
	RequestDispatcher dispatcher = request.getRequestDispatcher("/member/update/update.jsp");
	request.setAttribute("errors", errorList);
	dispatcher.forward(request, response);
	
	}

}
