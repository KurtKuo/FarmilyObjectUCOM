package farmily.gtf.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;
import farmily.gtf.service.MailService;

/**
 * Servlet implementation class RegisterServlet
 */
//@WebServlet(name="LoginServlet",urlPatterns="/member/login/login.do")
//完整網址：http://localhost:8080/farmily/member/signup/registered.do
@WebServlet(name="RegisterServlet",urlPatterns="/member/signup/registered.do")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RegisterServlet() {
        super();
        // TODO Auto-generated constructor stub
        //預設建構子，無參數建構子
    }

	/** 若要改成doGet注意拼寫
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    @Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	HttpSession session =request.getSession();
    	
    	List<String> errorList = new ArrayList<>();//集合 List裡面的子類別ArrayList 清單 <-語法
		request.setCharacterEncoding("utf-8");//當FormData有中文時 name address

		// 1.處理request中的Form Data讀取並檢查之
		//id,password,name,gender,birthday,email,address,phone,captcha,subscribe
		String id = request.getParameter("id");
		String password = request.getParameter("password");
		String name = request.getParameter("name");
		String gender = request.getParameter("gender");
		String birthday = request.getParameter("birthday");
		String email = request.getParameter("email");
		//非必要欄位
		String address = request.getParameter("address");
		//必要欄位
		String phone = request.getParameter("phone");
		String captcha = request.getParameter("captcha");
		//非必要欄位
		String subscribe = request.getParameter("subscribe");
		
		//emailSend郵件檢查
		String emailSend = request.getParameter("emailSend");
		
		
		
		//必要欄位簡單檢查在呼叫 商業邏輯 有錯誤就列入errorList 錯誤清單
		if(id==null||id.length()==0) {
			errorList.add("請輸入帳號，謝謝");
			}
		if(password==null||password.length()<Customer.PWD_MIN_LENGTH||password.length()>Customer.PWD_MAX_LENGTH) { 
			// 判斷兩個密碼一致 <||!password1.equals(password2) 或者不相等 >
			//	if(password==null||password.length()<8||password.length()>20) { 
			errorList.add(
					String.format("請輸入密碼，長度%d~%d，謝謝", Customer.PWD_MIN_LENGTH,Customer.PWD_MAX_LENGTH)
					);
			}
		if(name==null||name.length()<Customer.NAME_MIN_LENGTH||name.length()>Customer.NAME_MAX_LENGTH) {
			errorList.add(
					String.format("請輸入名字，長度%d~%d，謝謝", Customer.NAME_MIN_LENGTH,Customer.NAME_MAX_LENGTH)
					);
			}
		if(gender==null||gender.length()==0) {
			errorList.add("請選擇性別，謝謝");
		}
		if(birthday==null||birthday.length()!=10) {		//符合iso-8601		
			errorList.add("請選擇生日，謝謝");
		}
		if(email==null||email.length()==0) {
			errorList.add("請輸入email，謝謝");
		}
		if(phone==null||phone.length()==0) {
			errorList.add("請輸入mobile，謝謝");
		}
		if(captcha==null||captcha.length()==0) {
			errorList.add("請輸入captcha，謝謝");
		}else {
			//TODO: 15章
			String oldCaptcha = (String)session.getAttribute("captcha");
			//要記得轉型String
			if(!(captcha).equals(oldCaptcha)) //大小寫都要對
			{//if(!(captcha).equalsIgnoreCase(oldCaptcha))//大小寫沒關係
				errorList.add("驗證碼不正確，謝謝");
			}	
		}
		session.removeAttribute("captcha");
		
			if(emailSend!=null) {
				MailService.sendHelloMailWithLogoTHANK(emailSend);
				System.out.println("已將"+emailSend+"傳送！");
				request.setAttribute("emailSend", emailSend);
				request.getRequestDispatcher("/member/signup/signupEmailLogin.jsp").forward(request, response);
				return;
			}

		//2.若檢查無誤，才呼叫商業邏輯
		if(errorList.isEmpty()) { //錯誤清單是空白的
			Customer c =new Customer();//import
		try {	
			c.setId(id);
			c.setPassWord(password);
			c.setName(name);
			c.setGender(gender.charAt(0));//轉型
			c.setBirthday(birthday);
			c.setEmail(email);
			c.setAddress(address);
			c.setPhone(phone);
			c.setSubscribed(subscribe!=null);
			/*血型
			  if(bloodType!=null && bloodType.length()>0)
			  c.setBloodType(BloodType.valueOf(bloodType));
			  }
			  */
			 CustomerService service = new CustomerService();
			 //呼叫商業邏輯
			// try {搬到 c.setId(id); 上方
				service.register(c);
				
				//3.1產生註冊成功的回應
				RequestDispatcher dispatcher =request.getRequestDispatcher("/member/signup/signupTransfer.jsp");
				//request 生命週期太短要改為 session類別
				//session.setAttribute("member", c);
				//註冊不需要使用session只是要帶畫面成功與否
				
				
				//因為要跳轉回去給email畫面 跳轉完直接登入
				session.setAttribute("member",c);
				//request.setAttribute("customer", c);
				
				dispatcher.forward(request, response);			
				return;
				
			} catch (GTFException e) {
				this.log(e.getMessage(),e);//寫給admin,tester 給管理者or開發人員
				errorList.add(e.getMessage()); //輸出給網頁上
			} catch(GTFDataInvalidException e) {
				errorList.add(e.getMessage()); //輸出給網頁上
			}catch(Exception e) {
				this.log("會員註冊發生非預期錯誤",e);//寫給admin,tester 給管理者or開發人員
				errorList.add(e.getMessage()+"，請聯絡系統管理員"); //輸出給網頁上
			}
		}//if(errorList.isEmpty())
		
			//3.2產生註冊失敗的回應
		RequestDispatcher dispatcher = request.getRequestDispatcher("/member/signup/registered.jsp");
		request.setAttribute("errors", errorList);//將錯誤清單傳過去
		dispatcher.forward(request, response);
			
	}

}
