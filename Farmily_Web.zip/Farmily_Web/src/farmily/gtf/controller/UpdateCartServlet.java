package farmily.gtf.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import farmily.gtf.entity.CartItem;
import farmily.gtf.entity.ShoppingCart;
import farmily.gtf.exception.GTFDataInvalidException;

/**
 * Servlet implementation class UpdateCartServlet
 */
@WebServlet("/member/cart/update_cart.do")
public class UpdateCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateCartServlet() {
        super();
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		//1,取得session
		HttpSession session= request.getSession();
		ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
		
		//2.呼叫商業邏輯
		if(cart!=null && cart.size()>0) {
			for(CartItem cartItem:cart.getCartItemSet()) {
				String quantity = request.getParameter("quantity"+cartItem.hashCode());
				String delete = request.getParameter("delete"+cartItem.hashCode());
				System.out.println(cartItem.getProduct().getName() + "修改為" + quantity);
				System.out.println(cartItem.getProduct().getName() +  (delete==null?"不":"要") + "刪除");
				
				if(delete==null&&quantity!=null&&quantity.matches("\\d+")) {			
					try {
						int qty = Integer.parseInt(quantity);
						if(qty>0) {
							cart.update(cartItem, qty);
						}else{
							cart.remove(cartItem);
						}
					}catch(GTFDataInvalidException e){
						System.out.println(e.getMessage() + cartItem);
					}				
				}else if(delete!=null) {
					cart.remove(cartItem);
				}		
			}		
		}
		
		//3.redirect去checkout 或是 回cart.jsp
		String checkout = request.getParameter("checkout");
		System.out.println(checkout);
		if(checkout!=null) {
			response.sendRedirect(request.getContextPath()+"/member/cart/check_out.jsp");
		}else {
			response.sendRedirect("cart.jsp");	
		}		
	}

}
