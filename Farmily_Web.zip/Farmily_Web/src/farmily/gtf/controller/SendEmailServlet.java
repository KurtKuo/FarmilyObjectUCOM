package farmily.gtf.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;
import farmily.gtf.service.MailService;

/**
 * Servlet implementation class sendEmailServlet
 */
@WebServlet("/member/update/sendEmail.do")
public class SendEmailServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public SendEmailServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
			request.setCharacterEncoding("utf-8");//當FormData有中文時 name address
	    	List<String> errorList = new ArrayList<>();//集合 List裡面的子類別ArrayList 清單 <-語法
			
		
			//emailSend郵件檢查
			String sendPWDEmail = request.getParameter("sendPWDEmail");
			
			
				if(sendPWDEmail==null||sendPWDEmail.length()==0) {
					errorList.add("請輸入信箱，謝謝");
				}
			System.out.println("您輸入的Email為："+sendPWDEmail);
			
			//2.若檢查無誤，才呼叫商業邏輯
			if(errorList.isEmpty()) { //錯誤清單是空白的
				try {	
					Random random = new Random();
					int len =6;
					String emailCaptcha ="";
					for(int i=0;i<len;i++) {
						int data = random.nextInt(36);//0~36不含36 之間的一個整數
						char ch = (char)(data<10?(data+'0'):(data-10+'A'));//小於10等於data //大於10 減掉10轉為A~Z
						emailCaptcha +=ch;
					}
					HttpSession emailSession = request.getSession(true);//產生emailCaptchamㄥˋ
					emailSession.setAttribute("emailCaptcha", emailCaptcha);
					System.out.println("您得到的的email為："+emailCaptcha);
					MailService.sendHelloMailWithLogo(sendPWDEmail,emailCaptcha);
					RequestDispatcher dispatcher = request.getRequestDispatcher("/member/update/changePwd.jsp");
					dispatcher.forward(request, response);			
					return;
						 
					} catch(GTFDataInvalidException e) {
						errorList.add(e.getMessage()); //輸出給網頁上
				}
			
			//3.2產生註冊失敗的回應
			RequestDispatcher dispatcher = request.getRequestDispatcher("/member/update/forgotPwd.jsp");
			request.setAttribute("errors", errorList);//將錯誤清單傳過去
			dispatcher.forward(request, response);	
			}
	}
}