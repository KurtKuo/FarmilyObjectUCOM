package farmily.gtf.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;


import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import farmily.gtf.entity.Product;
import farmily.gtf.entity.ShoppingCart;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.ProductService;

/**
 * Servlet implementation class AddToCartServlet
 */
@WebServlet("/member/cart/add_cart.do")
public class AddToCartServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AddToCartServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		List<String> errors = new ArrayList<>(); //錯誤清單
		HttpSession session = request.getSession();
		//1.取得request中的 form data 
		 String productId = request.getParameter("productId");
		 String color = request.getParameter("color");
		 String size = request.getParameter("size");
		 String quantity = request.getParameter("quantity");
		 //2.邊檢查資料邊呼叫商業邏輯
		 if(productId!=null) {
			ProductService service = new ProductService();
					try {
						Product p = service.getProductById(productId);
						if(p!=null) { //
							
							if(quantity!=null && quantity.matches("\\d+")) {///
								ShoppingCart cart = (ShoppingCart) session.getAttribute("cart");
										if(cart==null) {////
											cart = new ShoppingCart();
											session.setAttribute("cart", cart);
										}
								cart.add(p, color, size, Integer.parseInt(quantity));
								
							}else {///
								errors.add("加入購物車時數量必須為正整數，謝謝"+quantity);	 
							}
						}else {//
						 errors.add("加入購物車時查不到該編號的產品，謝謝"+productId);	 
						}			
					}catch (GTFException e) {
						// TODO Auto-generated catch block
						 errors.add("加入購物車時查詢產品失敗，謝謝"+productId);
					}catch (GTFDataInvalidException e) {
						errors.add("加入購物車失敗:"+e.getMessage());
					}catch(Exception e) {
						errors.add("加入購物車時查詢產品失敗"+e);
					}	
			}else {
					errors.add("加入購物車，必須有產品編號，謝謝"+productId);
				}
		 	System.out.println(errors);
		 	
		 	//3.成功或失敗皆forward給購物車畫面
		 	//因為外部轉址 會用response將完整網址交給Browser端，request生命週期由response送出那刻便結束
		 	//所以將request 改成 session
		 	if(errors.size()>0) {
		 		//request.setAttribute("errors", errors);
		 		session.setAttribute("errors", errors);
		 	}
		 		//else {
		 //		//若沒有錯誤便將之前錯誤刪除，以免造成誤會
		 //		//request.removeAttribute("errors");
		 //		session.removeAttribute("errors");
		 //	}
		 	
		 	//RequestDispatcher dispatcher = request.getRequestDispatcher("/member/cart/cart.jsp");
		 	//import javax.servlet.RequestDispatcher;
		 	//dispatcher.forward(request, response);
		 	
		 	//request.getRequestDispatcher("/member/cart/cart.jsp").forward(request, response);
		 	//改成外部轉址
		 	//將完整的網址告訴瀏覽器，請瀏覽器再送一次GET請求
		 	//已改成同步請求
		 	//response.sendRedirect(request.getContextPath()+"/member/cart/cart.jsp");
		 		//因為改成 ajax改成下列回應
		 	request.getRequestDispatcher("/member/cart/small_cart.jsp").forward(request, response);
	}	
	
}
