package farmily.gtf.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;

/**
 * Servlet implementation class LoginServlet
 */
@WebServlet(name="LoginServlet",urlPatterns="/member/login/login.do")//務必保留字串的 左邊'/' 不然伺服器會當掉//
//伺服器端是contextRoot後面 所以 action="/member/login/login.do"
//@WebServlet("/member/login/login.do");  Servlet是伺服器根據請求對應至正確url
//完整路徑http://localhost:8080/farmily/member/login/login.do
public class LoginServlet extends HttpServlet { //繼承HttpServlet父類別
	//正常類別不會有網址，只有在HttpServlet的子類別才可以在程式碼利用@WebServlet 宣告網址位置
	private static final long serialVersionUID = 1L;
       
    /**
     * Defult constructor
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
        //預設建構子，無參數建構子
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
    //Post安全度高，不能用Get因為使用者可以從url看到
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
    	
    	//若只將資料放進request因為生命週期太短，所以改成session
    	//結束時間-request 畫面產生，session 連線斷線
    	HttpSession session =request.getSession();
    	List<String> errorList = new ArrayList<>();//集合 List裡面的子類別ArrayList 清單 <-語法
		//request.setCharacterEncoding("utf-8"); //當FormData有中文時login沒有中文
		
		//1. 取得請求request傳來的FormData: id,password,captcha (login.html name=的值) 並檢查之
		String id = request.getParameter("id"); //取前端輸入的範圍資料 form data 內的name
		String pwd = request.getParameter("password");//form data 內的password
		String captcha = request.getParameter("captcha");//form data 內的captcha
		
		System.out.println(id);//測試資料輸出在Web伺服器上Console視窗
		System.out.println(pwd);//測試資料輸出在Web伺服器上Console視窗
		System.out.println(captcha);//測試資料輸出在Web伺服器上Console視窗
		
		//檢查
		if(id==null||id.length()==0) {
			errorList.add("請輸入帳號，謝謝");
			}
		if(pwd==null||pwd.length()<8||pwd.length()>20) { 
			// 判斷兩個密碼一致 <||!password1.equals(password2) 或者不相等 >
			errorList.add("請輸入密碼，長度8~20個，謝謝");
			}
		if(captcha==null||captcha.length()==0) {
			errorList.add("請輸入captcha，謝謝");
		}else {
			//TODO: 15章
			String oldCaptcha = (String)session.getAttribute("captcha");
			//要記得轉型String
			if(!(captcha).equals(oldCaptcha)) //大小寫都要對
			{//if(!(captcha).equalsIgnoreCase(oldCaptcha))//大小寫沒關係
				errorList.add("驗證碼不正確，謝謝");
			}	
		}
		session.removeAttribute("captcha");
		//將舊的驗證碼移除，怕下一次進入瀏覽器會用舊的
		
		//若檢查無誤，才呼叫商業邏輯
		if(errorList.isEmpty()) {
		//2.若無誤，呼叫商業邏輯CustomerService login方法 建立CustomerService類別的物件
		CustomerService service = new CustomerService();
		try {
			//import farmily.gtf.entity.Customer;
			Customer c = service.login(id, pwd);
			
			//建立cookie
			//將消費者輸入的id 存進id變數中 後者存入前者name裡頭
			Cookie idCookie = new Cookie("id",id);
			Cookie autoCookie = new Cookie("auto","checked");
			
			idCookie.setMaxAge(0); //0表示cookie不但不存檔，有舊的還會被delete
			autoCookie.setMaxAge(0);//必須設定Cookie生命週期
			
			String auto = request.getParameter("auto");
			//若 name="auto"有打勾
			if(auto!=null) {
				//若有打勾7天為有限期限
				int sec = 7*24*60*60; //單位秒 ex.7天
				idCookie.setMaxAge(sec); //預設值為負值 不設定就不會儲存 0即是刪除
				autoCookie.setMaxAge(sec);//必須設定Cookie生命週期				
			}			
			response.addCookie(idCookie);
			response.addCookie(autoCookie);
			
			
			//3.1 內部轉交(forward) loginTransfer.jsp
			RequestDispatcher dispatcher = request.getRequestDispatcher("/member/login/loginTransfer.jsp");
			//request 生命週期太短要改為 session類別
			session.setAttribute("member", c);
			dispatcher.forward(request, response);
			
			//import javax.servlet.RequestDispatcher;
			//ServletRequest內方法，取得派遣器 並指派回給 RequestDispatcher物件
			return;//成功即結束				
			
		}catch(GTFDataInvalidException e) {
			this.log(e.getMessage(),e);//寫給admin,tester 給管理者or開發人員
			errorList.add(e.getMessage()); //輸出給網頁上		
		}catch (GTFException e) {
			// TODO Auto-generated catch block
			this.log(e.getMessage(),e);//寫給admin,tester 給管理者or開發人員
			errorList.add(e.getMessage()); //輸出給網頁上	
		}catch (Exception e) {
			this.log("會員登入發生非預期錯誤",e);//寫給admin,tester 給管理者or開發人員
			errorList.add(e.getMessage()+"，請聯絡系統管理員"); //輸出給網頁上
			}
		}//if(errorList.isEmpty())
		
		
		//3.2 資料檢查有誤or商業邏輯失敗，執行失敗 切換至login.jsp & 絕對路徑 /member/login/login.jsp
		RequestDispatcher dispatcher = request.getRequestDispatcher("/member/login/login.jsp");
		request.setAttribute("errors", errorList);//將錯誤清單傳過去
		dispatcher.forward(request, response);
		
				
	}
}
