package farmily.gtf.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 * Servlet implementation class LogoutServlet
 */
@WebServlet(name="LogoutServlet",urlPatterns="/logout.do")
public class LogoutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LogoutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session = request.getSession(false);
		//HttpSession session = request.getSession(); 這個為建立新的session
		//建立新的虛擬物件 連線
		//既然要logout必須取舊的session物件//boolean false來取消建立新的連線
		//2.呼叫商業邏輯
		if(session!=null) {
		session.invalidate();
		}//利用invalidate()登出，銷毀session物件
		//3.forward 回首頁
		request.getRequestDispatcher("/").forward(request, response);
		//RequestDispatcher dispatcher =request.getRequestDispatcher("/");
		//dispatcher.forward(request, response);
		//回首頁
	}
}
