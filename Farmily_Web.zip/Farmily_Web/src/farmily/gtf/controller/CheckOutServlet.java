package farmily.gtf.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import farmily.gtf.entity.Customer;
import farmily.gtf.entity.Order;
import farmily.gtf.entity.PaymentType;
import farmily.gtf.entity.ShippingType;
import farmily.gtf.entity.ShoppingCart;
import farmily.gtf.exception.GTFException;
import farmily.gtf.exception.GTFStockShortageException;
import farmily.gtf.service.OrderService;

/**
 * Servlet implementation class CheckOutServlet
 */
@WebServlet("/member/cart/check_out.do")
public class CheckOutServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public CheckOutServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
	
		HttpSession session= request.getSession();
		Customer member = (Customer) session.getAttribute("member");
		if(member==null) {
			//瀏覽器角度 必須絕對路徑
			response.sendRedirect(request.getContextPath()+"/member/login/login.jsp");
			return;
		}
		ShoppingCart cart = (ShoppingCart)session.getAttribute("cart");
		if(cart==null || cart.isEmpty()) {
			//瀏覽器角度 必須絕對路徑
			response.sendRedirect(request.getContextPath()+"/member/cart/cart.jsp");
			return;
		}
		
		List<String> errors = new ArrayList<>();
		//1.取得request的form data
		String paymentType = request.getParameter("paymentType");//ATM,HOME,...
		String shippingType = request.getParameter("shippingType");
		
		String recipientName = request.getParameter("recipientName");
		String recipientEmail = request.getParameter("recipientEmail");
		String recipientPhone = request.getParameter("recipientPhone");
		String shippingAddress = request.getParameter("shippingAddress");
		
		PaymentType pType = null;
		if(paymentType==null || paymentType.length()==0) {
			errors.add("必須選擇付款方式");
		}else {
			pType = PaymentType.valueOf(paymentType);
		}
		
		ShippingType shType = null;
		if(shippingType==null || shippingType.length()==0) {
			errors.add("必須選擇貨運方式");
		}else {
			shType=ShippingType.valueOf(shippingType);
		}
		
		if(recipientName==null || (recipientName=recipientName.trim()).length()==0) {
			errors.add("必須輸入收件人姓名");
		}
		
		if(recipientEmail==null || (recipientEmail=recipientEmail.trim()).length()==0) {
			errors.add("必須輸入收件人email");
		}
		
		if(recipientPhone==null || (recipientPhone=recipientPhone.trim()).length()==0) {
			errors.add("必須輸入收件人電話");
		}
		
		if(shippingAddress==null || (shippingAddress=shippingAddress.trim()).length()==0) {
			errors.add("必須輸入收件地址");
		}
		
		//2.若無誤，則呼叫商業邏輯
		if(errors.isEmpty()) {
			Order order = new Order();
			order.setMember(member);
			order.add(cart);
			
			order.setPaymentType(pType);
			order.setPaymentFee(pType.getFee());
			
			order.setShippingType(shType);
			order.setShippingFee(shType.getFee());
			
			order.setRecipientName(recipientName);
			order.setRecipientEmail(recipientEmail);
			order.setRecipientPhone(recipientPhone);
			order.setShippingAddress(shippingAddress);
			
			OrderService oService = new OrderService();
			try {
				oService.insert(order);				
				session.removeAttribute("cart");
				
				//3.1 forward to check_out_ok.jsp
				request.setAttribute("order", order);
				
				  //加入信用卡串接程式(以下紅色粗體字部分)
		          //若paymentType=PaymentType.CARD則轉交/WEB-INF/credit_card.jsp來送出對於第三方支付的請求
		          if(order.getPaymentType()==PaymentType.CARD){         
		        	 //request.getRequestDispatcher(request.getContextPath()+"/WEB-INF/credit_card.jsp").forward(request, response);  //可以測試時用這個
		             request.getRequestDispatcher("../../WEB-INF/credit_card_5597.jsp").forward(request, response);                 
		             return;
		          }      
				
				request.getRequestDispatcher("check_out_ok.jsp").forward(request, response);
				return;
			}catch (GTFStockShortageException e) {
				this.log(e.getMessage(),e);
				errors.add(e.getMessage());
				session.setAttribute("errors", errors);
				response.sendRedirect(request.getContextPath()+"/member/cart/cart.jsp");
				return;
			} catch (GTFException e) {
				this.log(e.getMessage(), e);
				errors.add(e.getMessage());
			}catch (Exception e) {
				this.log("建立訂單發生非預期錯誤", e);
				errors.add("建立訂單失敗:" + e);				
			}
		}
		//3.2 forward to check_out.jsp
		request.setAttribute("errors", errors);
		request.getRequestDispatcher("check_out.jsp").forward(request, response);
		return;
	}

}
