package farmily.gtf.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;

import javax.servlet.DispatcherType;
import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
/**
 * Servlet Filter implementation class CharSetFilter
 */
@WebFilter(urlPatterns={ "*.do", "*.jsp" },dispatcherTypes = {DispatcherType.REQUEST,DispatcherType.ERROR})
public class CharSetFilter implements Filter {

    /**
     * Default constructor. 
     */
    public CharSetFilter() {
    	//無參數建構式
    }

	/**
	 * @see Filter#destroy()
	 */
    @Override
	public void destroy() {
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
    @Override
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		// pass the request along the filter chain
    	//編碼完後必須要鎖定，不然會被後續更改
    	//前置處理
    	request.setCharacterEncoding("utf-8");//設定編碼
    	request.getParameterNames();//鎖定request邊碼
    	//getParameterNames
    	
    	response.setCharacterEncoding("utf-8");
    	response.getWriter();//鎖定response編碼
		chain.doFilter(request, response);//交棒給 Filter > Servlet(jsp)
		//後續處理
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
    @Override
	public void init(FilterConfig fConfig) throws ServletException {
	}

}
