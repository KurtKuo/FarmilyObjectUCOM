ALTER TABLE product_colors
	ADD CONSTRAINT fk_product_colors_TO_products
    FOREIGN KEY (product_id) REFERENCES products(id);

ALTER TABLE order_items
	ADD CONSTRAINT fk_order_items_TO_orders
    FOREIGN KEY (order_id) REFERENCES orders(id);
 
ALTER TABLE order_items
	ADD CONSTRAINT fk_order_items_TO_products
    FOREIGN KEY (product_id) REFERENCES products(id); 
 
ALTER TABLE  orders  
	ADD CONSTRAINT fk_orders_TO_customers
    FOREIGN KEY (customer_id) REFERENCES customers(id);
    
