USE gtf;

UPDATE customers
	SET password="asdf12343", name="迪迪", gender="M", birthday="1999-02-24", email="iiii@uuu.cod", address="阿努", phone="0933232333", subscribed=true
	 WHERE id='A123456707';