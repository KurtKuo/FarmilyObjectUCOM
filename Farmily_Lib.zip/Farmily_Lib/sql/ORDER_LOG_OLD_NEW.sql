SELECT * FROM orders_log WHERE order_id
AND old_status!=new_status;