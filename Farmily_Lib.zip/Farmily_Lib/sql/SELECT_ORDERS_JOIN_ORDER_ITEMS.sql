SELECT id, customer_id, order_date, order_time,
 payment_type, payment_fee, shipping_type, shipping_fee,
 shipping_address FROM orders 
	WHERE customer_id='A123456770';
    
SELECT order_id, price, quantity
	FROM  order_items WHERE order_id IN (41,42,43,44);

SELECT id,order_date, order_time,status, 
	payment_type, payment_fee, shipping_type, 
    shipping_fee, shipping_address,
    sum(price *quantity) total_amount,
    (sum(price*quantity)+sum(payment_fee)+sum(shipping_fee)) as total_amount_fee,
    price, quantity, price*quantity as amount
    FROM orders LEFT JOIN order_items
		ON orders.id = order_items.order_id	
	WHERE customer_id='A123456770'
    GROUP BY orders.id;
    
    
    /*歷史訂單查詢*/
    SELECT id,order_date, order_time, 
		payment_type, payment_fee,
	    shipping_type, shipping_fee, shipping_address,
	    sum(price *quantity) total_amount,
	    (sum(price*quantity)+sum(payment_fee)+sum(shipping_fee)) as total_amount_fee
    FROM orders 
    	LEFT JOIN order_items
		ON orders.id = order_items.order_id	
	WHERE customer_id='A123456770'
    GROUP BY orders.id;
    
    
    /*單筆訂單查詢*/
    
    SELECT id, customer_id, order_date, order_time,status,
    	payment_type, payment_fee, payment_note,
    	shipping_type, shipping_fee, shipping_note,
    	recipient_name, recipient_email, recipient_phone, shipping_address
		FROM orders WHERE id = '18';
	
		
		
	SELECT orders.id, customer_id, order_date, order_time, status,
	 payment_type, payment_fee, payment_note,
	 shipping_type, shipping_fee, shipping_note,
	 recipient_name, recipient_email, recipient_phone, shipping_address,
	 order_id, order_items.product_id,products.name,order_items.color_name,
	 products.photo_url,product_colors.photo_url, size, price, quantity
	 
	FROM orders 
		LEFT JOIN order_items ON orders.id = order_items.order_id 
		LEFT JOIN products ON order_items.product_id = products.id
	    LEFT JOIN product_colors ON order_items.product_id = product_colors.product_id 
						AND order_items.color_name = product_colors.color_name
	WHERE orders.id = '40';



	
	
	
	
	
	
	