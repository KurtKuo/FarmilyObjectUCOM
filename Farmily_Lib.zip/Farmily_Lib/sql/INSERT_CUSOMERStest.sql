INSERT INTO customers
	(id, password, name, gender, birthday, email, address, phone, subscribed)
    VALUE('A123123132','asdf1234','王武','M','2000-02-03','test02@uuu.com.tw','','',false);