SELECT id, name,product_colors.color_name,size, product_colors.stock as color_stock, 
		products.unit_price, products.stock, description, 
		products.photo_url, products.shelf_date, category, discount,
        
        
        
		product_colors.photo_url as color_photo,
        product_colors.shelf_date as color_shelf_date,icon_url,
        product_color_sizes.stock as size_stock, product_color_sizes.unit_price as size_price
        
   FROM products
   LEFT JOIN product_colors ON products.id=product_colors.product_id
   LEFT JOIN product_color_sizes
   ON products.id = product_color_sizes.product_id
   AND ((product_colors.color_name = product_color_sizes.color_name) 
	   OR(product_colors.color_name IS NULL 
			AND product_color_sizes.color_name=''))

        ORDER BY id, name,product_colors.color_name,ordinal;