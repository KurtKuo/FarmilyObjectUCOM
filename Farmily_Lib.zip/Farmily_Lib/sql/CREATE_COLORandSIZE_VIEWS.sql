CREATE VIEW products_colors_view AS /* 反正規化 */ /* CREATE:建立 ALTER:修改  */
SELECT 
         products . id  AS  id ,
        IFNULL( product_colors . color_name , '') AS  color_name ,
        
         products . name  AS  name ,
         products . unit_price  AS  unit_price ,
         products . stock  AS  stock ,
         products . description  AS  description ,
         products . photo_url  AS  photo_url ,
         products . shelf_date  AS  shelf_date ,
         products . category  AS  category ,
         products . discount  AS  discount ,
         
         product_colors . stock  AS  color_stock ,
         product_colors . photo_url  AS  color_photo ,
         product_colors . shelf_date  AS  color_shelf_date ,
         product_colors . icon_url  AS  icon_url 
    FROM
        ( products 
        LEFT JOIN  product_colors  ON (( products . id  =  product_colors . product_id )));
					/* WHERE p.id IN (1,2,5,10); */
    
    
CREATE VIEW  products_color_sizes_view  AS/* 反正規化 */
    SELECT 
         products . id  AS  id ,
         
        IFNULL( product_color_sizes . color_name , '') AS  the_color_name ,
         product_color_sizes . size  AS  size ,
         product_color_sizes . ordinal  AS  ordinal ,
         
         products . name  AS  name ,
         products . unit_price  AS  unit_price ,
         product_color_sizes . unit_price  AS  size_price ,
         
         products . stock  AS  stock ,
         product_color_sizes . stock  AS  size_stock ,
         
         products . description  AS  description ,
         products . photo_url  AS  photo_url ,
         products . shelf_date  AS  shelf_date ,
         products . category  AS  category ,
         products . discount  AS  discount 
    FROM
        ( products 
        LEFT JOIN  product_color_sizes  ON (( products . id  =  product_color_sizes . product_id )));
		/*WHERE products.id IN (1,2,5,10); */
    
    
    
    