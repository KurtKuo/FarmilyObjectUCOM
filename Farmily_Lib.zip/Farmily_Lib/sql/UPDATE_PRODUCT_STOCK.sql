SELECT id,stock FROM products WHERE id =1;

SELECT product_id,stock FROM product_colors WHERE product_id=3 AND color_name="紫";

SELECT product_id,stock FROM product_color_sizes WHERE product_id=3 AND color_name="紫" AND size='M';

SELECT product_id,stock FROM product_color_sizes WHERE product_id=14 AND color_name='' AND size='M';

/*如果購買數量為3*/
UPDATE  products SET stock=stock-3 WHERE stock>=3 AND id=1;

UPDATE product_colors SET stock=stock-3 WHERE stock>=3 AND (product_id=13 AND color_name='紫');

UPDATE product_color_sizes SET stock=stock-3 WHERE stock>=3 AND (product_id=13 AND color_name='紫' AND size='M');

UPDATE product_color_sizes SET stock=stock-3 WHERE stock>=3 AND (product_id=13 AND color_name='' AND size='M');

/*UPDATE無法同時執行*/
UPDATE products SET stock=stock-5 WHERE stock>=5 AND id=1;

UPDATE products SET stock=stock-3 WHERE stock>=3 AND id=1;

UPDATE products SET stock=stock-2 WHERE stock>=2 AND id=1;

SELECT id,stock FROM products WHERE id =2;
