SELECT  id, name, unit_price, stock, description, photo_url, shelf_date, category, discount, products_type
	FROM  products
WHERE id = 3;

SELECT  product_id, color_name, stock, photo_url, shelf_date, icon_url
	FROM    product_colors
WHERE  product_id = 3;

/*INNER JOIN*/
SELECT id, name, unit_price, products.stock, description, products.photo_url,
 products.shelf_date, category, discount, products_type ,
 
 color_name, product_colors.stock,
 product_colors.photo_url,
 product_colors.shelf_date,icon_url
 
 FROM products JOIN product_colors
	ON products.id = product_colors.product_id
     WHERE products.id = 3;
     
/*LEFT OUTER JOIN*/     
SELECT id, name, unit_price, products.stock, description, products.photo_url,
 products.shelf_date, category, discount, products_type ,
 
 color_name, product_colors.stock as color_stock,
 product_colors.photo_url as color_photo,
 product_colors.shelf_date as color_shelf_date,icon_url
 
 FROM products LEFT JOIN product_colors
	ON products.id = product_colors.product_id
     WHERE products.id = 3;
     
/*RIGHT OUTER JOIN*/     
SELECT id, name, unit_price, products.stock, description, products.photo_url,
 products.shelf_date, category, discount, products_type ,
 
 color_name, product_colors.stock,
 product_colors.photo_url,
 product_colors.shelf_date,icon_url
 
 FROM product_colors RIGHT JOIN  products
	ON products.id = product_colors.product_id
     WHERE products.id =3;     

/*CROSS JOIN*/
SELECT id, name, unit_price, products.stock, description, products.photo_url,
 products.shelf_date, category, discount, products_type ,
 
 color_name, product_colors.stock,
 product_colors.photo_url,
 product_colors.shelf_date,icon_url
 FROM products JOIN product_colors;




