/*
-- Query: SELECT id, name,product_colors.color_name,size, product_colors.stock as color_stock, 
		products.unit_price, products.stock, description, 
		products.photo_url, products.shelf_date, category, discount,
		product_colors.photo_url as color_photo,
        product_colors.shelf_date as color_shelf_date,icon_url,
        product_color_sizes.stock as size_stock, product_color_sizes.unit_price as size_price
        
   FROM products
   LEFT JOIN product_colors ON products.id=product_colors.product_id
   LEFT JOIN product_color_sizes
   ON products.id = product_color_sizes.product_id
   AND ((product_colors.color_name = product_color_sizes.color_name) 
	   OR(product_colors.color_name IS NULL 
			AND product_color_sizes.color_name=''))
                
		WHERE products.id IN (29,20,40)
        ORDER BY id, name,product_colors.color_name,ordinal
LIMIT 0, 1000

-- Date: 2021-07-05 17:17
*/
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (20,'河津櫻',NULL,NULL,NULL,1899,217,'花季：春季\n2 月 至 3 月\n花色：粉紅','https://i.ibb.co/9HghN51/march-hejin.png','2021-04-20','Spring',21,NULL,NULL,NULL,NULL,NULL);
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (29,'天然玉米','白','M',22,109,359,'產地：台灣花蓮\n容量：600 g\n有效日期：3 天','https://i.ibb.co/rsQddJp/summer-corn.png','2021-06-04','Summer',15,'https://i.ibb.co/Yy0QX9v/corn-WHITE.png','2021-06-04','https://i.ibb.co/Yy0QX9v/corn-WHITE.png',359,109);
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (29,'天然玉米','白','L',22,109,359,'產地：台灣花蓮\n容量：600 g\n有效日期：3 天','https://i.ibb.co/rsQddJp/summer-corn.png','2021-06-04','Summer',15,'https://i.ibb.co/Yy0QX9v/corn-WHITE.png','2021-06-04','https://i.ibb.co/Yy0QX9v/corn-WHITE.png',22,409);
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (29,'天然玉米','黃','M',359,109,359,'產地：台灣花蓮\n容量：600 g\n有效日期：3 天','https://i.ibb.co/rsQddJp/summer-corn.png','2021-06-04','Summer',15,'https://i.ibb.co/rsQddJp/summer-corn.png','2021-06-03','https://i.ibb.co/rsQddJp/summer-corn.png',359,109);
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (29,'天然玉米','黃','L',359,109,359,'產地：台灣花蓮\n容量：600 g\n有效日期：3 天','https://i.ibb.co/rsQddJp/summer-corn.png','2021-06-04','Summer',15,'https://i.ibb.co/rsQddJp/summer-corn.png','2021-06-03','https://i.ibb.co/rsQddJp/summer-corn.png',22,409);
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (40,'上等火龍果','白','M',524,219,44,'產地：台灣彰化\n容量：600 g\n有效日期：2 天','https://i.ibb.co/nQS7j0M/summer-dragonfruit.png','2021-06-08','Summer',15,'https://i.ibb.co/dcbDDXD/dragon-WHITE.png','2021-06-08','https://i.ibb.co/dcbDDXD/dragon-WHITE.png',44,219);
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (40,'上等火龍果','白','L',524,219,44,'產地：台灣彰化\n容量：600 g\n有效日期：2 天','https://i.ibb.co/nQS7j0M/summer-dragonfruit.png','2021-06-08','Summer',15,'https://i.ibb.co/dcbDDXD/dragon-WHITE.png','2021-06-08','https://i.ibb.co/dcbDDXD/dragon-WHITE.png',44,519);
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (40,'上等火龍果','紅','M',44,219,44,'產地：台灣彰化\n容量：600 g\n有效日期：2 天','https://i.ibb.co/nQS7j0M/summer-dragonfruit.png','2021-06-08','Summer',15,'https://i.ibb.co/nQS7j0M/summer-dragonfruit.png','2021-06-07','https://i.ibb.co/nQS7j0M/summer-dragonfruit.png',524,219);
INSERT INTO `` (`id`,`name`,`color_name`,`size`,`color_stock`,`unit_price`,`stock`,`description`,`photo_url`,`shelf_date`,`category`,`discount`,`color_photo`,`color_shelf_date`,`icon_url`,`size_stock`,`size_price`) VALUES (40,'上等火龍果','紅','L',44,219,44,'產地：台灣彰化\n容量：600 g\n有效日期：2 天','https://i.ibb.co/nQS7j0M/summer-dragonfruit.png','2021-06-08','Summer',15,'https://i.ibb.co/nQS7j0M/summer-dragonfruit.png','2021-06-07','https://i.ibb.co/nQS7j0M/summer-dragonfruit.png',524,519);
