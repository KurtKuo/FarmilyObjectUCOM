SELECT id, name, unit_price, stock, description, photo_url,
	shelf_date, category, discount, products_type FROM products
    WHERE name LIKE '%櫻%';