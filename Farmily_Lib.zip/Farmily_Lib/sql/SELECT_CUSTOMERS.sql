USE gtf;
SELECT id, password, name, gender, birthday, email, address, phone, subscribed FROM customers;

SELECT id, password, name, gender, birthday, email, address, phone, subscribed FROM customers

WHERE id = 'A123456789' AND password='asd1234';