/*
-- Query: SELECT * FROM gtf.products
LIMIT 0, 1000

-- Date: 2021-06-10 18:11
*/
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (1,'三峽上等龍井茶',6299,5,'產地：新北三峽,重量：600 g,有效日期：2 年','https://i.ibb.co/NWrP8by/greentea.png','2021-06-10','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (2,'信義鄉佳釀梅酒',6299,15,'產地：南投信義鄉,容量：720 ml,有效日期：無期限','https://i.ibb.co/r48qrVK/wine.png','2021-01-10','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (3,'花蓮蝶豆花茶',2999,21,'產地：花蓮瑞穗,重量：600 g,有效日期：3 年','https://i.ibb.co/b306Bxr/beantea.png','2021-05-10','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (4,'南投魚池紅玉',3599,30,'產地：南投魚池鄉,重量：600 g,有效日期：2 年','https://i.ibb.co/pKB6BJN/blacktea.png','2021-04-10','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (5,'鹿谷凍頂烏龍茶',3599,25,'產地：南投鹿谷鄉,重量：600 g,有效日期：2 年','https://i.ibb.co/zrQ4gpx/oolong-Tea.png','2021-03-10','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (6,'松柏嶺抹茶粉',1499,55,'產地：南投名間鄉,重量：600 g,有效日期：1 年','https://i.ibb.co/WB60C44/matchatea.png','2021-05-10','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (7,'美麗田草莓果醬',1099,16,'產地：台北內湖,容量：500 ml,有效日期：1 年','https://i.ibb.co/d2DytVr/jam.png','2021-06-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (8,'嘉義特級辣椒醬',1099,24,'產地：嘉義縣,容量：500 ml,有效日期：4 年','https://i.ibb.co/nC5tpWx/chilisauce.png','2021-03-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (9,'大岡山頂級龍眼蜜',4399,120,'產地：高雄大岡山,容量：1200 ml,有效日期：無期限','https://i.ibb.co/YbX0B89/honey.png','2021-03-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (10,'六龜純胡椒粒',1799,29,'產地：高雄六龜區,重量：600 g,有效日期：3 年','https://i.ibb.co/KKPJVZT/pepper.png','2021-05-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (11,'台東紅薑黃粉',1599,59,'產地：台東知本,重量：600 g,有效日期：3 年','https://i.ibb.co/0GVsDVn/turmeric.png','2021-02-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (12,'南投優等孜然粉',1359,29,'產地：南投尖石鄉,重量：600 g,有效日期：3 年','https://i.ibb.co/6WwWmw0/cumin.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (13,'緋寒櫻',1199,210,'花季：春季,1 月 至 4 月,花色：緋紅','https://i.ibb.co/30TVZn1/january-cherry.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (14,'福爾摩沙',2899,240,'花季：春季,1 月下旬,花色：白色','https://i.ibb.co/SQtrkR3/january-formosa.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (15,'富士櫻',2399,251,'花季：春季 2 月 下旬,花色：粉白','https://i.ibb.co/JknRn2X/february-fuji.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (16,'大漁櫻',3199,215,'花季：春季 2 月 至 3 月,花色：粉白','https://i.ibb.co/1nLPwf1/february-catch.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (17,'樁寒櫻',6399,165,'花季：春季 2 月 至 3 月 ,花色：淡粉白','https://i.ibb.co/1KjJCkM/february-perfume.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (18,'墨染櫻',3199,315,'花季：春季 2 月 至 3 月,花色：粉色及白色','https://i.ibb.co/2dfMYw3/february-sumizome.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (19,'重辦八重櫻',2699,187,'花季：春季 2 月 至 3 月,花色：緋紅','https://i.ibb.co/2syCJYS/february-yae.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (20,'河津櫻',1899,217,'花季：春季 2 月 至 3 月,花色：粉紅','https://i.ibb.co/9HghN51/march-hejin.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (21,'霧社櫻',2499,257,'花季：春季 2 月 至 3 月,花色：白色','https://i.ibb.co/8YrwpWm/march-wusheh.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (22,'紅粉佳人',2999,197,'花季：春季 3 月 上旬,花色：粉紅','https://i.ibb.co/Lvv355r/february-pinkgirl.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (23,'千島櫻',4199,241,'花季：春季 3 月 中旬,花色：淡粉紅','https://i.ibb.co/dfWS2K9/february-thousand-Islands.png','2021-04-20','discount',21);
INSERT INTO `` (`id`,`name`,`unit_price`,`stock`,`description`,`poto_url`,`shelf_date`,`category`,`discount`) VALUES (24,'染井吉野櫻',3799,314,'花季：春季 3 月 至 4 月,花色：粉色、白色','https://i.ibb.co/s67nkDL/marchto-Aprilcerasus.png','2021-04-20','discount',21);
