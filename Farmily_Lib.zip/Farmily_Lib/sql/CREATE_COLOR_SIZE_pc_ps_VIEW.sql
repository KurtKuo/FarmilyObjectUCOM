
CREATE VIEW pc_view AS
SELECT id,IFNULL(color_name,'')as color_name,name,unit_price,products.stock,description,
	products.photo_url,products.shelf_date,category,discount,
    product_colors.stock as color_stock,product_colors.photo_url as color_photo,
    product_colors.shelf_date as color_shelf_date,icon_url
    
FROM products LEFT JOIN product_colors
ON products.id = product_colors.product_id;



ALTER VIEW ps_view AS
SELECT id, IFNULL(color_name,'') as the_color_name,size,ordinal,name,
 products.unit_price,product_color_sizes.unit_price as size_price,
 products.stock,product_color_sizes.stock as size_stock,
	description,products.photo_url, products.shelf_date, category, discount
	FROM products 
		LEFT JOIN product_color_sizes
		ON products.id = product_color_sizes.product_id;
        