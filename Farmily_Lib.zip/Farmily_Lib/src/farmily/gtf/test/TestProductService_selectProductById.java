package farmily.gtf.test;

import farmily.gtf.exception.GTFException;
import farmily.gtf.service.ProductService;

public class TestProductService_selectProductById {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ProductService service = new  ProductService();
		try {
			
			System.out.println(service.getProductById("2"));
			
			
		}catch(GTFException e){
			e.printStackTrace();
			
		}
	}
}
