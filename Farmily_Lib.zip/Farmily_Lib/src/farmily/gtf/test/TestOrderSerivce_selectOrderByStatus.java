package farmily.gtf.test;

import java.util.List;

import farmily.gtf.entity.Customer;
import farmily.gtf.entity.Order;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;
import farmily.gtf.service.OrderService;

public class TestOrderSerivce_selectOrderByStatus {

	public static void main(String[] args) {
		CustomerService cService = new CustomerService();
		OrderService oService = new OrderService();
		Customer member;
		
		try {
			member = cService.login("A123456770", "asdf12343");
			
			List<Order> list = oService.getOrderByStatus(member.getId(),0);
			System.out.println(list);

		} catch (GTFException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
}