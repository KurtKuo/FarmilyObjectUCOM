package farmily.gtf.test;

import farmily.gtf.service.MailService;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Administrator
 */
public class TestMailService {

    public static void main(String[] args) {
        MailService.sendHelloMailWithLogoTHANK("onlychengkuo@gmail.com"); //請填入你的有效的測試用email
    }
}
