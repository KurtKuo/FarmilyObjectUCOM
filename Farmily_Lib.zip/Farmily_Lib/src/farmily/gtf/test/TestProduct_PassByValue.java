package farmily.gtf.test;

import java.time.LocalDate;

import farmily.gtf.entity.Product;

public class TestProduct_PassByValue {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product bigMenOne = new Product(1,"迪會貴",1200,5);
		
		bigMenOne.setDescription("又名東京櫻花、日本櫻花，是一種櫻花的園藝品種，為薔薇科櫻屬的植物，產於日本以及移植於中國的北京、南昌、西安、青島、南京等地");
		bigMenOne.setPhotoUrl("https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/2021/03/25/realtime/11949515.jpg&s=Y&x=100&y=0&sw=1080&sh=720&exp=3600");
		bigMenOne.setShelfDate("2000/01/05"); //利用 replace()做修改
		//利用 replace()做修改 ( /修改成- )
		
		System.out.println("ID:"+bigMenOne.getId());
		System.out.println("名稱:"+bigMenOne.getName());
		System.out.println("價錢:"+bigMenOne.getUnitPrice());
		System.out.println("庫存:"+bigMenOne.getStock());
		System.out.println("敘述:"+bigMenOne.getDescription());
		System.out.println("圖片:"+bigMenOne.getPhotoUrl());
		System.out.println("上架時間:"+bigMenOne.getShelfDate());
	
		
	}

}
