package farmily.gtf.test;

import java.time.LocalDate;

import farmily.gtf.entity.Outlet;

public class TestOutlet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Outlet bigMenOutlet = new Outlet();
		bigMenOutlet.setId(12);
		bigMenOutlet.setName("非常好書");
		bigMenOutlet.setUnitPrice(100); //指派定價
		bigMenOutlet.setDiscount(21);
		bigMenOutlet.setStock(10);
		bigMenOutlet.setPhotoUrl("無圖片");
		bigMenOutlet.setDescription("無敘述");
		bigMenOutlet.setShelfDate("2000-01-20");
		
		
	
		/*System.out.println("id"+bigMenOutlet.getId());//12
		System.out.println("書名Name"+bigMenOutlet.getName());//非常好書
		System.out.println("價格"+bigMenOutlet.getUnitPrice());//100.0
		System.out.println("庫存"+bigMenOutlet.getStock());//10
		System.out.println("圖片"+bigMenOutlet.getPhotoUrl());//無圖片
		System.out.println("敘述"+bigMenOutlet.getDescription());//無敘述
		System.out.println("上架日期"+bigMenOutlet.getShelfDate());//2000-01-20
		System.out.println("折扣:"+bigMenOutlet.getDiscount()+"%OFF");//21
		System.out.println("折扣:"+bigMenOutlet.getDiscountString());//79
		System.out.println("售價是多少"+bigMenOutlet.getUnitPrice()*(100-bigMenOutlet.getDiscount())/100);
		//在方法中製作getPrice查詢售價
		//Override 舊方法寫在新類別 使用 Override將private > protected 
		//System.out.println("售價是多少"+bigMenOutlet.getPrice());
		System.out.println("價格"+bigMenOutlet.getUnitPrice());//79.0
		System.out.println("價格"+bigMenOutlet.getListPrice());//100.0
		System.out.println("產品"+bigMenOutlet); //記憶體位置*/
//		System.out.println("產品"+bigMenOutlet.toString()); //記憶體位置
//		System.out.println("hello");//hello
//		System.out.println(LocalDate.now().toString());//String
//		System.out.println(LocalDate.now().plusYears(10000).toString());//String
//		System.out.println(LocalDate.now());
		System.out.println(bigMenOutlet); //記憶體位置經 override 來顯示內容
		//System.out.println("產品"+bigMenOutlet.toString()); //與上面顯示一樣
	}

}
