package farmily.gtf.test;
class A {
    static int counter = 0;
    public void printCount(){
        System.out.println(counter + " ");
    }
}
class B extends A {
    public int counter = 10;
    public void printCount(){
        System.out.println(counter + " ");
    }
}

public class TestPolymorphsimStatic {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 	A foo = new A();
	        A bar = new B();
	        foo.printCount();//A類別參數foo參考A物件內的方法和屬性 為 0
	        bar.printCount();//A類別參數bar參考B物件內的方法和屬性 為 10
	        System.out.println(foo.counter);//A類別參數foo參考A類別屬性
	        System.out.println(bar.counter);//A類別參數bar參考A類別屬性
	        System.out.println(((B)bar).counter); //利用Polymorphsim降型 ，A類別參數bar參考B類別屬性
	        
	}
}

