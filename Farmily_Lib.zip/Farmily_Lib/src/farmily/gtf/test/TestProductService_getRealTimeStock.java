package farmily.gtf.test;

import farmily.gtf.entity.Product;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.ProductService;

public class TestProductService_getRealTimeStock {

	public static void main(String[] args) {
		ProductService pService = new ProductService();
		
		Product p1;
		try {
			p1 = pService.getProductById("1");
			Product p13 = pService.getProductById("29");
			Product p11 = pService.getProductById("40");
			Product p15 = pService.getProductById("44");
			
			System.out.println(p1.getName()+"庫存:"+pService.getRealTimeStock(p1, null, null));
			System.out.println(p13.getName()+","+p13.getColorList().get(1).getColorName()
						+"庫存:"+pService.getRealTimeStock(p13, p13.getColorList().get(1), null));
			
			System.out.println(p11.getName()+","+p11.getColorList().get(0).getColorName()
					+",M庫存:"+pService.getRealTimeStock(p11,p11.getColorList().get(0), "M"));
			
			System.out.println(p15.getName()+","+p15.getColorList().get(0).getColorName()
					+",M庫存:"+pService.getRealTimeStock(p15,p15.getColorList().get(0), "M"));
		} catch (GTFException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}


}
