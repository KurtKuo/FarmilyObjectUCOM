package farmily.gtf.test;

import farmily.gtf.entity.Seasons;

public class TestSenson {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.out.println(Seasons.SPRING.name());
//		System.out.println(Seasons.SPRING.getSeasonCode());
//		System.out.println(Seasons.SPRING.getSeasonColorName());
//		System.out.println(Seasons.SPRING.toString());
//		
//		System.out.println(Seasons.values().length);
		for(int i =0;i<Seasons.values().length;i++)
		{
			System.out.println(Seasons.values()[i].toString());
			System.out.println(Seasons.values()[i].getSeasonCode());
			System.out.println(Seasons.values()[i].getSeasonColorName());
			}
		}
	
	}

