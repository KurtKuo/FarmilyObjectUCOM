package farmily.gtf.test;

import java.time.LocalDate;

import farmily.gtf.entity.Customer;
import farmily.gtf.entity.Outlet;
import farmily.gtf.entity.Product;
import farmily.gtf.entity.VIP;

public class TestEqualOperator {

	public static void main(String[] args) {
		System.out.println("1==1.0: "+(1==1.0)); //true
		System.out.println(true==false); //false
		
		//參考型別String物件的==
		System.out.println("Hello" == "Hello"); //true
		System.out.println("Hello" == new String("Hello")); //false
		//new String("Hello") 建立一個物件 兩個不同物件當然位置不同
		System.out.println("\"Hello\".equals(new String(\"Hello\")): " +
								"Hello".equals(new String("Hello")));//true
		//比較值相同
		
		//參考型別LocalDate物件的==
		System.out.println(
				LocalDate.parse("2000-12-05")==LocalDate.of(2000, 12, 5)); //false	
				//LocalDate.parse("2000-12-05")建立一個物件
				//LocalDate.of(2000, 12, 5))建立一個物件
		System.out.println(
				LocalDate.parse("2000-12-05").equals(LocalDate.of(2000, 12, 5))); //true
				
		
		//參考型別Customer物件的==
		Customer c = new Customer();
		//c.id="A123456789";
		c.setId("A123456789");
		c.setName("狄會貴");
		//c.password="asdf1234";
		c.setPassWord("asdf1234");
		c.setGender('M');
		c.setEmail("test01@uuu.com.tw");
		c.setBirthday(LocalDate.parse("2000-12-05"));
		
		Customer c1 = new Customer();
		//c1.id="A123456789";
		c1.setId("A123456123");
		c1.setName("狄會貴");
		//c1.password="asdf1234";
		c1.setPassWord("asdf1234");
		c1.setGender('M');
		c1.setEmail("test01@uuu.com.tw");
		c1.setBirthday(LocalDate.parse("2000-10-05"));
		//System.out.println(c.birthday=="2000-12-01"); //無法編譯
		
		//利用 toString(); 方法將字串印出
		System.out.println("c和c1利用toString方法: "+c.toString()+"\n\n*************\n"+c1.toString());
		
		
		
		
		
		
		//利用 equals(); 方法判斷
		System.out.println("c.equals(c1): " + c.equals(c1)); //false 身分證號碼不一致
		System.out.println(c==c1); //false	c1的記憶體位置不等於c的記憶體位置
		c1 = c; //將c的記憶體位置指派給c1記憶體位置
		//當執行完c1 = c; c1記憶體位置 為garbage
		System.out.println("c==(c1): "+ (c==c1)); //true 記憶體位置相同true
		
		VIP vip = new VIP();
		
		vip.setId("A123456789");
		System.out.println("c1 和 vip記憶體位置" + (c1==vip));
		System.out.println("c1 和 vip記憶體值" + c1.equals(vip));
		System.out.println("vip 和 c1記憶體值" + vip.equals(c1));
		
		
		Product p = new Product();
		
		p.setId(10);
		p.setName("梅花");
		p.setUnitPrice(15000D);
		
		Product p2 = new Product();
		
		p2.setId(12);
		p2.setName("櫻花");
		p2.setUnitPrice(15000D);
		
		
		System.out.println("p 和 p2記憶體位置" + (c1==vip));
		System.out.println("p 和 p2記憶體值" + p.equals(p2));

		Outlet outlet = new Outlet();
		
		outlet.setId(11);
		outlet.setName("李花");
		outlet.setUnitPrice(15000D);
		outlet.setDiscount(12);
		outlet.setStock(10);
		System.out.println("p 和 outlet記憶體位置" + (p==outlet));
		System.out.println("p 和 p2是否為同一個類別 請Ctrrl + / equals :  " + p.equals(p2));
		//因為equals方法是優先抓取最近類別之equals
		
		
		
		
		Outlet outlet1 = new Outlet();
		outlet1.setId(11);
		outlet1.setName("李花");
		outlet1.setUnitPrice(15000D);
		outlet1.setDiscount(12);
		outlet1.setStock(10);
		System.out.println("outlet 和 outlet1記憶體位置" + (outlet==outlet1));
		System.out.println("outlet  和 outlet1是否為同一個類別 請Ctrrl + / equals :  " + outlet.equals(outlet));
		
	}
	
//	public static String test() {
//		return "Hello";
//	}

}
