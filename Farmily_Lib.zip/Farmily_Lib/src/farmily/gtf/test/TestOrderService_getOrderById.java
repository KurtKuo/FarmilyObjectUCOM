package farmily.gtf.test;

import farmily.gtf.entity.Customer;
import farmily.gtf.entity.Order;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;
import farmily.gtf.service.OrderService;

public class TestOrderService_getOrderById {

	public static void main(String[] args) {
		CustomerService cService = new CustomerService();
		OrderService oService = new OrderService();
		
		
		try {
			Customer member = cService.login("A123456770","asdf12343");
			Order order = oService.getOrderById("29", member);
			System.out.println(order);

		} catch (GTFException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
}
