package farmily.gtf.test;

import farmily.gtf.entity.Gender;

public class TestLGenderEnum {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		System.err.println(Gender.GENGER_MEN.toString());
//		System.err.println(Gender.GENGER_MEN.ordinal());		
//		System.err.println(Gender.GENGER_MEN.name());//
//		System.err.println(Gender.GENGER_MEN.getCode());
		//利用FOR迴圈寫
		for(int i=0; i<Gender.values().length;i++)
		{
			System.out.println(Gender.values()[i].toString());
			System.out.println(Gender.values()[i].getZhName());
			System.out.println(Gender.values()[i].ordinal());
			System.out.println(Gender.values()[i].getCode());
		}
	}
}