package farmily.gtf.test;

import java.time.LocalDate; //必須先import java.time.LocalDate

public class TestIfSwitch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println(LocalDate.of(2021,4,18).getDayOfWeek().getValue());
		//取今天是否為上學日，週日週六放假，周一周二周四需要上整天，周三周五為半天
		int dayOfWeekIfTest = LocalDate.now().getDayOfWeek().getValue();
		
		if(dayOfWeekIfTest==1 || dayOfWeekIfTest==2 || dayOfWeekIfTest==4)
		{
			System.out.println("孩子們恭喜今天是星期"+dayOfWeekIfTest+"要上整天唷!!");
		}
		else if(dayOfWeekIfTest==3 || dayOfWeekIfTest==5)
		{
			System.out.println("孩子們你們以為半天要幹嘛?!就是要補習!!!");
		}
		else if(dayOfWeekIfTest==6 || dayOfWeekIfTest==7)
		{
			System.out.println("好啦今天放假~");
		}
		else
		{
			System.out.println("Error");
		}
		
		//以下使用switch case做判斷，更有效率
		
		int dayOfWeekSwitchTest = LocalDate.now().getDayOfWeek().getValue();
		
		switch (dayOfWeekSwitchTest) {
		//default:
		//System.out.println("Error");
		//break; //最後一個不用加break; default也可以放在第一位
		case 1:
		case 2:
			System.out.println("孩子們恭喜今天是星期"+dayOfWeekSwitchTest+"要上整天唷!!");
			break;
		case 4:
		case 3:
		case 5:
			System.out.println("孩子們你們以為半天要幹嘛?!就是要補習!!!");
			break;
		case 6:
		case 7:
			System.out.println("好啦今天放假~");
			break;
		
		default:
			System.out.println("Error");
			 //最後一個不用加break; default也可以放在第一位
		}
		
		
		
		
		
		
		
		
		
	}

}
