package farmily.gtf.test;

import java.time.LocalDate;

public class TestString_printf {
	public static final char MALE = 'G';
	public static final char FEMALE = 'M';
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		String dateOne = "2000+11+22";
		
		
		
		if(dateOne!=null && dateOne.length()>0) 
		{
			dateOne = dateOne.replace('+', '-');
			LocalDate dateSecond = LocalDate.parse(dateOne);
			System.out.println(dateSecond);
		}
		
		else {
			System.err.println("生日字串不得NULL");
		}
		
		
		
		char gender = 'N';
		if(gender == MALE || gender == FEMALE)
		{
			System.out.println("客戶性別為: "+gender);
		}
		else
		{
			System.err.println("性別資料不正確:"+gender+"正確必須是"+MALE+"男生或是"+FEMALE+"女生");
			
			System.err.printf("性別資料不正確: %s，正確必須是 %S男生或是 %S女生",gender,MALE,FEMALE);
			
		}

	}

}
