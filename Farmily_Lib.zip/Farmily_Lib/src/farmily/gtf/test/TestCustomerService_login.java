package farmily.gtf.test;

import java.util.logging.Level;
import java.util.logging.Logger;

import farmily.gtf.exception.GTFException;
//import farmily.gtf.entity.Customer;
import farmily.gtf.service.CustomerService;
public class TestCustomerService_login {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerService service =new CustomerService();
		//Customer c = service.login("","asdddd1234");//兩個密碼必須相同！
		//Customer c = service.login("A123456789","dqd");//兩個密碼必須相同！
		//Customer c = service.login(null, null, null);//必須輸入帳號和密碼！
		//Customer c = service.login("", null, "");
		//Customer c = service.login(A123456789, null ,ASQSQS);
		//都為錯誤
		try {
		System.out.println(service.login("A123456770","asdf12343"));
		}catch(GTFException e){
			//System.out.println(getMessage());
			Logger.getLogger("詳細的錯誤呈現").log(Level.SEVERE,e.getMessage(),e);
			//Java底層程式庫 邏輯問題處理回報程式
			//Servlet中是寫成
			//this.log(e.getMessage(),e);
		}
		System.out.println("the end");
	}

}
