package farmily.gtf.test;

import java.time.LocalDate;

import farmily.gtf.entity.Customer;

public class TestCustomerForMemoryDrawing2 {

	public static void main(String[] args) {
		
		
		System.out.println(args.length);
		
		
		//基本型別 區域變數
		int i;
		i = 1;
		int j = i;
				i++;
		System.out.println(i); //2
		System.out.println(j); //1
		
		//參考型別 區域變數 = new 類別
		Customer customer = new Customer();
		
		//customer.id= new String("A123456789");
		customer.setId("A123456789");//public>private
		//customer.id = "A123456789";
		//customer.id = new String("A123456789");
		//兩個都可以
		//customer.password="asdf1234"; 
		customer.setPassWord("1234");//public>private
		customer.setName("迪匯貴");
		customer.setGender("M".charAt(0));
		customer.setBirthday(LocalDate.of(2000,10,13));
		//customer.birthday = LocalDate.parse("2000-10-13");
		customer.setEmail("test1@uuu.com.tw");
		
		System.out.println("*****以下為customer*****的資料");//A123456789
		//System.out.println(customer.id);//A123456789
		System.out.println(customer.getId());//public>private
		//System.out.println(customer.password);//asdf1234 public>private
		System.out.println(customer.getPassWord());//public>private
		System.out.println(customer.getName());//迪匯貴
		System.out.println(customer.getGender());//M
		System.out.println(customer.getBirthday());//2021-04-12
		System.out.println(customer.getEmail());//test1@uuu.com.tw
		System.out.println(customer.getAddress());//空字串
		System.out.println(customer.getPhone());//空字串
		System.out.println(customer.isSubscribed());//false
		System.out.println(customer);
		
		
		Customer customer2 = new Customer();
		//customer2.id = "A123456789";
		customer2.setId("A123456789");
		//customer2.password="asdf1234";public>private
		customer2.setPassWord("1234");
		customer2.setName("郭誠誠");
		customer2.setGender("M".charAt(0));
		customer2.setBirthday(LocalDate.of(2111,10,13));
		//customer2.birthday = LocalDate.parse("2111-09-13");
		customer2.setEmail("test2222@uuu.com.tw");
		
		
		
		
		System.out.println("*****以下為customer2*****的資料");//A123456789
		System.out.println(customer2.getId());//public>private
		System.out.println(customer2.getPassWord());//public>private
		System.out.println(customer2.getName());//迪匯貴
		System.out.println(customer2.getGender());//M
		System.out.println(customer2.getBirthday());//2021-04-12
		System.out.println(customer2.getEmail());//test1@uuu.com.tw
		System.out.println(customer2.getAddress());//空字串
		System.out.println(customer2.getPhone());//空字串
		System.out.println(customer2.isSubscribed());//false
		System.out.println(customer2);
		
	}

}
