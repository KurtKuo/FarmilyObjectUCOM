package farmily.gtf.test;

import farmily.gtf.entity.Customer;
import farmily.gtf.entity.VIP;

public class TestInstanceof {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Object o = new Object();
		Customer c = new Customer();
		VIP vip = new VIP();
		
		//皆為繼承關係
		//子類別 instanceof 父類別 true
		System.out.println( o instanceof Object);//true
		System.out.println( c instanceof Object);//true
		System.out.println( vip instanceof Object);//true
		
		//反繼承關係
		System.out.println( o instanceof Customer); //false
		System.out.println( vip instanceof Customer); //true
		System.out.println( o instanceof Customer); //false

		
	}

}
