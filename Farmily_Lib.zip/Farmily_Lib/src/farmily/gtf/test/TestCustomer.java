package farmily.gtf.test;

import java.time.LocalDate;
import java.util.Scanner;

import farmily.gtf.entity.Customer;

public class TestCustomer {

	public static void main(String[] args) {
		int i ;
		Customer customer = new Customer();
		customer.setId("A123123123");//public>private
		//customer.id = "A123456789";
		customer.setPassWord("asd1234");//public>private
		customer.setName("迪匯貴");
		customer.setGender(Customer.OTHER_GENDER); //or 'M'
		
		//customer.setBirthday(2018,5,5);
		customer.setBirthday("2000-01-05");
		//customer.setBirthday(LocalDate.of(1998,5,5));
		customer.setEmail("test1@uuu.com.tw");
		
		
//		System.out.println(customer.getId());//A123456789
//		//System.out.println(customer.password);//asdf1234 因為屬性改成private
//		System.out.println(customer.getPassWord()); //因為屬性改為private 所以改成getPassWord方法
//		System.out.println(customer.getName());//迪匯貴
//		System.out.println(customer.getGender());//M
//		System.out.println(customer.getBirthday());//1998-05-05
//		System.out.println(customer.getEmail());//test1@uuu.com.tw
//		System.out.println(customer.getAddress());//空字串
//		System.out.println(customer.getPhone());//空字串
//		System.out.println(customer.isSubscribed());//false
		System.out.println(customer);
	}

}
