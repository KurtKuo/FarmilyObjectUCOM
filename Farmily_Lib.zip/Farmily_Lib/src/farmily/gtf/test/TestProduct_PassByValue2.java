package farmily.gtf.test;

import java.time.LocalDate;

import farmily.gtf.entity.Product;
import farmily.gtf.service.ProductService;

public class TestProduct_PassByValue2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product bigMenOne = new Product(1,"迪會貴",1200,5);
		ProductService bigMen2 = new ProductService();
		
//		System.out.println("ID:"+bigMenOne.getId());
//		System.out.println("名稱:"+bigMenOne.getName());
//		System.out.println("價錢:"+bigMenOne.getUnitPrice());
//		System.out.println("庫存:"+bigMenOne.getStock());
//		System.out.println("敘述:"+bigMenOne.getDescription());
//		System.out.println("圖片:"+bigMenOne.getPhotoUrl());
//		System.out.println("上架時間:"+bigMenOne.getShelfDate());
	
		bigMen2.addPrice(bigMenOne);
		System.out.println(bigMenOne.getUnitPrice());//1210
		
		bigMen2.addPrice(bigMenOne.getUnitPrice());
		System.out.println(bigMenOne.getUnitPrice());//1210
		
		bigMen2.addPrice(bigMenOne);
		System.out.println(bigMenOne.getUnitPrice());//1220
		
		bigMen2.addPrice(bigMenOne);
		System.out.println(bigMenOne.getUnitPrice());//1220

	}

}
