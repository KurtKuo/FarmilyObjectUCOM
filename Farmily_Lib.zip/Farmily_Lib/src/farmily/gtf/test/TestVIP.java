package farmily.gtf.test;

import farmily.gtf.entity.VIP;

public class TestVIP {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		VIP vip = new VIP();
		vip.setId("A123456789");
		System.out.println(vip.getId());
		
		vip.setDiscount(10);
		//System.out.println(vip.getDiscount());
		//System.out.println(vip.getDiscountString());
		
		System.out.println(vip);
		
		
	}

}
