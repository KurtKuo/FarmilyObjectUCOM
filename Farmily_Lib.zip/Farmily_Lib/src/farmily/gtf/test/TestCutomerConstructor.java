package farmily.gtf.test;

import java.time.LocalDate;

import farmily.gtf.entity.Customer;

public class TestCutomerConstructor {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i = Integer.parseInt("1");
		byte a = 1;
		System.out.println(a);
	
		Customer customer = new Customer("A123456789","A123456","迪會貴",'M',LocalDate.of(2000,6,2),"test1@uuu.com.tw");
		
		//customer.setId("A123456789");
		//customer.setName("迪會貴");
		//customer.setPassWord("A123456");
		//customer.setBirthday(2000,5,5);
		//customer.setGender("M".charAt(0)); //or 'M'
		//customer.setBirthday(1911,5,5);
		//customer.setBirthday("1911-05-05");
		//customer.setEmail("test1@uuu.com.tw");
		
		
		
		
		
		
		
		
		System.out.println("ID :"+customer.getId());//A123456789
		//System.out.println(customer.password);//asdf1234 因為屬性改成private
		System.out.println("密碼 :"+customer.getPassWord()); //因為屬性改為private 所以改成getPassWord方法
		System.out.println("姓名 :"+customer.getName());//迪匯貴
		System.out.println(customer.getGender());//M
		System.out.println(customer.getBirthday());//1998-05-05
		System.out.println(customer.getEmail());//test1@uuu.com.tw
		System.out.println(customer.getAddress());//空字串
		System.out.println(customer.getPhone());//空字串
		System.out.println(customer.isSubscribed());//false
		System.out.println(customer.getAge());//false
	
		
	}

}
