package farmily.gtf.test;

import java.util.logging.Level;
import java.util.logging.Logger;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;

public class TestCutomerService_changePassword {

	public static void main(String[] args) {
		CustomerService service = new CustomerService();
		try {
			
			Customer c = service.useEmailLogin("onlychengkuo@gmail.com");
			System.out.println("****修改前****");
			System.out.println(c);
			
			c.setPassWord("asdf12343");
			service.forgetPassword(c);
	
			System.out.println("****修改後****");
			Customer c2 = service.login("onlychengkuo@gmail.com", c.getPassWord());
			
			System.out.println(c2);
			
		} catch (GTFDataInvalidException e) {
			System.err.println(e.getMessage());
		} catch (GTFException e) {
			Logger.getLogger("詳細的錯誤呈現").log(Level.SEVERE,e.getMessage(),e);
			}
	}

}
