package farmily.gtf.test;

import java.time.LocalDate;

import farmily.gtf.entity.Customer;

public class TestCustomerBirthdayAge {

	public static void main(String[] args) {
		//LocalDate.now();
		//LocalDate.of(2000,3,5);
		//LocalDate.parse("2000-01-15");
		
		Customer bigMen = new Customer();
		//bigMen.id="A123456789";
		bigMen.setId("A123456789");
		bigMen.setName("誠誠");
		bigMen.setBirthday(LocalDate.parse("2000-01-01"));//若沒有這行bigMen.birthday = null便不會執行
		
		
		//計算客戶物件bigMen的年齡
		/*if(bigMen.birthday!=null) {
			int customer1Age = 0;
			int thisYear = LocalDate.now().getYear();
			int birthdayYear = bigMen.birthday.getYear();
			System.out.println("bigMen 名字是"+bigMen.name);
			int age = thisYear-(bigMen.birthday.getYear());
			System.out.println("bigMen 歲數"+age);
			
		}
		else
		{
			System.out.println("沒有誠誠的生日所以不能執行!!");
		}*/
			System.out.println(bigMen.getName()+"ID是"+bigMen.getId());
	}

}
