package farmily.gtf.test;

import java.text.NumberFormat;
import java.util.Locale;

import farmily.gtf.entity.BloodType;

public class TestBloodType {

	public static void main(String[] args) {
		
		System.out.println(BloodType.O.getClass().getName());
		System.out.println(BloodType.O);
		System.out.println(BloodType.O.toString());
	
		System.out.println(BloodType.O.name());
		System.out.println(BloodType.O.ordinal());
		
		System.out.println(BloodType.A);
		System.out.println(BloodType.A.name());
		System.out.println(BloodType.A.ordinal());
		
		System.out.println(BloodType.B);
		System.out.println(BloodType.B.name());
		System.out.println(BloodType.B.ordinal());
		
		System.out.println(BloodType.AB);
		System.out.println(BloodType.AB.name());
		System.out.println(BloodType.AB.ordinal());
		
		NumberFormat nf = NumberFormat.getCurrencyInstance();
		System.out.println("四捨六入五成雙: "+ nf.format(5.175));
		nf = NumberFormat.getInstance();
		System.out.println("四捨五入: "+ nf.format(5.1756));
		nf = NumberFormat.getCurrencyInstance(Locale.US);
		System.out.println("四捨六入五成雙 US貨幣: "+ nf.format(5.175654321));
		
		System.out.println("記憶體位置: "+ nf.getClass().getName());
		
	}

}
