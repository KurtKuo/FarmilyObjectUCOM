package farmily.gtf.test;

import java.time.LocalDate;

import farmily.gtf.entity.Customer;
import farmily.gtf.entity.VIP;

public class TestPolymorphsim {
	//本次練習多型Polymorphsim
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c = new VIP();
		//上層型別宣告的變數，參考至下層型別建立的物件
		
		c.setId("A123456789");
		c.setName("郭小豬");
		System.out.println("VIP的物件"+c);
		System.out.println("VIP的第二行"+c.toString());
		System.out.println("***********************");
		System.out.println("參考VIP類別");
		if(c instanceof VIP) {
		((VIP)c).setDiscount(5);
		System.out.println("利用getDiscountString():"+((VIP)c).getDiscountString());
		System.out.println("利用getDiscount():"+((VIP)c).getDiscount());
		
		}
		System.out.println("***********************");
		
		
		Object s = "Hello";//上層型別宣告的變數，參考到下層型別建立之物件， Polymorphsim declaration
		String str = new String("Hello"); //normal declaration
		
		System.out.println(str.length()); //length 為String類別內的方法所以可以參考到
		// System.out.println(s.length()); 此為編譯錯誤，因為父類別 Object無法參考使用到子類別String內的方法length()
		
		
		if(s instanceof String)
		{
			String stringTest = (String)s;
			System.out.println("上層型別參考至下層型別後(轉型後):"+((String)s).length()); //5 將s轉型成String 轉型以後才能使用length方法來讀取長度為5
			//System.out.println("並利用toString方法:"+(String)s.length()); //先執行 .length();  Object內並無length方法 所以會編譯錯誤
			System.out.println("利用toString方法後再轉型:"+(String)s.toString()); //先執行 . 然後再轉為String
			System.out.println("轉型完後指派給新變數stringTest:"+stringTest); 
			System.out.println("並利用length方法:"+stringTest.length());//字串長度
			
		}
		
		System.out.println(s.toString()); 
		//因為右邊 引數值的型別為String 優先抓到子類別中String 類別中 toString的方法
		System.out.println(str.toString());
		System.out.println("***********************");
		
		////////////////////////////////////////////////////////////
		
		//Object s
		
		s = LocalDate.of(1991,11,22);
		System.out.println("日期:"+s);
		//System.out.println(s.getYear());編譯錯誤
		
		//轉型為 LocalDate 便能使用getYear()這個方法 getYear找出年分
		if(s instanceof LocalDate)
		{
			LocalDate dateTest = (LocalDate)s; //轉型為:LoaclDate後指派給 dateTest參數
			System.out.println("轉型方法一後的年份: "+((LocalDate)s).getYear());
			System.out.println("轉型方法二後的年份: "+dateTest.getYear());
			//轉型為 LocalDate 便能使用getMonth()這個方法 getMonth找出年分
			System.out.println("轉型方法一後的月份: "+((LocalDate)s).getMonthValue());
			
		}
		
		
		s = LocalDate.parse("1991-11-22");
		System.out.println(s);
		
		
		
		System.out.println(s.getClass().getName()); //packge位置
		System.out.println("***********************");

		
		
	}

}
