package farmily.gtf.test;

import farmily.gtf.entity.CartItem;
import farmily.gtf.entity.Customer;
import farmily.gtf.entity.Order;
import farmily.gtf.entity.PaymentType;
import farmily.gtf.entity.Product;
import farmily.gtf.entity.ShippingType;
import farmily.gtf.entity.ShoppingCart;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;
import farmily.gtf.service.OrderService;
import farmily.gtf.service.ProductService;

public class TestOrderService_insert {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerService cService = new CustomerService();
		ProductService pService = new ProductService();
		
		try {
			Customer member = cService.login("A123456770","asdf12343");

			Product no2 = pService.getProductById("3");
			Product no13 = pService.getProductById("13");
			//加入購物車
			ShoppingCart cart = new ShoppingCart();
			cart.setMember(member);
			cart.add(no2,"紫", "", 1);
			cart.add(no2,"藍", "", 1);
			cart.add(no2,"紫", "", 2);
			cart.add(no2,"紫", "", 1);
			cart.add(no2,"藍", "", 2);
			cart.add(no2,"藍", "", 1);
			cart.add(no13,"", "", 1);
			
			//查詢購物車
			for(CartItem item:cart.getCartItemSet()) {
				System.out.println("本次買了 "+item.getProduct().getName()+"\t");
				System.out.println(item.getColor()==null?"":item.getColor().getColorName());
				System.out.println(item.getSize()+"\t");
				System.out.println(item.getProduct().getUnitPrice()+"元,\t");
				System.out.println(cart.getQuantity(item)+"個");
				//System.out.println(item.getProduct().getUnitPrice()*cart.getQuantity(item));			
				System.out.println("\t小計: "+cart.getAmount(item));
			}		
			System.out.println("共買了"+cart.size()+"項"+","+cart.getTotalQuantity()+"件");	
			System.out.println("總金額"+cart.getTotalAmount()+"元");
			System.out.println("cart是否為empty"+cart.isEmpty());
			
			int rowNo = 0;
			for(CartItem item:cart.getCartItemSet()) {
				rowNo++;
					if(rowNo==1) {
						cart.update(item, 3);
					}else if(rowNo==3){
						cart.remove(item);
					}
			}
			System.out.println("修改後");
			
			for(CartItem item:cart.getCartItemSet()) {
				System.out.println("本次買了 "+item.getProduct().getName()+"\t");
				System.out.println(item.getColor()==null?"":item.getColor().getColorName());
				System.out.println(item.getSize()+"\t");
				System.out.println(item.getProduct().getUnitPrice()+"元,\t");
				System.out.println(cart.getQuantity(item)+"個");
				//System.out.println(item.getProduct().getUnitPrice()*cart.getQuantity(item));			
				System.out.println("\t小計: "+cart.getAmount(item));
			}		
			System.out.println("共買了"+cart.size()+"項"+","+cart.getTotalQuantity()+"件");	
			System.out.println("總金額"+cart.getTotalAmount()+"元");
			System.out.println("cart是否為empty"+cart.isEmpty());
			//上方是 購物車明細
			
			//以下是訂單明細
			
			Order order = new Order();
			order.setMember(member);
			order.setPaymentType(PaymentType.ATM);
			order.setPaymentFee(PaymentType.ATM.getFee());
			
			order.setShippingType(ShippingType.HOME);
			order.setShippingFee(ShippingType.HOME.getFee());
			
			order.setRecipientName(member.getName());
			order.setRecipientEmail(member.getEmail());
			order.setRecipientPhone(member.getPhone());
			order.setShippingAddress(member.getAddress());
			
			order.add(cart);
			
			System.out.println("-----新增前----------------------------------------");
			
			System.out.println(order);
			
			OrderService oService = new OrderService();
			oService.insert(order);
			
			
			System.out.println("-----新增後----------------------------------------");
			System.out.println(order);

		
		} catch (GTFException e) {			
			e.printStackTrace();
		}	
	}

}
