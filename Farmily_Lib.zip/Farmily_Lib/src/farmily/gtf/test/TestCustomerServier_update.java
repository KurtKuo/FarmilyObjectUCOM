package farmily.gtf.test;

import java.util.logging.Level;
import java.util.logging.Logger;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;

public class TestCustomerServier_update {

	public static void main(String[] args) {
		CustomerService service = new CustomerService();
		try {
			
			Customer c = service.login("A123123123", "AAaa1234");
			
			System.out.println(c);
			

			c.setPassWord("AAaa1234");
//			c.setName("小宇");
			c.setGender(Customer.GENDER_MEN);
//			c.setEmail("test00@uuu.com.tw");
//			c.setBirthday("2000-01-05");
//			c.setAddress("台北市復興北路99號14F");
//			c.setPhone("02-25149191");
//			c.setSubscribed(true);
			
			service.update(c);
			
			System.out.println("****修改後****");

			Customer c2 = service.login("A123123123", c.getPassWord());
			
			System.out.println(c2);
			
		} catch (GTFDataInvalidException e) {
			System.err.println(e.getMessage());
		} catch (GTFException e) {
			Logger.getLogger("詳細的錯誤呈現").log(Level.SEVERE,e.getMessage(),e);
			}
		}
}
		