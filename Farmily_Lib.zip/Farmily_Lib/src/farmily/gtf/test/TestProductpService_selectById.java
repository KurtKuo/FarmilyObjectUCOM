package farmily.gtf.test;

import farmily.gtf.exception.GTFException;
import farmily.gtf.service.ProductService;

public class TestProductpService_selectById {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		ProductService pService = new ProductService();
		
		
		
		
		try {
			
			System.out.println("1號=================有尺寸沒顏色");
			System.out.println(pService.getProductById("1"));
			System.out.println("29號=================有尺寸有顏色");
			System.out.println(pService.getProductById("29"));
			
	
			
		} catch (GTFException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		
		
		
		
		
		
		
		
		
	}

}
