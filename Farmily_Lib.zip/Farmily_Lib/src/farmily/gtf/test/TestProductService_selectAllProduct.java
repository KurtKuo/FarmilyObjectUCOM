package farmily.gtf.test;

import java.util.List;

import farmily.gtf.entity.Product;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.ProductService;

public class TestProductService_selectAllProduct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//import farmily.gtf.service.ProductService;
		ProductService service = new ProductService();
		try {
			//List<Product> list = service.getAllProducts();
			//System.out.println(list);
			
			System.out.println(service.getPrductsByCategory("spring"));
		} catch (GTFException e) { //import farmily.gtf.exception.GTFException;
			// TODO Auto-generated catch block
			e.printStackTrace();
		}	
	}

}
