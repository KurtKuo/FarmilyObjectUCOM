package farmily.gtf.test;

import java.util.List;

import farmily.gtf.entity.Customer;
import farmily.gtf.entity.Order;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;
import farmily.gtf.service.OrderService;

public class TestOrderService_getOrderHistory {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		CustomerService cService = new CustomerService();
		
		Customer member;
		try {
			member = cService.login("A123456770", "asdf12343");
			OrderService oService = new OrderService();
			List<Order> list = oService.getOrderHistory(member.getId());
			
			System.out.println(list);
			
		}catch(GTFException e) {
			e.printStackTrace();
		}
	}

}
