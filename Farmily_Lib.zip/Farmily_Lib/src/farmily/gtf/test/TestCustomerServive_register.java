package farmily.gtf.test;
import java.util.logging.Level;
import java.util.logging.Logger;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFDataInvalidException;
import farmily.gtf.exception.GTFException;
import farmily.gtf.service.CustomerService;

public class TestCustomerServive_register {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Customer c = new Customer();
		try {
		c.setId("A112312212");
		c.setPassWord("asdf12343");
		c.setName("ss1s");
		c.setGender(Customer.GENDER_MEN);
		c.setEmail("tess22@uuu.com.tw");
		c.setBirthday("1990-01-03");
		c.setAddress("大直區");
		c.setPhone("0910112212");
		c.setSubscribed(true);
		
		
		CustomerService service = new CustomerService();
	
			service.register(c);
			Customer c2 = service.login("A123456770", "asdf12343");
			System.out.println(c2);
		} catch (GTFException e) {
			// TODO Auto-generated catch block
			//e.printStackTrace();
			Logger.getLogger("呈現詳細的錯誤訊息").log(Level.SEVERE,e.getMessage(),e);	
		
		//catch (GTFException e||GTFDataInvalidException e)
	}catch (GTFDataInvalidException e){
		System.err.println(e.getMessage());
		}
	}
}