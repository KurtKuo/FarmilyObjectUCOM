package farmily.gtf.test;

import farmily.gtf.entity.Product;

public class TestProduct {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Product product = new Product(); //建構子
		
//		System.out.println(productMen.getId());//0
//		System.out.println(productMen.getName());//null
//		System.out.println(productMen.getUnitPrice());//0.0
//		System.out.println(productMen.getStock());//0
//		System.out.println(productMen.getDescription());//null
//		System.out.println(productMen.getPhotoUrl());//null
//		System.out.println(productMen.getShelfDate());//null
	
		
		
		product.setId(1);
		product.setName("極速開發 Java大型系統：Spring Boot又輕又快又好學");
		product.setUnitPrice(880);
		product.setStock(12);
		
		
		Product product2 = new Product(2,"超級好書",880,12);
//		System.out.println(productMen2.getId());
//		System.out.println(productMen2.getName());
//		System.out.println(productMen2.getUnitPrice());
//		System.out.println(productMen2.getStock());
//		System.out.println(productMen2.getDescription());
//		System.out.println(productMen2.getPhotoUrl());
//		System.out.println(productMen2.getShelfDate());
		
		
		
		
		Product product3 = new Product(3,"超級好書2",1000,20);
//		System.out.println(productMen3.getId());
//		System.out.println(productMen3.getName());
//		System.out.println(productMen3.getUnitPrice());
//		System.out.println(productMen3.getStock());
//		System.out.println(productMen3.getDescription());
//		System.out.println(productMen3.getPhotoUrl());
//		System.out.println(productMen3.getShelfDate());
		
		//利用override方法測試
		System.out.println(product.toString());
		System.out.println(product2.toString());
		System.out.println(product3.toString());
		
		
		
	}

}
