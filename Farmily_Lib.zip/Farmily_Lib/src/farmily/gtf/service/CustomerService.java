package farmily.gtf.service;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFException;

public class CustomerService {
	//此變數參考至 CustomerDAO這個類別
	private CustomerDAO dao = new CustomerDAO();//delegation代理人
	//import import farmily.gtf.entity.Customer;
	public Customer login(String id, String pwd) throws GTFException{
		if(id==null || id.length()==0|| pwd==null || pwd.length()==0) {
			throw new IllegalArgumentException("會員登入時，必須輸入帳號和密碼");		
			//uncheckedException 不需要 throws 檢查是否有異常輸入參數不能為empty或者null
		}
		Customer c = dao.selectCustomerById(id);
		
		
		//檢查密碼
		if(c!=null && pwd.equals(c.getPassWord())) {
			return c;
		}else {
			//TODO: 拋出checkedException錯誤
			throw new GTFException("登入失敗，帳號或密碼不正確");
			//RuntimeException 改為 GTFException 
			//只要是使用者錯誤 皆用自己定義的Exception
//			if(c==null) {
//				throw new GTFException("登入失敗，帳號不正確");
//			}else {
//				throw new GTFException("登入失敗，密碼不正確");
//			}
		}
		//return c;
	}
	
	//註冊
	
	public void register(Customer customer)throws GTFException{
		if(customer==null) throw new IllegalArgumentException("客戶註冊時，客戶物件不得為null");
		
		//新增
		dao.insert(customer);	
	}
	
	
	//修改
	
	public void update(Customer customer)throws GTFException{
		if(customer==null) throw new IllegalArgumentException("客戶修改會員資料時，客戶物件不得為null");
		
		//修改
		dao.update(customer);
		
	}
	
	public Customer useEmailLogin(String email)throws GTFException{
		if(email==null) throw new IllegalArgumentException("客戶登入會員資料時，客戶物件不得為null");
		
		//修改
		Customer c = dao.selectCustomerById(email);
		return c;
	}
	
	
	public void forgetPassword(Customer email)throws GTFException{
		if(email==null) throw new IllegalArgumentException("客戶更新密碼會員資料時，客戶物件不得為null");
		
		//利用email登入後修改
		dao.UPdatePasswordByEmail(email);
	}

	
}
