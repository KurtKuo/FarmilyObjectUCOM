package farmily.gtf.service;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import farmily.gtf.entity.Color;
import farmily.gtf.entity.Outlet;
import farmily.gtf.entity.Product;
import farmily.gtf.entity.Size;
import farmily.gtf.exception.GTFException;



class ProductDAO {
	private static final String SELECT_ALL_PRODUCTS="SELECT id, name, unit_price,"
			+"photo_url, stock, description, category, discount, products_type "
			+ "FROM products";
	//資料庫的方法存取權限皆不可以用public
	List<Product> selectAllProducts()throws GTFException{
		List<Product> list = new ArrayList<>(); //import java.util.ArrayList; 介面
		try (
				//import java.sql.Connection;
				Connection connection = RDBConnection.getConnection();//1.2取得連線
				//import java.sql.PreparedStatement;
				PreparedStatement pstmt = connection.prepareStatement(SELECT_ALL_PRODUCTS);//3.準備指令
				//import java.sql.ResultSet;
				ResultSet rs =pstmt.executeQuery();//4.執行指令
				){
			while(rs.next()) {//5.處理rs
				Product p;
				int discount = rs.getInt("discount");
				if(discount>0) {
					//polymorphsim 上層型別建立成下層物件 使用下層類別方法
					p = new Outlet();
					((Outlet)p).setDiscount(discount);		
				}else {
					p = new Product();
				}
				p.setId(rs.getInt("id"));
				p.setName(rs.getString("name"));
				p.setDescription(rs.getString("description"));
				p.setUnitPrice(rs.getDouble("unit_price"));
				p.setPhotoUrl(rs.getString("photo_url"));
				p.setCategory(rs.getString("category"));
				p.setProducts_type(rs.getString("products_type"));
				p.setStock(rs.getInt("stock"));
				
				list.add(p); //將物件p值加入到list變數中
			}

		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new GTFException("查詢全部產品失敗！",e);
		}
		return list;
	}
	//產品查詢用
	private static final String SELECT_PRODUCTS_BY_CATEGORY ="SELECT id, name, unit_price, "
			+ "photo_url, stock, description, category, discount, products_type "
			+ "FROM products WHERE category = ?";
	
	
	//產品依照 all-season'spring'summer'fall'winter分類
	List<Product> selectProductsByCategroy(String catgory)throws GTFException{
		// TODO Auto-generated method stub
		List<Product> list = new ArrayList<>(); //import java.util.ArrayList;
		try ( 
				Connection connection = RDBConnection.getConnection();//1.2取得連線
				PreparedStatement pstmt = connection.prepareStatement(SELECT_PRODUCTS_BY_CATEGORY);//3.準備指令				
				){
			pstmt.setString(1, catgory);//3.1傳入?的值
			
			try( //這個try要自己加，將查詢後資料庫關閉，以免佔據記憶體
					ResultSet rs = pstmt.executeQuery();//4.執行指令 會回傳
					){
						//5.處理rs
						while(rs.next()) {
							Product p; //如果沒有折扣折建立 new Product();
							int discount = rs.getInt("discount");
							if(discount>0) {
								//polymorphsim 上層型別建立成下層物件 使用下層類別方法
								p = new Outlet();
								((Outlet)p).setDiscount(discount);		
							}else {
								p = new Product();
							}
							p.setId(rs.getInt("id"));
							p.setName(rs.getString("name"));
							p.setDescription(rs.getString("description"));
							p.setUnitPrice(rs.getDouble("unit_price"));
							p.setPhotoUrl(rs.getString("photo_url"));
							p.setCategory(rs.getString("category"));
							p.setProducts_type(rs.getString("products_type"));
							p.setStock(rs.getInt("stock"));
							
							list.add(p); //將物件p值加入到list變數中
						}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new GTFException("利用categroy分類查詢失敗！",e);
		}
		
		return list;
	}

	
	
	//產品型式
		private static final String SELECT_PRODUCTS_BY_PRODUCTSTYPE ="SELECT id, name, unit_price, "
				+ "photo_url, stock, description, category, discount, products_type "
				+ "FROM products WHERE products_type = ?";
	
	//產品依照 Product'Sapling'Vegetable'Fruit分類
	List<Product> selectProductsByProductsType(String productType)throws GTFException {
		// TODO Auto-generated method stub
		List<Product> list = new ArrayList<>(); //import java.util.ArrayList;
		try ( 
				Connection connection = RDBConnection.getConnection();//1.2取得連線
				PreparedStatement pstmt = connection.prepareStatement(SELECT_PRODUCTS_BY_PRODUCTSTYPE);//3.準備指令				
				){
			pstmt.setString(1, productType);//3.1傳入?的值
			
			try( //這個try要自己加，將查詢後資料庫關閉，以免佔據記憶體
					ResultSet rs = pstmt.executeQuery();//4.執行指令 會回傳
					){
						//5.處理rs
						while(rs.next()) {
							Product p;
							int discount = rs.getInt("discount");
							if(discount>0) {
								//polymorphsim 上層型別建立成下層物件 使用下層類別方法
								p = new Outlet();
								((Outlet)p).setDiscount(discount);		
							}else {
								p = new Product();
							}
							p.setId(rs.getInt("id"));
							p.setName(rs.getString("name"));
							p.setDescription(rs.getString("description"));
							p.setUnitPrice(rs.getDouble("unit_price"));
							p.setPhotoUrl(rs.getString("photo_url"));
							p.setCategory(rs.getString("category"));
							p.setProducts_type(rs.getString("products_type"));
							p.setStock(rs.getInt("stock"));
							
							list.add(p); //將物件p值加入到list變數中
						}
			}
		}catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new GTFException("利用products_type分類查詢失敗！",e);
		}
		return list;
	}
	
	//禮品
			private static final String SELECT_PRODUCTS_BY_GIFTBOX ="SELECT id, name, unit_price, "
					+ "photo_url, stock, description, category, discount, products_type, gift_Box  "
					+ "FROM products WHERE gift_Box = ?";
			//產品依照 Product'Sapling'Vegetable'Fruit分類
			List<Product> selectProductsByGiftBox(String gift_Box)throws GTFException {
				// TODO Auto-generated method stub
				List<Product> list = new ArrayList<>(); //import java.util.ArrayList;
				try ( 
						Connection connection = RDBConnection.getConnection();//1.2取得連線
						PreparedStatement pstmt = connection.prepareStatement(SELECT_PRODUCTS_BY_GIFTBOX);//3.準備指令				
						){
					pstmt.setString(1, gift_Box);//3.1傳入?的值
					
					try( //這個try要自己加，將查詢後資料庫關閉，以免佔據記憶體
							ResultSet rs = pstmt.executeQuery();//4.執行指令 會回傳
							){
								//5.處理rs
								while(rs.next()) {
									Product p;
									int discount = rs.getInt("discount");
									if(discount>0) {
										//polymorphsim 上層型別建立成下層物件 使用下層類別方法
										p = new Outlet();
										((Outlet)p).setDiscount(discount);		
									}else {
										p = new Product();
									}
									p.setId(rs.getInt("id"));
									p.setName(rs.getString("name"));
									p.setDescription(rs.getString("description"));
									p.setUnitPrice(rs.getDouble("unit_price"));
									p.setPhotoUrl(rs.getString("photo_url"));
									p.setCategory(rs.getString("category"));
									p.setProducts_type(rs.getString("products_type"));
									p.setStock(rs.getInt("stock"));
									p.setGiftBox(rs.getBoolean("gift_Box"));
									
									list.add(p); //將物件p值加入到list變數中
								}
					}
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new GTFException("利用products_type分類查詢失敗！",e);
				}
				return list;
			}

			
			//產地
			private static final String SELECT_PRODUCTS_BY_ORIGIN ="SELECT id, name, unit_price, "
					+ "photo_url, stock, description, category, discount, products_type, gift_Box, origin  "
					+ "FROM products WHERE origin = ?";
			//產品依照 Product'Sapling'Vegetable'Fruit分類
			List<Product> selectProductsByOrigin(String origin)throws GTFException {
				// TODO Auto-generated method stub
				List<Product> list = new ArrayList<>(); //import java.util.ArrayList;
				try ( 
						Connection connection = RDBConnection.getConnection();//1.2取得連線
						PreparedStatement pstmt = connection.prepareStatement(SELECT_PRODUCTS_BY_ORIGIN);//3.準備指令				
						){
					pstmt.setString(1, origin);//3.1傳入?的值
					
					try( //這個try要自己加，將查詢後資料庫關閉，以免佔據記憶體
							ResultSet rs = pstmt.executeQuery();//4.執行指令 會回傳
							){
								//5.處理rs
								while(rs.next()) {
									Product p;
									int discount = rs.getInt("discount");
									if(discount>0) {
										//polymorphsim 上層型別建立成下層物件 使用下層類別方法
										p = new Outlet();
										((Outlet)p).setDiscount(discount);		
									}else {
										p = new Product();
									}
									p.setId(rs.getInt("id"));
									p.setName(rs.getString("name"));
									p.setDescription(rs.getString("description"));
									p.setUnitPrice(rs.getDouble("unit_price"));
									p.setPhotoUrl(rs.getString("photo_url"));
									p.setCategory(rs.getString("category"));
									p.setProducts_type(rs.getString("products_type"));
									p.setStock(rs.getInt("stock"));
									p.setGiftBox(rs.getBoolean("gift_Box"));
									p.setOrigin(rs.getString("origin"));
									
									list.add(p); //將物件p值加入到list變數中
								}
					}
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new GTFException("利用origin產地查詢失敗！",e);
				}
				return list;
			}
			
			//上架日期分類
			private static final String SELECT_PRODUCTS_BY_NEWPRODUCTS ="SELECT  id, name, unit_price, stock,"
					+ " description, photo_url, shelf_date, category, discount, products_type, gift_Box, origin \n"
					+ "	FROM products "
					+ " order by shelf_date desc limit 12";

			List<Product> selectProductsByNewProducts(String newProducts)throws GTFException {
				// TODO Auto-generated method stub
				List<Product> list = new ArrayList<>(); //import java.util.ArrayList;
				try ( 
						Connection connection = RDBConnection.getConnection();//1.2取得連線
						PreparedStatement pstmt = connection.prepareStatement(SELECT_PRODUCTS_BY_NEWPRODUCTS);//3.準備指令	
						ResultSet rs = pstmt.executeQuery();//4.執行指令 會回傳
						){
					//pstmt.setString(1, limit);//3.1 沒有?只是執行不需要傳入?的值
					
				//這個try要自己加，將查詢後資料庫關閉，以免佔據記憶體
						
								//5.處理rs
								while(rs.next()) {
									Product p;
									int discount = rs.getInt("discount");
									if(discount>0) {
										//polymorphsim 上層型別建立成下層物件 使用下層類別方法
										p = new Outlet();
										((Outlet)p).setDiscount(discount);		
									}else {
										p = new Product();
									}
									p.setId(rs.getInt("id"));
									p.setName(rs.getString("name"));
									p.setDescription(rs.getString("description"));
									p.setUnitPrice(rs.getDouble("unit_price"));
									p.setPhotoUrl(rs.getString("photo_url"));
									p.setCategory(rs.getString("category"));
									p.setProducts_type(rs.getString("products_type"));
									p.setStock(rs.getInt("stock"));
									p.setGiftBox(rs.getBoolean("gift_Box"));
									p.setOrigin(rs.getString("origin"));
									
									list.add(p); //將物件p值加入到list變數中
								}
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new GTFException("利用newProducts最新商品查詢失敗！",e);
				}
				return list;
			}

			//特價商品查詢
			private static final String SELECT_PRODUCTS_BY_ONSALE ="SELECT  id, name, unit_price, stock,"
					+ " description, photo_url, shelf_date, category, discount, products_type, gift_Box, origin \n"
					+ "	FROM products "
					+ "	WHERE discount > 14 "
					+ " order by discount desc limit 12";

			List<Product> selectProductsByOnSale(String onSale)throws GTFException {
				// TODO Auto-generated method stub
				List<Product> list = new ArrayList<>(); //import java.util.ArrayList;
				try ( 
						Connection connection = RDBConnection.getConnection();//1.2取得連線
						PreparedStatement pstmt = connection.prepareStatement(SELECT_PRODUCTS_BY_ONSALE);//3.準備指令	
						ResultSet rs = pstmt.executeQuery();//4.執行指令 會回傳
						){
					//pstmt.setString(1, limit);//3.1 沒有?只是執行不需要傳入?的值
					
				//這個try要自己加，將查詢後資料庫關閉，以免佔據記憶體
						
								//5.處理rs
								while(rs.next()) {
									Product p;
									int discount = rs.getInt("discount");
									if(discount>0) {
										//polymorphsim 上層型別建立成下層物件 使用下層類別方法
										p = new Outlet();
										((Outlet)p).setDiscount(discount);		
									}else {
										p = new Product();
									}
									p.setId(rs.getInt("id"));
									p.setName(rs.getString("name"));
									p.setDescription(rs.getString("description"));
									p.setUnitPrice(rs.getDouble("unit_price"));
									p.setPhotoUrl(rs.getString("photo_url"));
									p.setCategory(rs.getString("category"));
									p.setProducts_type(rs.getString("products_type"));
									p.setStock(rs.getInt("stock"));
									p.setGiftBox(rs.getBoolean("gift_Box"));
									p.setOrigin(rs.getString("origin"));
									
									list.add(p); //將物件p值加入到list變數中
								}
				}catch (SQLException e) {
					// TODO Auto-generated catch block
					throw new GTFException("利用onSale特價商品查詢失敗！",e);
				}
				return list;
			}
			
			

	
//	private static final String SELECT_PRODUCT_BY_ID="SELECT id, name, unit_price,"
//			+ " stock, description, photo_url,"
//			+ " shelf_date, category, discount, products_type "
//			+ " FROM products WHERE id = ?";
	private static final String SELECT_PRODUCT_BY_ID="SELECT id, name, unit_price, products.stock, description, products.photo_url,"
			+ " products.shelf_date, category, discount, products_type ,"
			+ " color_name, product_colors.stock as color_stock, "
			+ " product_colors.photo_url as color_photo, "
			+ " product_colors.shelf_date as color_shelf_date,icon_url "
			+ " FROM products LEFT JOIN product_colors "
			+ "	ON products.id = product_colors.product_id "
			+ " WHERE products.id = ?";
	
	
	
	//JOIN
	private static final String SELECT_PRODUCT_BY_ID_USING_JOIN ="SELECT id, name,size,"
			+ " IFNULL(product_colors.color_name,'') as the_color_name, product_color_sizes.color_name, "
			+ " product_colors.stock as color_stock, "
			+ "	products.unit_price, products.stock, description, "
			+ "	products.photo_url, products.shelf_date, category, discount,"
			+ "	product_colors.photo_url as color_photo,"
			+ " product_colors.shelf_date as color_shelf_date,icon_url,"
			+ " product_color_sizes.stock as size_stock, product_color_sizes.unit_price as size_price,"
			+ " product_color_sizes.product_desciption "
			+ "  FROM products "
			+ "	  LEFT JOIN product_colors ON products.id=product_colors.product_id "
			+ "	  LEFT JOIN product_color_sizes ON products.id = product_color_sizes.product_id"
			+ "		AND ((product_colors.color_name = product_color_sizes.color_name) "
			+ "				OR(product_colors.color_name IS NULL AND product_color_sizes.color_name=''))"
			+ "		WHERE products.id =?"
			+ "        ORDER BY id, name,product_colors.color_name,size,ordinal"; 
	
	
	
	private static final String SELECT_PRODUCT_BY_ID_FROM_VIEW = 
			"SELECT pc_view.id, ps_view.the_color_name, size, "
			+ "	ps_view.name, ps_view.unit_price, ps_view.stock, ps_view.description, ps_view.photo_url, ps_view.shelf_date, ps_view.category, ps_view.discount,  "
			+ "    color_name, color_stock, color_photo, color_shelf_date, icon_url, "
			+ "	ps_view.the_color_name, ordinal, size_price, size_stock	 "
			+ "	FROM pc_view LEFT JOIN ps_view "
			+ "	ON pc_view.id = ps_view.id "
			+ "     AND pc_view.color_name = ps_view.the_color_name "
			+ "	WHERE pc_view.id = ? "
			+ "    ORDER BY ps_view.the_color_name, ordinal";
	
	
	
	
	private static final String SELECT_PRODUCT_BY_ID_TEST = "SELECT id, name,"
			+ "			product_colors.color_name, product_color_sizes.color_name as the_color_name,product_color_sizes.size, "
			+ "				product_colors.stock as color_stock, "
			+ "				products.unit_price, products.stock, description, "
			+ "				products.photo_url, products.shelf_date, category, discount, "
			+ "				product_colors.photo_url as color_photo, "
			+ "				product_colors.shelf_date as color_shelf_date,icon_url,\n"
			+ "				product_color_sizes.stock as size_stock, product_color_sizes.unit_price as size_price "
			+ "			  FROM products "
			+ "				  LEFT JOIN product_color_sizes ON products.id = product_color_sizes.product_id "
			+ "				  LEFT JOIN product_colors ON products.id=product_colors.product_id "
			+ "					AND (size OR(product_colors.color_name IS NULL AND product_color_sizes.color_name='')) "
			+ "				WHERE products.id = ? "
			+ "			        ORDER BY id, name,product_colors.color_name,ordinal ";
	
			

	Product selectProductById(String id) throws GTFException {
		Product p = null;		
		//用id去資料庫查詢1筆產品		
		try(
				Connection connection = RDBConnection.getConnection(); //1,2 取得連線
				PreparedStatement pstmt = connection.prepareStatement(SELECT_PRODUCT_BY_ID_USING_JOIN); //3. 準備指令
		) {			
			//3.1 傳入?的值
			pstmt.setString(1, id);			
			try(
				ResultSet rs = pstmt.executeQuery();//4.執行指令
			){
				//5.處理rs
				Color color=null;
				while(rs.next()) {
					int discount = rs.getInt("discount");
					if(p==null) {
						if(discount>0) {
							p = new Outlet();
							((Outlet)p).setDiscount(discount);
						}else {
							p = new Product();
						}
						
						p.setId(rs.getInt("id"));
						p.setName(rs.getString("name"));
						p.setUnitPrice(rs.getDouble("unit_price"));
						p.setStock(rs.getInt("stock"));
						p.setDescription(rs.getString("description"));
						p.setPhotoUrl(rs.getString("photo_url"));
						p.setShelfDate(rs.getString("shelf_date"));						
						p.setCategory(rs.getString("category"));
					}
					
					String colorName=rs.getString("the_color_name"); //測試用System.out.println(the_color_name);
					String size = rs.getString("size"); //測試System.out.println(size);
					
					if(size!=null || (size==null && colorName!=null && colorName.length()>0)) {
						if(color==null || (color!=null && !color.getColorName().equals(colorName))) {
							color = new Color();
							color.setColorName(colorName);
							color.setStock(rs.getInt("color_stock"));
							
							String colorPhoto = rs.getString("color_photo");
							if(colorPhoto!=null) {
								color.setPhotoUrl(colorPhoto);
							}else {
								color.setPhotoUrl(p.getPhotoUrl());
							}
							
							String iconUrl=rs.getString("icon_url");
							if(iconUrl!=null) {
								color.setIconUrl(iconUrl);
							}else {
								color.setIconUrl(color.getPhotoUrl());
							}
							System.out.println(color);
							p.addColor(color);
						}
						
						if(size!=null) {
							Size sizeObj = new Size();
							sizeObj.setColorName(color.getColorName());
							sizeObj.setSize(size);
							sizeObj.setPrice(rs.getDouble("size_price"));
							sizeObj.setStock(rs.getInt("size_stock"));
							sizeObj.setProduct_descrption(rs.getString("product_color_sizes.product_desciption"));
							//取得SIZE的備註
							color.addSize(sizeObj);
						}
					}
				}
				return p;
			}			
		} catch (SQLException e) {
			throw new GTFException("用id查詢產品失敗", e);
		}
	}
	
	
	private static final String SELECT_PRODUCT_BY_NAME="SELECT id, name, unit_price,"
			+ " stock, description, photo_url,"
			+ " shelf_date, category, discount, products_type "
			+ " FROM products WHERE name LIKE ?";
	
	List<Product> selectPrductsName(String search) throws GTFException {
		List<Product> list = new ArrayList<>();
		
		try (
				Connection connection = RDBConnection.getConnection(); //1.2建立連線
				PreparedStatement pstmt = connection.prepareStatement(SELECT_PRODUCT_BY_NAME);//2.準備指令
				){	
			pstmt.setString(1,'%'+search+'%');//3.1傳入?的值
			
			try( //這個try要自己加，將查詢後資料庫關閉，以免佔據記憶體
					ResultSet rs = pstmt.executeQuery();//4.執行指令 會回傳
					){
						//5.處理rs
						while(rs.next()) {
							Product p;
							int discount = rs.getInt("discount");
							if(discount>0) {
								//polymorphsim 上層型別建立成下層物件 使用下層類別方法
								p = new Outlet();
								((Outlet)p).setDiscount(discount);		
							}else {
								p = new Product();
							}
							p.setId(rs.getInt("id"));
							p.setName(rs.getString("name"));
							p.setDescription(rs.getString("description"));
							p.setUnitPrice(rs.getDouble("unit_price"));
							p.setPhotoUrl(rs.getString("photo_url"));
							p.setCategory(rs.getString("category"));
							p.setProducts_type(rs.getString("products_type"));
							p.setStock(rs.getInt("stock"));
							
							list.add(p); //將物件p值加入到list變數中
						}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new GTFException("用[部分名稱]查詢產品失敗",e);
		}
	
		// TODO Auto-generated method stub
		return list;
	}

	
	
	
	private static final String SELECT_RealTime_STOCK_BY_PRODUCT_ID="SELECT id,stock"
			+ " FROM products "
			+ " WHERE id=?";
	int selectRealTimeStock(int id) throws GTFException{
		int stock=0;		
		try (	Connection connection = RDBConnection.getConnection();//1,2
				PreparedStatement pstmt = connection.prepareStatement(SELECT_RealTime_STOCK_BY_PRODUCT_ID); //3
				){
			//3.1傳入?的值
			pstmt.setInt(1, id);
			
			//4.執行指令
			try(ResultSet rs=pstmt.executeQuery()){
				while(rs.next()) {
					stock = rs.getInt("stock");
				}
			}
			return stock;
		} catch (SQLException e) {
			throw new GTFException("查詢(無顏色無尺寸)產品即時庫存失敗",e);
		}
		
	}	
	
	private static final String SELECT_RealTime_STOCK_BY_PRODUCT_ID_AND_COLOR=
			"SELECT product_id,stock FROM product_colors "
			+ "WHERE product_id=? AND color_name=?";
	int selectRealTimeStock(int id, String colorName) throws GTFException{
		int stock = 0;
		try (	Connection connection = RDBConnection.getConnection();//1,2
				PreparedStatement pstmt = connection.prepareStatement(SELECT_RealTime_STOCK_BY_PRODUCT_ID_AND_COLOR); //3
				){
			//3.1傳入?的值
			pstmt.setInt(1, id);
			pstmt.setString(2, colorName);
			
			//4.執行指令
			try(ResultSet rs=pstmt.executeQuery()){
				while(rs.next()) {
					stock = rs.getInt("stock");
				}
			}
			return stock;
		} catch (SQLException e) {
			throw new GTFException("查詢(有顏色無尺寸)產品即時庫存失敗",e);
		}
	}
	
	
	private static final String SELECT_RealTime_STOCK_BY_PRODUCT_ID_AND_COLOR_AND_SIZE=
			"SELECT product_id,stock FROM product_color_sizes "
			+ "WHERE product_id=? AND color_name=? AND size=?";
	
	int selectRealTimeStock(int id, String colorName, String size) throws GTFException{
		int stock = 0;
		try (	Connection connection = RDBConnection.getConnection();//1,2
				PreparedStatement pstmt = connection.prepareStatement(
						SELECT_RealTime_STOCK_BY_PRODUCT_ID_AND_COLOR_AND_SIZE); //3
				){
			//3.1傳入?的值
			pstmt.setInt(1, id);
			pstmt.setString(2, colorName);
			pstmt.setString(3, size);
			
			//4.執行指令
			try(ResultSet rs=pstmt.executeQuery()){
				while(rs.next()) {
					stock = rs.getInt("stock");
				}
			}
			return stock;
		} catch (SQLException e) {
			throw new GTFException("查詢(有尺寸)產品即時庫存失敗",e);
		}
	}
	
}
