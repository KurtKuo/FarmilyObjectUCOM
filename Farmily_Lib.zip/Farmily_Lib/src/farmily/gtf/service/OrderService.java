package farmily.gtf.service;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

import farmily.gtf.entity.Customer;
import farmily.gtf.entity.Order;
import farmily.gtf.entity.OrderStatusLog;
import farmily.gtf.exception.GTFException;


public class OrderService {
	
	private OrderDAO dao =  new OrderDAO();
	
	
	public void insert(Order order)throws GTFException{
		if(order==null)throw new IllegalArgumentException("建立訂單時失敗");
		dao.insert(order);
	}
	public List<Order> getOrderHistory(String memberId)throws GTFException{
		return dao.selectOrderHistory(memberId);
	}
	
	public Order getOrderById(String id,Customer member)throws GTFException {
		Order order = dao.selectOrderById(id);
		//如果非本人登入，無法查到別人訂單，非常重要
		if(order!=null&&member!=null&&member.equals(order.getMember())) {
		return order;
		}else {
			return null;
		}
	}
	//用status查利是訂單
	public List<Order> getOrderByStatus(String id,int status)throws GTFException {
		return dao.selectOrderByStatus(id,status);
	}

	
	//ATM轉帳 狀態1
	public void updateStatusToTransfered(Customer member, String orderId,
	           String bank, String last5, double amount,LocalDate TransferedDate, String TransferedTime) throws GTFException {
	        if(member==null || orderId==null || !orderId.matches("\\d+")) {
	           throw new IllegalArgumentException("通知轉帳時，member|orderId不得為null");
	        }
	       
	        StringBuilder paymentNote = new StringBuilder();
	        paymentNote.append(bank).append(", ").append(last5);
	        paymentNote.append(",轉帳金額:").append(amount);
	        paymentNote.append(",交易日期時間:").append(TransferedDate).append(" ").append(TransferedTime);
	 
	        dao.updateStatusToTransfered(Integer.parseInt(orderId), member.getId(), paymentNote.toString());
	}
	
	
	//信用卡付款 狀態2
	 public void updateStatusToPAID(int orderId, String customerId, String cardF6, String cardL4,
	            String auth, String paymentDate, String amount) throws GTFException {
	        StringBuilder paymentNote = new StringBuilder("信用卡號:");
	        paymentNote.append(cardF6==null?"4311-95":cardF6).append("**-****").append(cardL4==null?2222:cardL4);
	        paymentNote.append(",授權碼:").append(auth==null?"777777":auth);
	        paymentNote.append(",交易時間:").append(paymentDate==null?LocalDateTime.now():paymentDate);
//	        paymentNote.append(",刷卡金額:").append(amount);
	        System.out.println("orderId = " + orderId);
	        System.out.println("customerId = " + customerId);
	        System.out.println("paymentNote = " + paymentNote);
	        dao.updateStatusToPAID(orderId, customerId, paymentNote.toString());
	 }
	
	
	public List<OrderStatusLog> getOrderStatusLog(String orderId) throws GTFException{
		return dao.selectOrderStatusLog(orderId);	
	}
	
}
