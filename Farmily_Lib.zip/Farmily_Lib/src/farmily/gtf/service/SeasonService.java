package farmily.gtf.service;

import java.util.Calendar;
import java.util.Date;

public class SeasonService {
	
	public String  seasonCheck(String date) {
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(new Date());
		int year = cal.get(Calendar.YEAR);
		int month = cal.get(Calendar.MONTH) +1;
		int day = cal.get(Calendar.DAY_OF_MONTH);
		System.out.println(year + "-" + month + "-" + day);
		if(month==3||month==4||month==5) {
			date="春季";
			if(day<=15) {
				System.out.println("春初");
			}else {
				System.out.println("春末");
			}	
		}else if(month==6||month==7||month==8) {
			date="夏季";
			if(day<=15) {
				System.out.println("立夏");
			}else {
				System.out.println("大暑");
			}
		}else if(month==9||month==10||month==11) {
			date="秋季";
			if(day<=15) {
				System.out.println("立秋");
			}else {
				System.out.println("秋末");
			}
		}else if(month==12||month==1||month==2) {
			date="冬季";
			if(day<=15) {
				System.out.println("冬初");
			}else {
				System.out.println("冬末");
			}
		}
		return date;
	}
}