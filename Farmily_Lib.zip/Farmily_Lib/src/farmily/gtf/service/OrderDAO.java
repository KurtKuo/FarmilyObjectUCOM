package farmily.gtf.service;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;

import farmily.gtf.entity.Color;
import farmily.gtf.entity.Customer;
import farmily.gtf.entity.Order;
import farmily.gtf.entity.OrderItem;
import farmily.gtf.entity.OrderStatusLog;
import farmily.gtf.entity.PaymentType;
import farmily.gtf.entity.Product;
import farmily.gtf.entity.ShippingType;
import farmily.gtf.exception.GTFException;
import farmily.gtf.exception.GTFStockShortageException;

class OrderDAO {
	
	private static final String UPDATE_PRODUCT_STOCK="UPDATE products"
			+ " SET stock=stock-? WHERE stock>=? AND id=?";
	
	private static final String UPDATE_PRODUCT_COLORS_STOCK="UPDATE product_colors"
			+ " SET stock=stock-? WHERE stock>=? "
			+ "AND (product_id=? AND color_name=?)";
	
	private static final String UPDATE_PRODUCT_COLOR_SIZES_STOCK="UPDATE product_color_sizes"
			+ " SET stock=stock-? WHERE stock>=? "
			+ "AND (product_id=? AND color_name=? AND size=?);";	


	
	
	private static final String INSERT_ORDER="INSERT INTO orders"
			+ "(id, customer_id, order_date, order_time, "
			+ " payment_type, payment_fee, shipping_type, shipping_fee, "
			+ " recipient_name, recipient_email, recipient_phone, shipping_address, status)"
			+ "VALUES(?,?,?,?,?,?,?,?,?,?,?,?,0)";
	
	private static final String INSERT_ORDER_ITEM="INSERT INTO order_items "
			+ "(order_id, product_id, color_name, size, price, quantity) "
			+ "VALUES(?,?,?,?,?,?)";

	void insert(Order order)throws GTFException {
		
		try (
				//1.2取得連線
				Connection connection= RDBConnection.getConnection();
				PreparedStatement pstmt01 = connection.prepareStatement(UPDATE_PRODUCT_STOCK);//3.準備指令 修改庫存1
				PreparedStatement pstmt02 = connection.prepareStatement(UPDATE_PRODUCT_COLORS_STOCK);//3.準備指令 修改庫存2
				PreparedStatement pstmt03 = connection.prepareStatement(UPDATE_PRODUCT_COLOR_SIZES_STOCK);//3.準備指令 修改庫存2

				
				PreparedStatement pstmt1= connection.prepareStatement(INSERT_ORDER, Statement.RETURN_GENERATED_KEYS); //3. 準備指令一 訂單 
				//RETURN_GENERATED_KEYS新增的自動給號透過 pstmt1物件帶回
				PreparedStatement pstmt2= connection.prepareStatement(INSERT_ORDER_ITEM);//3.準備指令二 訂單明細
				){	
					connection.setAutoCommit(false); //加入資料庫交易控制
					try {
						for(OrderItem item:order.getOrderItemSet()) {//一筆一筆修改庫存量
							int qty = item.getQuantity();
							Product p = item.getProduct();
							Color color = item.getColor();
							String size = item.getSize();
							PreparedStatement pt = null;
							if(color!=null && size!=null && size.length()>0) {
								pt = pstmt03;
								pt.setString(4, color.getColorName());
								pt.setString(5,size);
							}else if(color!=null && (size==null || size.length()>0)){
								pt = pstmt02;
								pt.setString(4, color.getColorName());
							}else {
								pt = pstmt01;
							}
							//3.1傳入前3筆三個共有的值
							pt.setInt(1, qty);
							pt.setInt(2, qty);
							pt.setInt(3, p.getId());
							
							//4.執行指令
							int row = pt.executeUpdate(); //查詢資料庫 底數回傳 
							if(row==0) { 
								throw new GTFStockShortageException(item);
							}
						}
						
						
						
					//先新增order
					//3.1傳入指令一
					pstmt1.setInt(1, order.getId());
					pstmt1.setString(2, order.getMember().getId());
					pstmt1.setString(3, order.getOrderDate().toString());
					pstmt1.setString(4, order.getOrderTime().toString());
					pstmt1.setString(5, order.getPaymentType().name());
					pstmt1.setDouble(6, order.getPaymentType().getFee());
					pstmt1.setString(7, order.getShippingType().name());
					pstmt1.setDouble(8, order.getShippingType().getFee());
					pstmt1.setString(9, order.getRecipientName());
					pstmt1.setString(10, order.getRecipientEmail());
					pstmt1.setString(11, order.getRecipientPhone());
					pstmt1.setString(12, order.getShippingAddress());
					
					//4.執行指令一
					pstmt1.executeUpdate(); //commit
			try(//2.取得order自動給號的值
			ResultSet rs = pstmt1.getGeneratedKeys(); // 取得自動給好的KEY
			){
			//5.處理rs
				while(rs.next()) {
					int orderId = rs.getInt(1);//將第一個位置的值(id) 指派給 orderId 
					order.setId(orderId); // 將找到的KEY傳給物件order					
				}
				
					//新增明細
					for(OrderItem orderItem:order.getOrderItemSet()) {
					//3.1傳入指令二的？ //(order_id, product_id, color_name, size, price, quantity)
		
					pstmt2.setInt(1, order.getId());
					pstmt2.setInt(2, orderItem.getProduct().getId());
					Color color = orderItem.getColor();
					pstmt2.setString(3, color!=null?color.getColorName():"");
					pstmt2.setString(4, orderItem.getSize());
					pstmt2.setDouble(5, orderItem.getPrice());
					pstmt2.setInt(6, orderItem.getQuantity());
					
					//4.執行指令二
					pstmt2.executeUpdate(); //commit
					}
			}
				connection.commit(); //付出
				}catch(Exception e){ 
					connection.rollback(); //回復
					throw e;
				}finally {
					connection.setAutoCommit(true);
				}//connection.setAutoCommit>>
					
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new GTFException("建立訂單失敗",e);
		}
		
	}
	
	//以會員查詢訂單
	private static final String SELECT_ORDER_BY_MEMBER_ID="SELECT id,order_date, order_time, status, "
			+ "		payment_type, payment_fee, "
			+ "	    shipping_type, shipping_fee, shipping_address, "
			+ "	    sum(price *quantity) total_amount "
		//	+ "	    ,(sum(price*quantity)+sum(payment_fee)+sum(shipping_fee)) as total_amount_fee "
			+ "    FROM orders "
			+ "    	LEFT JOIN order_items "
			+ "			ON orders.id = order_items.order_id	"
			+ "	WHERE customer_id=? "
			+ "    GROUP BY orders.id";

	List<Order> selectOrderHistory(String memberId) throws GTFException {
		List<Order> list = new ArrayList<>();

	try (
			//1.2建立連線
			
			
			Connection connection = RDBConnection.getConnection();
			PreparedStatement pstmt = connection.prepareStatement(SELECT_ORDER_BY_MEMBER_ID);//2.準備指令
			){
		//3.1傳值
		pstmt.setString(1, memberId);
			try(	
					//4.因為是查詢會有回傳，處理結果
					ResultSet rs = pstmt.executeQuery();
					){
					//5.尋找資料庫資料
					while(rs.next()) {
					Order order = new Order();
					order.setId(rs.getInt("id"));
					order.setOrderDate(LocalDate.parse(rs.getString("order_date")));
					order.setOrderTime(LocalTime.parse(rs.getString("order_time")));
					order.setStatus(rs.getInt("status"));
					
					String pType = rs.getString("payment_type");
					order.setPaymentType(PaymentType.valueOf(pType));
					order.setPaymentFee(rs.getDouble("payment_fee"));
					
					String shType = rs.getString("shipping_type");
					order.setShippingType(ShippingType.valueOf(shType));
					order.setShippingFee(rs.getDouble("shipping_fee"));
					
					order.setShippingAddress(rs.getString("shipping_address"));
					order.setTotalAmount(rs.getDouble("total_amount"));
					
					list.add(order);
					}
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			throw new GTFException("查詢歷史訂單失敗！",e);
		}
		// TODO Auto-generated method stub
		return list;
	}
	
	
	
	
	
	//以訂單查詢狀態
	private static final String SELECT_ORDER_BY_STATUS="SELECT id,order_date, order_time, status, "
			+ "		payment_type, payment_fee, "
			+ "	    shipping_type, shipping_fee, shipping_address, "
			+ "	    sum(price *quantity) total_amount "
		//	+ "	    ,(sum(price*quantity)+sum(payment_fee)+sum(shipping_fee)) as total_amount_fee "
			+ "    FROM orders "
			+ "    	LEFT JOIN order_items "
			+ "			ON orders.id = order_items.order_id	"
			+ "	WHERE customer_id=? AND status=? "
			+ "    GROUP BY orders.id";

    List<Order>  selectOrderByStatus(String id,int status) throws GTFException {
    	List<Order> list = new ArrayList<>();
		// TODO Auto-generated method stub
		try (
				//1.2建立連線
				Connection connection = RDBConnection.getConnection();
				PreparedStatement pstmt = connection.prepareStatement(SELECT_ORDER_BY_STATUS);//3.準備指令
				){
			//3.1傳值
			pstmt.setString(1, id);
			pstmt.setInt(2, status);
				try(	
						//4.因為是查詢會有回傳，處理結果
						ResultSet rs = pstmt.executeQuery();
						){
						//5.處理rs
						while(rs.next()) {
								Order order = new Order();
								order.setId(rs.getInt("id"));
								order.setOrderDate(LocalDate.parse(rs.getString("order_date")));
								order.setOrderTime(LocalTime.parse(rs.getString("order_time")));
								order.setStatus(rs.getInt("status"));
								
								String pType = rs.getString("payment_type");
								order.setPaymentType(PaymentType.valueOf(pType));
								order.setPaymentFee(rs.getDouble("payment_fee"));
								
								String shType = rs.getString("shipping_type");
								order.setShippingType(ShippingType.valueOf(shType));
								order.setShippingFee(rs.getDouble("shipping_fee"));
								
								order.setShippingAddress(rs.getString("shipping_address"));
								order.setTotalAmount(rs.getDouble("total_amount"));
								
								list.add(order);
						}
				}		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new GTFException("利用Status查詢歷史明細失敗！",e);
			}	
		return list;
	}
	
	
	
	
  //以訂單編號查訂單內容
	private static final String SELECT_ORDER_BY_ID="SELECT orders.id, customer_id, order_date, order_time, status,  "
			+ "	payment_type, payment_fee, payment_note,  "
			+ "    shipping_type, shipping_fee, shipping_note,  "
			+ "    recipient_name, recipient_email, recipient_phone, shipping_address,  "
			+ "    order_id, order_items.product_id, "
			+ "	   products.name, products.photo_url,"
			+ "     order_items.color_name,product_colors.photo_url as color_photo, "
			+ "        size, price, quantity "
			+ "  FROM orders  "
			+ "	   LEFT JOIN order_items ON orders.id=order_items.order_id "
			+ "    LEFT JOIN products ON order_items.product_id = products.id "
			+ "    LEFT JOIN product_colors ON order_items.product_id = product_colors.product_id  "
			+ "					AND order_items.color_name = product_colors.color_name "
			+ "  WHERE orders.id=?";

	Order selectOrderById(String id) throws GTFException {
		Order order=null;
		// TODO Auto-generated method stub
		try (
				//1.2建立連線
				Connection connection = RDBConnection.getConnection();
				PreparedStatement pstmt = connection.prepareStatement(SELECT_ORDER_BY_ID);//3.準備指令
				){
			//3.1傳值
			pstmt.setString(1, id);
				try(	
						//4.因為是查詢會有回傳，處理結果
						ResultSet rs = pstmt.executeQuery();
						){
						//5.處理rs
						while(rs.next()) {
							if(order==null) {
								order = new Order();
								order.setId(rs.getInt("id"));
								
								Customer c = new Customer();
								c.setId(rs.getString("customer_id"));
								order.setMember(c);//這個帳號先存入order物件
								order.setOrderDate(LocalDate.parse(rs.getString("order_date")));
								order.setOrderTime(LocalTime.parse(rs.getString("order_time")));
								order.setStatus(rs.getInt("status"));
								
								String pType = rs.getString("payment_type");
								order.setPaymentType(PaymentType.valueOf(pType));
								order.setPaymentFee(rs.getDouble("payment_fee"));
								order.setPaymentNote(rs.getString("payment_note"));
								
								String shType = rs.getString("shipping_type");
								order.setShippingType(ShippingType.valueOf(shType));
								order.setShippingFee(rs.getDouble("shipping_fee"));
								order.setShippingNote(rs.getString("shipping_note"));
								
								order.setRecipientName(rs.getString("recipient_name"));
								order.setRecipientEmail(rs.getString("recipient_email"));
								order.setRecipientPhone(rs.getString("recipient_phone"));		
								order.setShippingAddress(rs.getString("shipping_address"));							
							}
							String orderId = rs.getString("order_id");
							if(orderId!=null) {
								OrderItem orderItem = new OrderItem();
								Product p = new Product();
								p.setId(rs.getInt("product_id"));
								p.setName(rs.getString("name"));
								p.setPhotoUrl(rs.getString("photo_url"));
								orderItem.setProduct(p);
								
								Color color = null;
								String colorName =rs.getString("color_name");
								if(colorName!=null && colorName.length()>0) {
									color = new Color();
									color.setColorName(colorName);
									color.setPhotoUrl(rs.getString("color_photo"));
									orderItem.setColor(color);
								}
								
								orderItem.setSize(rs.getString("size"));
								orderItem.setPrice(rs.getDouble("price"));
								orderItem.setQuantity(rs.getInt("quantity"));
								order.add(orderItem);
							
							}
						}
				}		
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				throw new GTFException("查詢訂單明細失敗！",e);
			}	
		return order;
	}
	
	//更改訂單狀態by選擇付款方式為 ATM
	private static final String UPDATE_STATUS_TO_TRANSFERED = "UPDATE orders SET status=1" //狀態設定為已轉帳
            + ", payment_note=? WHERE id=? AND customer_id=?"
            + " AND status=0" + " AND payment_type='" + PaymentType.ATM.name() + "'";

	 void updateStatusToTransfered(int orderId, String memberId, String paymentNote) throws GTFException {
	        try (Connection connection = RDBConnection.getConnection(); //2. 建立連線
	                PreparedStatement pstmt = connection.prepareStatement(UPDATE_STATUS_TO_TRANSFERED) //3. 準備指令
	                ) {
	            //3.1 傳入?的值
	            pstmt.setString(1, paymentNote);
	            pstmt.setInt(2, orderId);
	            pstmt.setString(3, memberId);
	 
	            //4. 執行指令
	            pstmt.executeUpdate();
	        } catch (SQLException ex) {
	            throw new GTFException("通知已轉帳失敗!", ex);
	        }   
	}
	
	 
	 //查詢訂單by狀態status
	 private static final String SELECT_ORDER_STATUS_LOG="SELECT order_id, update_time, old_status, new_status "
	    		+ "	FROM orders_log WHERE order_id=? "
	    		+ " AND old_status!=new_status;";
	    List<OrderStatusLog> selectOrderStatusLog(String orderId) throws GTFException{
	    	List<OrderStatusLog> list = new ArrayList<>();
	        try (Connection connection = RDBConnection.getConnection(); //2. 建立連線
	                PreparedStatement pstmt = connection.prepareStatement(SELECT_ORDER_STATUS_LOG) //3. 準備指令
	                ) {
	            //3.1 傳入?的值
	            pstmt.setString(1, orderId);
	            
	            try(ResultSet rs = pstmt.executeQuery()){
	            	while(rs.next()) {
	            		OrderStatusLog log = new OrderStatusLog();
	            		log.setOrderId(rs.getInt("order_id"));
	            		log.setUpdateTime(
	            				LocalDateTime.parse(rs.getString("update_time").replace(' ', 'T')));
	            		log.setOldStatus(rs.getInt("old_status"));
	            		log.setNewStatus(rs.getInt("new_status"));            		
	            		list.add(log);
	            	}
	            }
	    	return list;
	        } catch (SQLException ex) {
	            throw new GTFException("查詢訂單status log失敗!", ex);
	        }
	    }
	 
	 
	 
	  //更新訂單狀態status2就是已付款
	 private static final String UPDATE_STATUS_TO_ENTERED = "UPDATE orders SET status=2" //狀態設定為已付款
	            + ", payment_note=? WHERE id=? AND customer_id=?"
	            + " AND status=0" + " AND payment_type='" + PaymentType.CARD.name() + "'";
	 
	    public void updateStatusToPAID(int orderId, String customerId, String paymentNote) throws GTFException {
	        try (Connection connection = RDBConnection.getConnection(); //2. 建立連線
	                PreparedStatement pstmt = connection.prepareStatement(UPDATE_STATUS_TO_ENTERED) //3. 準備指令
	                ) {
	            //3.1 傳入?的值
	            pstmt.setString(1, paymentNote);
	            pstmt.setInt(2, orderId);
	            pstmt.setString(3, customerId);
	 
	            //4. 執行指令
	            pstmt.executeUpdate();
	        } catch (SQLException ex) {
	            System.out.println("修改信用卡付款入帳狀態失敗-" + ex);
	            throw new GTFException("修改信用卡付款入帳狀態失敗!", ex);
	        }
	    }
	
	
	    
	    
	    
	    
}
