package farmily.gtf.service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import farmily.gtf.exception.GTFException;



class RDBConnection {
	//Relational database 關聯式資料庫
	private static final String driver = "com.mysql.cj.jdbc.Driver"; //mysql 8.0後
	//jdbc:mysql://localhost:3306/gtf?serverTimezone=Asia/Taipei  //CST是中原標準時間 ' or UTC(全球) or GMT+8=(HK)
	private static final String url = "jdbc:mysql://localhost:3306/gtf";
	private static final String userId = "root";						//可以預設不打時間					
	private static final String pwd = "Aa27909055aA";
	
	//static method使用時，不需要 建立物件 就可以使用
	static Connection getConnection() throws GTFException{
		try {
            Context ctx = new InitialContext();
            //建立一個Context物件，InitialContext 能夠查詢最初連線位置與名稱
            //import javax.naming.Context; import javax.naming.InitialContext;
            
            if (ctx == null) {
                throw new GTFException("無法取得JNDI Context.");
            }
            //import javax.sql.DataSource;
            DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/farmily");
            //lookup找尋參數中所參考的類別，並建立一個該類別的物件 需轉型
            if (ds == null) {
                throw new RuntimeException("DataSource could not be found.");
            }

            Connection connection = ds.getConnection();

            System.out.println("從Connection Pool取得Connection:" + connection);

            return connection;

        } catch (Exception ex) {
        	//import java.util.logging.Logger;  import java.util.logging.Level;
            Logger.getLogger("RDBConnection").log(
            //Logger物件使用getLogger方法，取得異常問題顯示於Consale
                   Level.INFO, "從Connection Pool取得連線失敗，將從一般方式連線", ex);
            //SEVERE (highest value) WARNING INFO  CONFIG  FINE FINER  FINEST (lowest value)
            
		try {
			Class.forName(driver); //1.載入driver
			try {	
				Connection connection = DriverManager.getConnection(url,userId,pwd);//2.建立連線
				//DriverManager具備連線該廠牌練線能力
				//import java.sql.DriverManager;
				//import java.sql.Connection;
				return connection;
			} catch (SQLException e) {
				//e.printStackTrace();
				throw new GTFException("建立連線失敗"+e);
			}	
		} catch (ClassNotFoundException e) {
			//e.printStackTrace();
			throw new GTFException("載入Driver失敗，找不到"+driver);
		}
	}
	}
}
