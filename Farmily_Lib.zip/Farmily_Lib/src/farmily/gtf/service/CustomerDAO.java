package farmily.gtf.service;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.SQLIntegrityConstraintViolationException;

import farmily.gtf.entity.Customer;
import farmily.gtf.exception.GTFException;

class CustomerDAO {
		//載入diver用，不在原始程式庫內<此為外掛>
		//必須程式先放盡lib 資料夾，並部署Build Path JDBC
//		private static final String driver = "com.mysql.cj.jdbc.Driver"; //mysql 8.0後
		
		//jdbc:mysql://localhost:3306/gtf?serverTimezone=Asia/Taipei  //CST是中原標準時間 ' or UTC(全球) or GMT+8=(HK)
//		private static final String url = "jdbc:mysql://localhost:3306/gtf";
		//url 需要提供廠牌；位置；埠號；以及資料名稱 mySQL預設localhost:3306
//		private static final String userId = "root";								
//		private static final String pwd = "Aa27909055aA";
	
	
		//***MySQL資料庫	 查詢
		//error：訊息Your have an error in your SQL syntax.SQL語法有錯
		//SELECT-FROM-WHERE；換行一定要加空白，不然會連在一起導致語法錯誤
		private static final String SELECT_CUSTOMERS = "SELECT id,password,name,gender,birthday,email,"/*這個之後包含資料庫要做修改*/
				+"address,phone,subscribed " //這邊必須加入空白
				+"FROM customers WHERE id=? OR email=?";
		//id來查詢 程式開始
		Customer selectCustomerById(String id) throws GTFException{
		Customer c = null;//預設沒有查詢到任何東西，先不把物件建立起來 不需浪費任何Heap記憶體		
//		try {
//			Class.forName(driver);//1.載入Driver	//只要為Java以外的程式必須用try-catch
			try(	
					//放入try() 內 為執行完關閉
					//Connection connection = DriverManager.getConnection(url,userId,pwd);//2.建立連線
					Connection connection = RDBConnection.getConnection();	
					//利用RDBConnection方法 內 Class.forName(driver) 跟 DriverManager.Connection 取得連線
					PreparedStatement pstmt = connection.prepareStatement(SELECT_CUSTOMERS);//3.準備指令
					//import java.sql.PreparedStatement;
					//PreparedStatement的 executeUpdate() 方法可用來建立、修正、刪除資料； 不會回傳  
					//而 PreparedStatement的 executeQuery() 方法可用來查詢資料。會回傳
			){
				//3.1 傳入?的值
				pstmt.setString(1, id);
				pstmt.setString(2, id); //加入以email做登入
				
				//import java.sql.PreparedStatement 內部方法 setString//將上方第一個? 載入變數id內
				//rs前端結果 executeQuery 後端執行
				try( ResultSet rs = pstmt.executeQuery(); //4.執行指令 與下方executeUpdate不同 此會回傳值
					//import java.sql.ResultSet
					//executeQuery 執行詢問 為ResultSet類別中的方法
				){	//5.處理rs
					while(rs.next()){ //ResultSet 中的next() 移至下一筆資料
						c = new Customer();
						//34行先預設沒有查詢到東西
						//等有查詢到資料後此行為建立heap記憶體的物件以便存取後續SQL資料
						//setId...為物件c參考Customer類別之方法
						c.setId(rs.getString("id"));
						c.setPassWord(rs.getString("password"));
						c.setName(rs.getString("name"));
						c.setGender(rs.getString("gender").charAt(0)); //"M".charAt(0)->'M'
						c.setBirthday(rs.getString("birthday"));
						c.setEmail(rs.getString("email"));
						c.setAddress(rs.getString("address"));
						c.setPhone(rs.getString("phone"));
						c.setSubscribed(rs.getBoolean("subscribed"));
						/*血型判斷
						String bType = rs.getString("blood_type");						
						if(bType!=null) {
							c.setBloodType(BloodType.valueOf(bType));}	*/					
					}
				}//結束				
			} catch (SQLException e) {	
				//程式人員查看的錯誤方式
				//e.printStackTrace();// 改成拋出錯誤
				//此方法可以使前端看到 加上 ,e 可以把原因把原因加入
				//由原本RuntimeExcetion 改為 Exception 記得上方方法中加入 throws Exception
				//此方法為後端丟出訊息通知前端
				//GTFException = 自己定義自己網站的錯誤訊息提醒
				throw new GTFException("用ID查詢客戶失敗",e);//指令傳值or執行失敗or讀取rs
			}	
			return c;
//		} catch (ClassNotFoundException e) {			
//			//e.printStackTrace();// TODO 拋出錯誤
//			throw new GTFException("載入Diver失敗，找不到"+driver);
//		} 				
		}
		
		
	//***MySQL資料庫	 新增 即為註冊用
	private static final String INSERT_CUSTOMER="INSERT INTO customers "
			+ "(id, password, name, gender, birthday, email, address, phone, subscribed) "
			+ "VALUES(?,?,?,?,?,?,?,?,?)";
	
	//以下為新增程式 void 不回傳
 	void insert(Customer c) throws GTFException{	
 		
 		try (
 				Connection connection = RDBConnection.getConnection();
 		 		//透過RDBConnection中的 第1,第2 步驟取得連線
 				PreparedStatement pstmt = connection.prepareStatement(INSERT_CUSTOMER);//3.準備指令
 				){
 			//3.1 傳入?的值
			pstmt.setString(1, c.getId());
			pstmt.setString(2, c.getPassWord());
			pstmt.setString(3, c.getName());
			pstmt.setString(4, String.valueOf(c.getGender()));//基本型別轉字串
			pstmt.setString(5, String.valueOf(c.getBirthday()));//此方法較安全,為null 也可以印出
			//pstmt.setString(5, c.getBirthday().toString());//類別型別轉字串LocalDate 遇到null則不可以執行
			pstmt.setString(6, c.getEmail());
			pstmt.setString(7, c.getAddress());
			pstmt.setString(8, c.getPhone());
			pstmt.setBoolean(9, c.isSubscribed());
 			//pstmt.setString(10, c.getBloodType()!=null?c.getBliidType().name:null); 血型
 			pstmt.executeUpdate();//4.執行指令 與executeQuery不同 此方法不回傳結果

 		}catch (SQLIntegrityConstraintViolationException e) { //PKey|Unique Index重複 //子類別必須先處理
 			String msg = e.getMessage(); //將錯誤訊息指派給區域變數 msg
 			if(msg.indexOf("email_UNIQUE")>0) { //IndexOf由前面往後找
 				throw new GTFException("新增客戶失敗-email重複註冊");
 			}else if(msg.lastIndexOf("PRIMARY")>0) { //lastIndexOf由最後往前找
 				throw new GTFException("新增客戶失敗-ID重複註冊");
 			}else {
 				throw new GTFException("新增客戶失敗-" + e.getMessage(), e);//null
 			}
		} catch (SQLException e) {//SQLIntegrityConstraintViolationException 為SQLException 子類別	
			throw new GTFException("新增客戶失敗",e);
		}
 	}	
 	
 	private static final String UPDATE_CUSTOMER="UPDATE customers "
			+ "	SET password=?, name=?, gender=?, "
			+ "  birthday=?, email=?, "
			+ "  address=?, phone=?, subscribed=? "
			+ " WHERE id=?";

 	//以下為修改程式 
 	void update(Customer c) throws GTFException{
 		try (
 				Connection connection = RDBConnection.getConnection(); //1.2建立取得連線
 				PreparedStatement pstmt= connection.prepareStatement(UPDATE_CUSTOMER);	//3.準備指令
 				){
 			//依照資料庫 ? 索引值 順序
 			pstmt.setString(1, c.getPassWord());
 			pstmt.setString(2, c.getName());
 			pstmt.setString(3, String.valueOf(c.getGender()));
 			pstmt.setString(4, String.valueOf(c.getBirthday()));
 			pstmt.setString(5, c.getEmail());
 			pstmt.setString(6, c.getAddress());
 			pstmt.setString(7, c.getPhone());
 			pstmt.setBoolean(8, c.isSubscribed());
 			pstmt.setString(9, c.getId());
 			
 			int rows = pstmt.executeUpdate();//4.執行指令 PreparedStatment裏面方法
 			//executeUpdate 建立後回傳SQL內參數 回傳型別int	
			
		} catch (SQLIntegrityConstraintViolationException e) { //PK or UN重複
			e.printStackTrace();
			String msg =  e.getMessage();
			if(msg.indexOf("email_UNIQUE")>0) {
				throw new GTFException("修改客戶資料失敗-email重複註冊");	
			}else if(msg.indexOf("PRIMARY")>0) {
				throw new GTFException("修改客戶資料失敗-ID重複註冊");	
			}else {
				throw new GTFException("修改客戶資料失敗-"+e.getMessage(),e);//null
			}
		}catch(SQLException e) {//SQLIntegrityConstraintViolationException 為SQLException 子類別
			throw new GTFException("修改客戶資料失敗-",e);
		}	
 	}
 	
 	
 	
 	
 	private static final String UPDATE_CUSTOMER_BY_EMAIL="UPDATE customers "
			+ "	SET password=? "
			+ " WHERE email=?";

 	//以下為修改程式 
 	void UPdatePasswordByEmail(Customer email) throws GTFException{
 		try (
 				Connection connection = RDBConnection.getConnection(); //1.2建立取得連線
 				PreparedStatement pstmt= connection.prepareStatement(UPDATE_CUSTOMER_BY_EMAIL);	//3.準備指令
 				){
 			//依照資料庫 ? 索引值 順序
 			pstmt.setString(1, email.getPassWord());
 			pstmt.setString(2, email.getEmail());
 			
 			pstmt.executeUpdate();//4.執行指令 PreparedStatment裏面方法
 			//executeUpdate 建立後回傳SQL內參數 回傳型別int	
			
		} catch (SQLIntegrityConstraintViolationException e) { //PK or UN重複
			e.printStackTrace();
		}catch(SQLException e) {//SQLIntegrityConstraintViolationException 為SQLException 子類別
			throw new GTFException("修改客戶資料失敗-",e);
		}	
 	}
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
 	
}
