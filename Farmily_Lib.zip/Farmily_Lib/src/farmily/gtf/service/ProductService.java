package farmily.gtf.service;

import java.util.List;

import farmily.gtf.entity.Color;
import farmily.gtf.entity.Product;
import farmily.gtf.exception.GTFException;

public class ProductService {
	private ProductDAO dao = new ProductDAO();
	//不同的判斷找尋資料
	public List<Product> getAllProducts() throws GTFException{
		return dao.selectAllProducts();
	}//全找
	public List<Product> getPrductsByCategory(String catgory) throws GTFException{
		return dao.selectProductsByCategroy(catgory);
	}//分類季節
	public List<Product> getPrductsByProductsType(String productType) throws GTFException{
		return dao.selectProductsByProductsType(productType);
	}//產品型式
	public List<Product> getProductsByGiftBox(String gift_Box) throws GTFException{
		return dao.selectProductsByGiftBox(gift_Box);
	}//禮品
	public List<Product> getProductsByOrigin(String origin) throws GTFException{
		return dao.selectProductsByOrigin(origin);
	}//產地
	public List<Product> getProductsByNewProducts(String newProducts) throws GTFException{
		return dao.selectProductsByNewProducts(newProducts);
	}//最新
	public List<Product> getProductsByOnSale(String onSale) throws GTFException{
		return dao.selectProductsByOnSale(onSale);
	}//特價
	
	public List<Product> getPrductsByName(String search) throws GTFException{
		return dao.selectPrductsName(search);
	}//名字搜尋

	
	public Product getProductById(String productId) throws GTFException{
		if(productId==null || productId.length()==0) throw new IllegalArgumentException("查詢產品時必須有產品編號，不得為空白或是null!");
		return dao.selectProductById(productId);
	}//購物車用單純用ID去找相對產品名稱
	

	
	public int getRealTimeStock(Product p,Color color,String size)throws GTFException{
		if(p==null) throw new IllegalArgumentException("查詢即時庫存時產品不得為null");
		int stock = 0;
		if(color==null) {
			stock = dao.selectRealTimeStock(p.getId());
		}else if(color!=null && size!=null && size.length()>0) {
			stock = dao.selectRealTimeStock(p.getId(),color.getColorName(),size);
		}else {
			stock = dao.selectRealTimeStock(p.getId(),color.getColorName());
		}	
		return stock;
	}
	
	
	
	
	
	//漲價程式 以後用不到
	public void addPrice(double price)
	{	
		//基本型別 double 要回傳至成員變數(屬性)才會印出 
		price  = price+10;
	}
	public void addPrice(Product p)
	{
		p.setUnitPrice(p.getUnitPrice()+10);
		//參考物件Product 
	}

	/*正確寫法	
	public double addPrice(Product p)
	{	
	return(p.getUnitPrice()+10);
	}	
	*/
	
}
