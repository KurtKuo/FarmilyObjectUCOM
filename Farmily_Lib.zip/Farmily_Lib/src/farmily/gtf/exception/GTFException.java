package farmily.gtf.exception;

public class GTFException extends Exception {

	public GTFException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public GTFException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public GTFException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}
	     
}
