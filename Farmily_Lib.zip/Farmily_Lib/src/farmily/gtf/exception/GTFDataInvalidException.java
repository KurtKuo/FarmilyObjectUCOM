package farmily.gtf.exception;

public class GTFDataInvalidException extends RuntimeException {

	public GTFDataInvalidException() {
		super();
	}

	public GTFDataInvalidException(String message, Throwable cause) {
		super(message, cause);
	}

	public GTFDataInvalidException(String message) {
		super(message);
	}

}
