package farmily.gtf.exception;

import farmily.gtf.entity.OrderItem;

public class GTFStockShortageException extends GTFException {
	private final OrderItem item; 
	private static final String msg="庫存不足"; 
	
	public GTFStockShortageException() {
		super(msg);
		item = null;
	}

	public GTFStockShortageException(OrderItem item) {
		super(msg);
		this.item = item;
	}

	public OrderItem getItem() {
		return item;
	}

}
