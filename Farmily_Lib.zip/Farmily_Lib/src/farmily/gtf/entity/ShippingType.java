package farmily.gtf.entity;

public enum ShippingType {
	SHOP("園區取貨"),
	HOME("送貨到府",100),
	STORE("超商取貨",60),//,UBER("UBER",40);
	PACKAGE("便利袋",10);//測試用
	
	private final String description; //blank final variable
	private final double fee;//blank final variable
//	private PaymentType() {
//		無參數建構子
//	}
	private ShippingType(String description) {	
		this(description,0);	
	}
	
	private ShippingType(String description,double fee) {
		this.description = description;
		this.fee = fee;
	}
	
/////////////////////////////////////////////////	
	
	public double getFee() {
		return fee;
	}
//	public void setFee(double fee) {
//		this.fee = fee; final
//	}必須在宣告時給值，不可以在後續才給值
	
/////////////////////////////////////////////////
	
	public String getDescription() {
		return description;
	}
/////////////////////////////////////////////////	

	@Override
	public String toString() {
		return  description + 
				(fee==0?"":("," + fee + "元"));		
	}

	
}