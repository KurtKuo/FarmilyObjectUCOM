package farmily.gtf.entity;

import java.util.List;



public class CartItem {
	
	private Product product;//PKEY
	private Color color;	//PKEY
	private String size ="";//PKEY
	
/////////////////////////////////////////////
	
	public Product getProduct() {
		return product;
	}
	public void setProduct(Product product) {
		this.product = product;
	}
	
/////////////////////////////////////////////	
	
	public Color getColor() {
		return color;
	}
	public void setColor(Color color) {
		this.color = color;
	}
	
	
/////////////////////////////////////////////	
	
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		if(size!=null) this.size = size;
	}
	
/////////////////////////////////////////////	
	
	public int getDiscount() {
		return product instanceof Outlet?((Outlet)product).getDiscount():0;
	}

/////////////////////////////////////////////	
	
	public double getListPrice() {		
		double listPrice =  product instanceof Outlet?((Outlet)product).getListPrice():product.getUnitPrice();
		
		if(this.getSize()!=null && this.getSize().length()>0 && this.getColor()!=null) {
			List<Size> list = this.getColor().getSizeList();
			for(Size s:list) {
				if(s.getSize().equals(this.getSize())) {
					listPrice = s.getPrice();
				}
			}
		}
		return listPrice;
	}
	
/////////////////////////////////////////////	
	
	public double getUnitPrice() {
		double unitPrice = product.getUnitPrice();
		
		if(this.getSize()!=null && this.getSize().length()>0 && this.getColor()!=null) {			
			unitPrice = getListPrice();
			if(product instanceof Outlet) 
				unitPrice = unitPrice * (100-((Outlet)product).getDiscount())/100;
		}
		return unitPrice;
	}

	
/////////////////////////////////////////////		
	@Override
	public String toString() {
		
		return this.getClass().getSimpleName() 
				+'\n'+"[購買產品]=" + product 
				+'\n'+"[購買顏色]=" + color
				+'\n'+"[購買尺寸]=" + size
				+'\n';
		
	}
	
/////////////////////////////////////////////
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((product == null) ? 0 : product.hashCode());
		result = prime * result + ((color == null) ? 0 : color.hashCode());	
		result = prime * result + ((size == null) ? 0 : size.hashCode());
		return result;
	}
		
/////////////////////////////////////////////	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		
		CartItem other = (CartItem) obj;
		if (color == null) {
			if (other.color != null)
				return false;
		} else if (!color.equals(other.color))
			return false;
		if (product == null) {
			if (other.product != null)
				return false;
		} else if (!product.equals(other.product))
			return false;
		if (size == null) {
			if (other.size != null)
				return false;
		} else if (!size.equals(other.size))
			return false;
		return true;
	}

}
