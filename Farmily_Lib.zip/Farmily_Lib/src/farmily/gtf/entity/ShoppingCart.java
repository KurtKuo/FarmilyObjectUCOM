package farmily.gtf.entity;

import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import farmily.gtf.exception.GTFDataInvalidException;

public class ShoppingCart {
	private Customer member;
	private Map<CartItem, Integer> cartItemMap = new HashMap<>();
	//一個散列表，沒有順序的 屬於集合，不可以加getter 與 setter
	//import java.util.HashMap;import java.util.Map;
	
//////////////////////////////////////////////
	
	public Customer getMember() {
		return member;
	}
	public void setMember(Customer member) {
		this.member = member;
	}

//////////////////////////////////////////////	
	
	//Map的setter=addCartItem.Update,Remove
	//前端傳的Form Data中加入購物車中選擇的值 productID color 尺寸 數量
	public void add(Product product,String colorName, String size,int quantity) {
		if(product==null) {
			throw new IllegalArgumentException("加入購物車產品不得為NULL!");
		}
		
		if(quantity>0) {
			Color theColor = null;
			if(colorName!=null && (colorName=colorName.trim()).length()>0) {
			List<Color> list = product.getColorList();
			
			if(list==null || list.size()==0) {
				throw new GTFDataInvalidException("此產品無顏色可選!不應有colorName!"+colorName);
			}
			
					for(Color color:list) {//for
							if(colorName.equals(color.getColorName())){
							theColor = color;
							break;
						}
					}//for
				if(theColor==null) {
					throw new GTFDataInvalidException(colorName+"不在此產品的顏色清單內，謝謝");
				}
			}else if(colorName!=null && (colorName=colorName.trim()).length()==0 //沒顏色有尺寸
					&& (product.getColorList()!=null && product.getColorList().size()==1 && product.getColorList().get(0).getColorName().length()==0)) {
				theColor=product.getColorList().get(0);
			}else if ((colorName==null || (colorName=colorName.trim()).length()==0) 
					&& (product.getColorList()!=null && product.getColorList().size()>0)) {	
				throw new GTFDataInvalidException("此產品有顏色清單，必須選擇顏色，謝謝");
			}
			
			CartItem item = new CartItem();
			item.setProduct(product);
			item.setColor(theColor);
			item.setSize(size);
			//找出是否購物車中已有這個item就是old quantity
			Integer oldQuantity = cartItemMap.get(item);
			if(oldQuantity!=null) 
				quantity += oldQuantity;
			
			cartItemMap.put(item , quantity);
			//購物車中沒有這個item就是add，購物車中已有這個item就是update value	
		}
	}
////////////////////////////////////////add method end
	
	public void update(CartItem cartItem,int qty) {
		Integer oldQuantity = cartItemMap.get(cartItem);
		if(oldQuantity==null) throw new GTFDataInvalidException("購物車無此購物明細，無法修改，謝謝");
		
		cartItemMap.put(cartItem, qty);
		//有舊的就覆蓋
		//沒有舊的就增加
	}
	
	public void remove(CartItem key) {
		cartItemMap.remove(key);
		
	}
	
//////////////////////////////////////////////	

	//Map的getter
	//用delegate method 寫getter
///////////////////////////////////////////////////////////delegate method
	
	public int size() {
		//list,set,map皆有此方法,傳回集合中的筆數
		return cartItemMap.size();
	}	
	
	public boolean isEmpty() {
		//list,set,map皆有方法，傳回集合是否為空集合
		return cartItemMap.isEmpty();
	}
	
///////////////////////////////////////////////////////////
	
	//利用KEY找到值 抓到KEY去找對應的值
	public Set<CartItem> getCartItemSet() { 
		//return (cartItem.Map.keySet()); //最不安全，可能被前端修改，在remove不是最後一筆時，會發生 java.util.ConcurrentMonificationException
		//map方法，傳回map中的keySet(在此例中為購物明細集合)
		//return cartItemMap.keySet(); //正本可以更改，不安全

		//安全作法1: 回傳內容不可改的集合
		//return Collection.unmodifiableSet(cartItem.Map.keySet());//傳回的集合被前端修改會發生return exception
		
		//安全作法2: 回傳集合複(副)本
		return new HashSet<>(cartItemMap.keySet()); //將正本集合複製，這樣正本才不會被修改或刪除，安全
	}
	
///////////////////////////////////////////////////////////
	
	public int getQuantity(CartItem key) {
		//map才有的方法，傳回map該筆KetSet對應的值(在此例中為購買數量)
		//產品件數
		Integer qty = cartItemMap.get(key);
		return qty!=null?qty:0;
	}	
	
///////////////////////////////////////////////////////////

	public double getUnitPrice(CartItem key) {
		return key.getUnitPrice();
	}
	//呼叫 CartItem.getUnitPrice//售價
	
///////////////////////////////////////////////////////////
	
	public double getListPrice(CartItem key) {	
		return key.getListPrice();
	}
	//呼叫 CartItem.getListPrice //原價
	
///////////////////////////////////////////////////////////
	
	public int getDiscount(CartItem key) {		
		return key.getDiscount();
	}
	//呼叫 CartItem.getDiscount //打折
	
///////////////////////////////////////////////////////////	
	
	public String getDiscountString(CartItem key) {
		int discount = 100-getDiscount(key);
		if(discount%10==0) discount /=10;
		return discount + "折";
	}
	
	
//////////////////////////////////////////////////////////
	
		//自訂 getter : getAmount(),getTotalQuantity(),getTotalAmount
		//小計
	public double getAmount(CartItem key) {
		return Math.round(getUnitPrice(key) * getQuantity(key));
	}

///////////////////////////////////////////////////////////	
	
	public int getTotalQuantity() {
		int sum=0;
		for(Integer qty:cartItemMap.values()){
			if(qty!=null) sum+=qty;
		}
		return sum;
	}

///////////////////////////////////////////////////////////	
	
	public double getTotalAmount() {
		double sum = 0;
		for(CartItem item:cartItemMap.keySet()) {
			sum += getAmount(item);
		}
		return Math.round(sum);
	}	
	
//////////////////////////////////////////////
	
	@Override
	public String toString() {
		return 
				"[購物車：訂購人]=" + member 
				+'\n'+"[購物明細]=" + cartItemMap
				+'\n';
	}
	
}
	
