package farmily.gtf.entity;

public enum Seasons {
	SPRING('春',"綠色"),SUMMER('夏',"黃色"),FALL('秋',"紅色"),WINTER('冬',"白色");
	
	private final char seasonCode;

	private final String seasonColorName;
	
	private Seasons(char seasonCode,String seasonColorName)
	{
		this.seasonCode = seasonCode;
		this.seasonColorName = seasonColorName;
	}
	
	public char getSeasonCode() {
		return seasonCode;
	}

	public String getSeasonColorName() {
		return seasonColorName;
	}

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()
				+"天"
				+'\n'
				+"是美好的季節阿";
		
	}
	
	
}
