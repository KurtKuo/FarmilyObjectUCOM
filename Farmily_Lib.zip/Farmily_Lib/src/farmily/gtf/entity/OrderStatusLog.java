package farmily.gtf.entity;

import java.time.LocalDateTime;

public class OrderStatusLog {
	private int orderId; //訂單編號
	private LocalDateTime updateTime; //更新時間
	private int oldStatus; //匯款舊狀態
	private int newStatus; //匯款新狀態
	
///////////////////////////////////////////////////	
	
	public int getOrderId() {
		return orderId;
	}
	public void setOrderId(int orderId) {
		this.orderId = orderId;
	}
	
///////////////////////////////////////////////////	
	
	public LocalDateTime getUpdateTime() {
		return updateTime;
	}
	
///////////////////////////////////////////////////		
	
	public void setUpdateTime(LocalDateTime updateTime) {
		this.updateTime = updateTime;
	}
	
///////////////////////////////////////////////////	
	
	public int getOldStatus() {
		return oldStatus;
	}
	public void setOldStatus(int oldStatus) {
		this.oldStatus = oldStatus;
	}
	
///////////////////////////////////////////////////	
	
	public int getNewStatus() {
		return newStatus;
	}
	
	public void setNewStatus(int newStatus) {
		this.newStatus = newStatus;
	}
	
///////////////////////////////////////////////////		
	
}
