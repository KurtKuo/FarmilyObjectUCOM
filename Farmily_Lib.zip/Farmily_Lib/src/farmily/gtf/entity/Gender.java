package farmily.gtf.entity;

public enum Gender {
	//private final char i; 編譯錯誤，第一行必須列出列舉值
	GENGER_MEN('M',"男"),GENGER_FEMALE('F',"女"),OTHER_GENGER('O',"其他性");
	
	private final char code; //'M'男生,'F'女生,'O'其他
	private final String zhName;//繁體中文名字
	//final屬性由建構子給予初值
	
//	private Gender() {
//	this.('M',"男");
//	}
	//存取範圍為private建構子 enum
	private Gender(char code, String zhName) {
		this.code = code;
		this.zhName = zhName;
	} 
	/**
	 * @return the code
	 */
	public char getCode() {
		return code;
	}

	/**
	 * @return the zhName
	 */
	public String getZhName() {
		return zhName;
	}

}
