package farmily.gtf.entity;

public enum BloodType {
	O,A,B,AB;

	@Override
	public String toString() {
		// TODO Auto-generated method stub
		return super.toString()+"型";
	}
	
}
