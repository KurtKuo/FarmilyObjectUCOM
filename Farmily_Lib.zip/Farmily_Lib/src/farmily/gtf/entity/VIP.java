package farmily.gtf.entity;

import java.time.LocalDate;

public class VIP extends Customer {
	private int discount = 5;
	
	public VIP() {
		super();
		// TODO Auto-generated constructor stub
	}
	public VIP(String id, String password, String name, char gender, LocalDate birthday, String email) {
		super(id, password, name, gender, birthday, email);
		// TODO Auto-generated constructor stub
	}
	public VIP(String id, String password, String name) {
		super(id, password, name);
		// TODO Auto-generated constructor stub
	}
	public int getDiscount() {
		return discount;
	}
	public void setDiscount(int discount)
	{	
		if(discount>=0 && discount<=90) {
		this.discount  = discount;
		}
		}
	
	public String getDiscountString()
	{	
		int discount = 100-this.discount;
		if(discount%10 !=0) {
		return discount+"折";
		}
		else {
			return discount/10+"折";
		}
	}
	
	
	@Override
	public String toString() {
		return this.getClass().getName()+"\t\n"+super.toString()+"\t\n" +"VIP [discount=" + discount + ", getDiscountString()=" + getDiscountString() +  "]";
	}
	
	
	
}
