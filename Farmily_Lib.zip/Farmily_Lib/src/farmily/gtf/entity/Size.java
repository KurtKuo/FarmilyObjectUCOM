package farmily.gtf.entity;

public class Size {
	private String colorName;
	private String size;
	private int stock;
	private double price;
	private String product_descrption;
	
	
/////////////////////////////////////
	
	public String getColorName() {
		return colorName;
	}
	public void setColorName(String colorName) {
		this.colorName = colorName;
	}
	
/////////////////////////////////////
	
	public String getSize() {
		return size;
	}
	public void setSize(String size) {
		this.size = size;
	}
	
/////////////////////////////////////
	
	public int getStock() {
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	
/////////////////////////////////////
	
	public double getPrice() {
		return price;
	}
	public void setPrice(double price) {
		this.price = price;
	}
	
/////////////////////////////////////
	
	public String getProduct_descrption() {
		return product_descrption;
	}
	public void setProduct_descrption(String product_descrption) {
		this.product_descrption = product_descrption;
	}
	
/////////////////////////////////////	
	
	
	@Override
	public String toString() {
		
		return 
		+'\n'+ "[產品顏色]=" + colorName
		+'\n'+ "[尺寸]=" + size 
		+'\n'+ "[庫存]=" + stock	
		+'\n'+ "[定價]=" + price
		+'\n';	
		
	}

}
