package farmily.gtf.entity;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Collections;
import java.util.HashSet;
import java.util.Set;


public class Order {

	private int id;//PKEY,Auto-Increment,required
	

	private Customer member;//required
	private LocalDate orderDate = LocalDate.now();//required
	private LocalTime orderTime = LocalTime.now();//required

	private PaymentType paymentType;//required
	private String paymentNote;//null,optional
	private double paymentFee;

	private ShippingType shippingType;//required
	private String shippingNote;//null,optional
	private double shippingFee;

	private String recipientName;//required
	private String recipientEmail;//required
	private String recipientPhone;//required
	private String shippingAddress;//required
	
	private double totalAmount;//總計

	private int status; //0-NEW 1-TRANSFERED 2-PAID,......

	private Set<OrderItem> orderItemSet = new HashSet<>();

	
	//Set<OrderItem> orderItemSet's GETTER 
	public Set<OrderItem> getOrderItemSet(){
		return Collections.unmodifiableSet(orderItemSet);
	}	
	//DB端
	//Set<OrderItem> orderItemSet's SETTER: add,for DAO從資料庫請出一筆OrderItem加入Set
	public void add(OrderItem orderItem) {
		orderItemSet.add(orderItem);
	}
	
	//前端
	//Set<OrderItem> orderItemSet's SETTER: add,for Servlet從session找出cart，整個購物車內容加入Set
	public void add(ShoppingCart cart) {
			if(cart!=null && cart.size()>0) {
				for(CartItem cartItem:cart.getCartItemSet()) {
					OrderItem orderItem = new OrderItem();
					//購物車明細存到訂單明細中 依序存入
					orderItem.setProduct(cartItem.getProduct());
					orderItem.setColor(cartItem.getColor());
					orderItem.setSize(cartItem.getSize());
					
					//orderItem.setPrice(cartItem.getProduct().getUnitPrice());
					orderItem.setPrice(cart.getUnitPrice(cartItem));
					orderItem.setQuantity(cart.getQuantity(cartItem));
					
					orderItemSet.add(orderItem);//將購物車清單 加入 訂購明細中
				}
			}
	}
		
//////////////////////////////////////////	
		
	//	orderItemSet's GETTER ,delegate method
	public int size() {
		return orderItemSet.size();
	}

	
//////////////////////////////////////////	
	
	public void setTotalAmount(double totalAmount) {
		this.totalAmount = totalAmount;
	}
	
	
	//	orderItemSet's GETTER ,delegate method
	public double getTotalAmount() {//orderItemSet's GETTER, business methods
		double sum = totalAmount;
		if(!orderItemSet.isEmpty()){			
			for(OrderItem orderItem:orderItemSet) 
				sum += orderItem.getPrice()* orderItem.getQuantity();
		}
		return Math.round(sum);
	}
	
	public double getTotalAmountWithFee() {
		return getTotalAmount()+paymentFee+shippingFee;
	}
	
	
//////////////////////////////////////////
	
	
	public int getTotalQuantity() {
		int sum = 0;
		for(OrderItem orderItem:orderItemSet) {
			sum+=orderItem.getQuantity();
		}
		return sum;		
	}
	
//////////////////////////////////////////
	
	
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

//////////////////////////////////////////	
	
	public Customer getMember() {
		return member;
	}

	public void setMember(Customer member) {
		this.member = member;
	}

//////////////////////////////////////////	
	
	
	public LocalDate getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(LocalDate orderDate) {
		this.orderDate = orderDate;
	}

//////////////////////////////////////////	
	
	
	public LocalTime getOrderTime() {
		return orderTime;
	}

	public void setOrderTime(LocalTime orderTime) {
		this.orderTime = orderTime;
	}

//////////////////////////////////////////
	
	public PaymentType getPaymentType() {
		return paymentType;
	}

	public void setPaymentType(PaymentType paymentType) {
		this.paymentType = paymentType;
	}

//////////////////////////////////////////	
	
	public String getPaymentNote() {
		return paymentNote;
	}

	public void setPaymentNote(String paymentNote) {
		this.paymentNote = paymentNote;
	}

//////////////////////////////////////////	
	
	
	public double getPaymentFee() {
		return paymentFee;
	}

	public void setPaymentFee(double paymentFee) {
		this.paymentFee = paymentFee;
	}

//////////////////////////////////////////	
	
	
	public ShippingType getShippingType() {
		return shippingType;
	}

	public void setShippingType(ShippingType shippingType) {
		this.shippingType = shippingType;
	}

//////////////////////////////////////////	
	
	public String getShippingNote() {
		return shippingNote;
	}

	public void setShippingNote(String shippingNote) {
		this.shippingNote = shippingNote;
	}

//////////////////////////////////////////		
	
	public double getShippingFee() {
		return shippingFee;
	}

	public void setShippingFee(double shippingFee) {
		this.shippingFee = shippingFee;
	}

//////////////////////////////////////////		
	
	public String getRecipientName() {
		return recipientName;
	}

	public void setRecipientName(String recipientName) {
		this.recipientName = recipientName;
	}

//////////////////////////////////////////	
	
	
	public String getRecipientEmail() {
		return recipientEmail;
	}

	public void setRecipientEmail(String recipientEmail) {
		this.recipientEmail = recipientEmail;
	}

//////////////////////////////////////////	
	
	
	public String getRecipientPhone() {
		return recipientPhone;
	}

	public void setRecipientPhone(String recipientPhone) {
		this.recipientPhone = recipientPhone;
	}
	
//////////////////////////////////////////
	
	public String getShippingAddress() {
		return shippingAddress;
	}

	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}
	
//////////////////////////////////////////
	
	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

/////////////////////////////////////////
	
	public String getStatusString() {
		return getStatusString(this.status);
	}
	
	public String getStatusString(int status) {
		return Status.values()[status].description;
	}
	
/////////////////////////////////////////
	
	
	
	@Override
	public String toString() {
		return 
		this.getClass().getName()
		+"\t\n[訂購明細＝訂單]=" + id
		+'\n'+ "[訂購人]=" +(member==null?"無訂購人":member.getName())
		+'\n'+ "[訂購日期]=" + orderDate + "," + orderTime
		+'\n'+ "[付款方式]=" + paymentType 
		+'\n'+ "[付款備註]=" + paymentNote
		+'\n'+ "[手續費]=" + paymentFee
		+'\n'+ "[收件人]=" + recipientName+","+recipientEmail+","+recipientPhone
		+'\n'+ "[貨運地址]=" + shippingAddress
		+'\n'+ "[處理狀態]=" + status
		+'\n'+ "[總金額]=" + getTotalAmount()
		+'\n'+ "[總明細]=" + orderItemSet
		+'\n';	
	}
	
//////////////////////////////////////////
	
	enum Status{
		NEW("新訂單"),TRANSFERED("已轉帳"),
		PAID("已付款"),SHIPPED(("已出貨")),ARRIVED("已到貨"),
		CHECKED("已簽收"),COMPLETE("已完成");
		
		private final String description;

		private Status(String description) {
			this.description = description;
		}

		public String getDescription() {
			return description;
		}		
	}	 
}
//////////////////////////////////////////