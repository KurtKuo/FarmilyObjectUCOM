package farmily.gtf.entity;

import java.time.DateTimeException;
import java.time.LocalDate;
import java.time.Period;
import java.time.format.DateTimeParseException;

import farmily.gtf.exception.GTFDataInvalidException;

public class Customer {
	//private 只能在自己類別使用
		//public 能夠跨類別使用
	
	private String id;//required,PKey,須符合ROC_ID
	private String password;//required,6~20個字元	
	private String name;//required,2~50個字元	 
	private char gender;//required,'M'-男生,'F'-女生,'O'-其他
	private LocalDate birthday;//required,年滿12歲
	private String email;//required,須符合email格式 ,unitIndex
	private String address="";//optional 可自選可不填
	private String phone="";//optional	 
	private boolean subscribed;//optional
	
	
	
/////////////////////////////////////////////////////////////////////////
	//建構子 public
	//利用TestCustomerConstructor
	public Customer(){	}//若有加入 有參數建構子，必須加上此行
	
	public Customer(String id, String password, String name) {
		//super();
		this.setId(id);
		this.setPassWord(password);
		this.setName(name);
	}
	public Customer(String id, String password, String name, char gender, LocalDate birthday, String email) {
		//super();
		//this.setId(id);
		//this.setPassWord(password);
		//this.setName(name);
		this(id,password,name); //和上面執行方法一樣
		
		this.setGender(gender);
		this.setBirthday(birthday);
		this.setEmail(email);
	}

	//////////////////////////////////////////////////////////////////////////
	//ID Check 國民身分證字號
	private static final String idPattern = "[A-Z][1289][0-9]{8}";
	private static final String firstChar = "ABCDEFGHJKLMNPQRSTUVXYWZIO";
	
	public static boolean checkId(String id)
	{
		//身分證號檢查
		//final String idPattern = "[A-Z][1289][0-9]{8}"; 因為記憶體的關係，將兩行改為 static變數
		//final String firstChar = "ABCDEFGHJKLMNPQRSTUVXYWZIO"; 
		int oneNumber = 0;
		
		if(id !=null && id.matches(idPattern))
		{	
			//indexof 是第幾個位置
			//charAt是取那個位置的字元
			oneNumber = (firstChar.indexOf(id.charAt(0))+10);
			//依公式將第一位A123456789 ex:A分為第一位第二位 加上後面九位
			oneNumber = (oneNumber/10)*1 + (oneNumber%10)*9;
			//第一位 *1 第二位*9
			//拆成 A = 1 ' 0 兩位			
			
			//第三位到第十位 
			int n = 0;
			for(int i =1;i<9;i++)
			{
				n  = id.charAt(i)-'0';
				oneNumber += n*(9-i);
			}
			//第十一位
				oneNumber += (id.charAt(9)-'0')*1;
			
				//判斷總和是否%10為0 為ture,否為false
			/*if(oneNumber%10==0)
			{
				return true;
			}
			else {
				return false;
			}*/
			return (oneNumber%10==0);//結束這個程式， oneNumber%10==0 回傳 為 (true)
			
		}
		return false; //若不為 true 就回傳 false
	}
	
	
	// ID 方法
	public void setId(String id)
	{
		if(checkId(id))
		{
			this.id=id; //區域變數名字一樣 用this這個關鍵字
			//System.out.println("身分證正確"+this.id);
		}
		else
		{
			//System.out.println("身分證格式錯誤: "+id);
			throw new GTFDataInvalidException("身分證格式錯誤: "+id);
		}
	}
	
	public String getId() //public>private
	{	
		
		return this.id; //return this.id; 
	}
	
	//////////////////////////////////////////////////////////////////////////
	
	public static final int PWD_MIN_LENGTH = 8;
	public static final int PWD_MAX_LENGTH = 20;
	
	//PassWord 
	public void setPassWord(String pwd) //public>private
	{
		if(pwd !=null && pwd.length()>=PWD_MIN_LENGTH && pwd.length()<=PWD_MAX_LENGTH)
		{
			this.password = pwd; //符合規範才會指派數值
			//System.out.println(pwd);
		}
		else
		{
			//System.err.println("密碼格式不正確"+pwd+"密碼必須"+PWD_MIN_LENGTH
			//		+ "~"+PWD_MAX_LENGTH+"個字元");
			throw new GTFDataInvalidException("密碼格式不正確"+pwd+"密碼必須"+PWD_MIN_LENGTH+ "~"+PWD_MAX_LENGTH+"個字元，謝謝");
			//紅色的
		}
	}
	
	public String getPassWord() //public>private
	{
		return password;
	}
	
	//////////////////////////////////////////////////////////////////////////	

	
	//名字
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}

	/**
	 * @param name the name to set
	 */
	public static final int NAME_MIN_LENGTH = 2;
	public static final int NAME_MAX_LENGTH = 50;
	
	public void setName(String name) { 	
		if(name!=null && name.length()>=NAME_MIN_LENGTH && name.length()<=NAME_MAX_LENGTH) {	//required,2~50個字元
		
			this.name = name;
			//System.out.println(name);
		}else
		{
			//System.out.printf("姓名是不正確的!"+name+" ,必須為%d~%d個字元!",NAME_MIN_LENGTH,NAME_MAX_LENGTH);
			String msg = String.format("姓名是不正確的!"+name+" ,必須為%d~%d個字元，謝謝",NAME_MIN_LENGTH,NAME_MAX_LENGTH);
			throw new GTFDataInvalidException(msg);
		}
		}

	
	//////////////////////////////////////////////////////////////////////////		
	

	//性別
	/**
	 * @return the gender
	 */
	public char getGender() {
		return gender;
	}

	/**
	 * @param gender the gender to set
	 */
	public static final char GENDER_MEN = 'M';
	public static final char GENDER_FEMALE = 'F';
	public static final char OTHER_GENDER = 'O';
	
	public void setGender(char gender) {//required,'M'-男生,'F'-女生	
		if(gender == GENDER_MEN || gender == GENDER_FEMALE || gender == OTHER_GENDER) {
			this.gender = gender;
			//System.out.println(gender);
		}else {
			//System.err.printf("性別是不正確的!"+gender+" ,必須為正確的填入%s就是男生 or %s就是女生或是其他%s!",GENGER_MEN,GENGER_FEMALE,OTHER_GENGER);
			String msg = String.format("性別是不正確的!"+gender+" ,必須為正確的填入%s就是男生 or %s就是女生或是其他%s!",GENDER_MEN,GENDER_FEMALE,OTHER_GENDER);
			throw new GTFDataInvalidException(msg);
		}
		
	}


	//////////////////////////////////////////////////////////////////////////
	
	
	
	//生日
	/**
	 * @return the birthday
	 */
	public LocalDate getBirthday() {
		return birthday;
	}


	/**
	 * @param birthday the birthday to set
	 */
	public static final int AGE_MIN_YEAR = 12;	
	
	public void setBirthday(LocalDate birthday) {//required,年滿12歲
			
		/*if(birthday!=null && getAge()>=12) {
			this.birthday = birthday;
			//this.birthday = birthday;
			System.out.println(birthday);

			
		}else {
			System.out.println("生日是不正確的"+birthday+" ,必須年滿12歲!");
		}*/
			
		
		if(birthday!=null && Period.between(birthday, LocalDate.now()).getYears()>=AGE_MIN_YEAR)
		{
			this.birthday = birthday;
		}
		else{
			//System.out.printf("生日是不正確的:%s,必須年滿%d歲(小於%s))",this.birthday,AGE_MIN_YEAR,LocalDate.now().minusYears(AGE_MIN_YEAR));
			String msg = String.format("生日是不正確的:%s,必須年滿%d歲(小於%s))",birthday,AGE_MIN_YEAR,LocalDate.now().minusYears(AGE_MIN_YEAR));
			throw new GTFDataInvalidException(msg);
		}
		
		
	}
	
	// 此方法 將三個 int 轉為 LocalDate型別 並將值傳給 上面方法做判斷 
	//public void setBirthday(LocalDate birthday) 
	
	public void setBirthday(int y,int m ,int d)
	{
		try {
			this.setBirthday(LocalDate.of(y, m, d));
		}catch(DateTimeException e) {
			throw new GTFDataInvalidException("生日字串格是不正確:"+y+","+m+","+d+";"+"應符合yyyy-mm-dd"+e+"，謝謝");
		}
		//此方法LocalDate.of(1998,5,5); 為3個int
	}
	
	//將一個 String 轉為 轉為 LocalDate型別
	
	public void setBirthday(String dataString)
	{
		if(dataString!=null && dataString.length()>0) {
			try {
				this.setBirthday(LocalDate.parse(dataString));
			}catch(DateTimeParseException e) {
				throw new GTFDataInvalidException("生日字串格是不正確:"+dataString+"應符合yyyy-mm-dd，謝謝");
			}

		}
		//此方法LocalDate.pare("1998-05-05"); 為1個String
		else
		{
			//System.out.println("生日字串格是不正確:"+birthday);
			throw new GTFDataInvalidException("生日一定要填入，謝謝:"+dataString);
		}

}
	
	
	public int getAge() 
	{
		//根據客戶生日計算生日
		int age = -99;
		if(getBirthday()!=null) {
			
			int thisYear = LocalDate.now().getYear();
			int birthdayYear = birthday.getYear();
			age = thisYear-birthdayYear; 
			//Period period = Period.between(getBirthday(), LocalDate.now());
			//age = period.getYears();
			// System.out.println(period.getMonths());
			
		}
		else
		{
			//System.out.println("沒有客戶的生日資料，不能計算!!");
			//throw new GTFDataInvalidException("沒有客戶的生日資料，不能計算!!");
		}
		
		return age;
	}
		

	
	
	
//////////////////////////////////////////////////////////////////////////
	
	

	//email
	/**
	 * @return the email
	 */
	public String getEmail() {

		return email;
	}

	/**
	 * @param email the email to set
	 */
	private static final String EMAIL_Pattern = "^\\w{1,63}@[a-zA-Z0-9]{2,63}\\.[a-zA-Z]{2,63}(\\.[a-zA-Z]{2,63})?$";
	
	
	
	public void setEmail(String email) {
		if(email != null && email.matches(EMAIL_Pattern))
		{
			this.email = email;
		}
		else if(email==null){
			//System.out.println("email是不符合格式的"+email);
			throw new GTFDataInvalidException("email是不符合格式的，謝謝"+email);
		}
	}

//////////////////////////////////////////////////////////////////////////

	

	//地址
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}

	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		if(address!=null)
		{
		this.address = address;
		}
		else {
			this.address = "";
		}
	}


//////////////////////////////////////////////////////////////////////////

	
	
	//電話
	/**
	 * @return the phone
	 */
	public String getPhone() {
		return phone;
	}

	/**
	 * @param phone the phone to set
	 */
	public void setPhone(String phone) {
			this.phone = phone;
	}



//////////////////////////////////////////////////////////////////////////



	//訂閱電子報

	/**
	 * @param subscribed the subscribed to set
	 */
	public void setSubscribed(boolean subscribed) {
		this.subscribed = subscribed;
	}

	//boolean只會有 true &false 不用檢查
	public boolean isSubscribed() {
		// TODO Auto-generated method stub
		return subscribed;
	}
	
//////////////////////////////////////////////////////////////////////////
	
	@Override
	public String toString() {
		return this.getClass().getName()+"\n"+super.toString()+"\n"
				+"[身分證]=" + id +"\n"+ 
				"[密碼]=" + password +"\n"
				+ "[姓名]=" + name +"\n"
				+ "[性別]=" + gender +"\n"
				+ "[生日]="+ birthday +"\n"
				+ "[email]=" + email +"\n"
				+ "[地址]=" + address +"\n"
				+ "[phone]=" + phone +"\n"
				+ "[subscribed]="+ subscribed+"\n";
	}
		/*
		return this.getClass().getName()+"\t\n[產品編號]=" + id 
				+ ", [產品名稱]=" + name 
				+ ", \n[定價]=" + unitPrice 
				+ ", [庫存]=" + stock
				+ ", [說明]=" + description 
				+ "\n[圖片]=" + photoUrl 
				+ ", [上價日期]=" + shelfDate + "]"+"\n";
		
		
		
		
	}*/

	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((id == null) ? 0 : id.hashCode());
		return result;
	}

	@Override
	public boolean equals(Object obj) { //工具使用
		if (this == obj) //記憶體位置
			return true;
		if (!(obj instanceof Customer)) //若非if return ; 若是 繼續執行下一行 
			//注意(obj instanceof Customer) 有小括號先判斷後 再執行<!>
			return false;
		Customer other = (Customer) obj; //轉型
		if (id == null) { 
			//if (other.id != null) ex:A沒帶身分證 B沒有身分證 無法證明是否為同一人，所以為false
				return false;
		} else if (!id.equals(other.id))//若非if return ; 若是 繼續執行下一行
			//this.id 等於 other.id
			//< c變數參考的 物件c 內的屬性id值 = c1變數參考的 物件c1 內的屬性id值>
			//instanceof 若遇到null就回傳 false
			return false;
		return true; //若相等執行回傳true
	}
	
	
	
	
	
//	@Override
//	public boolean equals(Object obj) {
//		// TODO Auto-generated method stub
//		if(this.id==obj) return true;
//		
//		if(obj instanceof Customer)
//		{
//			if(this.id!=null && this.id.equals(((Customer) obj).getId())) {
//				//if(this.id!=null && this.id==((Customer) obj).getId()) 不能夠用等號
//				return true;
//			}
//			else
//			{
//				return false;
//			}		
//		}
//		else
//		{
//			return false;
//		}
//	}
	
	///////////////////////////////////////////////////////
	

}
