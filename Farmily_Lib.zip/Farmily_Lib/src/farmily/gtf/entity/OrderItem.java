package farmily.gtf.entity;


public class OrderItem {

	private Product product; //PKEY

	private Color color;	//PKEY,optional(可能是null)
	
	private String size=""; //PKEY,optional(可能是"")

	private double price; 	//交易價格

	private int quantity; 	//購買數量

	
///////////////////////////////////////

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}
	
///////////////////////////////////////	

	public Color getColor() {
		return color;
	}

	public void setColor(Color color) {
		this.color = color;
	}
	
///////////////////////////////////////
	public String getSize() {
		return size;
	}

	public void setSize(String size) {
		this.size = size;
	}
	
///////////////////////////////////////
	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}
	
///////////////////////////////////////
	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	
///////////////////////////////////////
	
	public double getAmount() {
		return price*quantity;	
	}
///////////////////////////////////////
	
@Override
public String toString() {
return 	this.getClass().getName()
+"\t\n[訂購明細＝產品]=" + (product!=null?product.getId()+","+product.getName():"無產品")
+'\n'+ "[訂購顏色]=" +(color!=null?color.getColorName()+",產品圖片"+color.getPhotoUrl():"沒有顏色選擇")
+'\n'+"[訂購尺寸]=" + size
+'\n'+ "[交易價]=" + price 
+'\n'+ "[訂購數量]=" + quantity
+'\n'+ "[小計]=" + getAmount()
+'\n';
}

///////////////////////////////////////

@Override
public int hashCode() {
	final int prime = 31;
	int result = 1;
	result = prime * result + ((product == null) ? 0 : product.hashCode());
	result = prime * result + ((color == null) ? 0 : color.hashCode());
	result = prime * result + ((size == null) ? 0 : size.hashCode());
	return result;
}

@Override
public boolean equals(Object obj) {
	if (this == obj)
		return true;
	if (obj == null)
		return false;
	if (getClass() != obj.getClass())
		return false;
	OrderItem other = (OrderItem) obj;
	if (color == null) {
		if (other.color != null)
			return false;
	} else if (!color.equals(other.color))
		return false;
	if (product == null) {
		if (other.product != null)
			return false;
	} else if (!product.equals(other.product))
		return false;
	if (size == null) {
		if (other.size != null)
			return false;
	} else if (!size.equals(other.size))
		return false;
	return true;
}

///////////////////////////////////////

	
}
