package farmily.gtf.entity;

public class Outlet extends Product{
	
	private int discount;
	
	public int getDiscount()
	{
		return discount;
	}
	
	public void setDiscount(int discount)
	{
		this.discount = discount;
	}
	
	public String getDiscountString()
	{
		int discount = 100-this.discount;
		
		if(discount%10!=0)
		{
			return discount+"折"; //ex.79折
		}
		else
		{
			return discount/10 + "折";//ex.7折
		}
		
	}
	@Override
	//先將父類別屬性unitPrice 由private > protected
	//Override 存取範圍 必須子類別大於父類別
	//子類別利用這個override方法可以改寫父類別方法
	//若父類別 加入修飾字 final 就不能夠覆寫它
	public double getUnitPrice() //查詢售價
	{	
		//protected改回private 
		//要加入super ()父類別的
		return super.getUnitPrice() * (100-discount)/100;
	}
	//取屬性值 定價
	public double getListPrice()
	{
		return super.getUnitPrice();
	}
	
////////////////////////////////////////////
	
	@Override
	public String toString() {
		return super.toString()+ "[折扣]=" + getDiscountString() +"\n"+ "[售價]=" + getUnitPrice()+"元"+"\n";
	}
	
}
