package farmily.gtf.entity;


import java.util.ArrayList;
import java.util.Collections;
import java.util.List;



public class Color {
	private String colorName; //PKEY ,Required
	private String photoUrl;
	private int stock;
	private String iconUrl;
	private List<Size> sizeList = new ArrayList<>();
	
	
//////////////////////////////////////////////	
	
	
	public void addSize(Size size) {
		sizeList.add(size);
	}	
	

//////////////////////////////////////////////	
	
	public List<Size> getSizeList() {
		return Collections.unmodifiableList(sizeList);
	}
	
	

	public void add(Size size) {
		sizeList.add(size);
	}

//////////////////////////////////////////////
	
	public String getColorName() {
		return colorName;
	}
	public void setColorName(String colorName) {
		this.colorName = colorName;
	}
	
//////////////////////////////////////////////	
	
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	
//////////////////////////////////////////////
	
	public int getStock() {
		if(sizeList!=null && sizeList.size()>0) {
			int stock = 0;
			for(Size size:sizeList) {
				stock += size.getStock();
			}
			return stock;
		}
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	
//////////////////////////////////////////////	
	
	public String getIconUrl() {
		return iconUrl;
	}
	public void setIconUrl(String iconUrl) {
		this.iconUrl = iconUrl;
	}
	
//////////////////////////////////////////////	
	

	@Override
	public String toString() {
		
		return 
		+'\n'+ "[產品顏色]=" + colorName
		+'\n'+ "[圖片]=" + photoUrl 
		+'\n'+ "[庫存]=" + stock	
		+'\n'+ "[產品圖示]=" + iconUrl
		+'\n'+ "[尺寸]=" + (sizeList.size()>0?"有size-"+sizeList:"")
		+'\n';	
	}
	
//////////////////////////////////////////////	
	
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((colorName == null) ? 0 : colorName.hashCode());
		return result;
	}
	
//////////////////////////////////////////////	
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Color other = (Color) obj;
		if (colorName == null) {
			if (other.colorName != null)
				return false;
		} else if (!colorName.equals(other.colorName))
			return false;
		return true;
	}
	
}
