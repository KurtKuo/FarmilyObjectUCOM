package farmily.gtf.entity;

import java.text.NumberFormat;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Product {
	//四捨五入
	public static final NumberFormat PRICE_FORMAT;
	static {
		NumberFormat pFormat = NumberFormat.getInstance();
		pFormat.setMinimumFractionDigits(2);
		pFormat.setMaximumFractionDigits(2);
		PRICE_FORMAT = pFormat;
	}

	private int id; //required ,PKey , auto-increment
	private String name; //required ,unique index ,1~50
	private double unitPrice;//required 定價 因為當初沒有折扣所以定價即為售價
	private int stock;//required
	private String description = "";//optional
	private String photoUrl;//optional
	private LocalDate shelfDate;//optional
	private String category;//分類
	private String products_type; //產品別
	private boolean gift_Box;//禮品
	private String origin;
	private String newProducts;
	
	private List<Color> colorList = new ArrayList<>();
	
////////////////////////////////////////////	
	//將價格四捨五入
	public static String getFormettedPrice(double price) {
		return PRICE_FORMAT.format(price);
	}

////////////////////////////////////////////
	
//陣列不可以用 setter 不然會整批換色
public List<Color> getColorList() {
//將陣列包裝，只能看不能改 
//當遇到集合 作法1:回傳內容不可更改之集合
return Collections.unmodifiableList(colorList); //謄本概念
}
//list 屬性的 setter :務必拆開成add,update,remove(這裡只提供add)

public void addColor(Color color) {
colorList.add(color);
}

////////////////////////////////////////////	
	
	//建構子的方法 務必要建立無參數建構子
	public Product() {
		
	}
	public Product(int id, String name, double Price) {
		
		this.id = id;
		this.name = name;
		this.unitPrice = Price;
	}
	
	public Product(int id, String name, double unitPrice, int stock) {
		
//		this.id = id;
//		this.name = name;
//		this.unitPrice = unitPrice;
		this(id,name,unitPrice);
		this.stock = stock;
		
	}
////////////////////////////////////////////
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	
////////////////////////////////////////////
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
////////////////////////////////////////////
	public  double getUnitPrice() { //查詢售價(定價)
		return unitPrice;
	}
	public void setUnitPrice(double unitPrice) { //指派售價 (定價)
		this.unitPrice = unitPrice;
	}
	
////////////////////////////////////////////
	public int getStock() {
		int stock = 0;
		if(colorList.size()>0) {
			for(Color color :colorList) {
				stock += color.getStock();
			}
		}else {
			stock = this.stock;
		}
		return stock;
	}
	public void setStock(int stock) {
		this.stock = stock;
	}
	
////////////////////////////////////////////
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	
////////////////////////////////////////////
	public String getPhotoUrl() {
		return photoUrl;
	}
	public void setPhotoUrl(String photoUrl) {
		this.photoUrl = photoUrl;
	}
	
////////////////////////////////////////////
	public LocalDate getShelfDate() {
		return shelfDate;
	}
	public void setShelfDate(LocalDate shelfDate) {
		this.shelfDate = shelfDate;
	}
	
	//由字串String轉為 LocalDate 轉型別
	public void setShelfDate(String shelfDateString) {
		if(shelfDateString!=null && shelfDateString.length()==10)
		{	
			shelfDateString = shelfDateString.replace("/", "-");
			this.setShelfDate(LocalDate.parse(shelfDateString));
		}
		else
		{
			System.out.println("時間格式不對: "+shelfDateString);
			}
		
	}
////////////////////////////////////////////
	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

////////////////////////////////////////////
	
	public String getProducts_type() {
		return products_type;
	}
	public void setProducts_type(String product_type) {
		this.products_type = product_type;
	}

////////////////////////////////////////////
	
	public void setGiftBox(boolean gift_Box) {
		this.gift_Box = gift_Box;
	}

	//boolean只會有 true &false 不用檢查
	public boolean isGiftBox() {

		return gift_Box;
	}
	
////////////////////////////////////////////
	//產地
	public String getOrigin() {
		return origin;
	}
	
	public void setOrigin(String origin) {
		this.origin = origin;
	}	
////////////////////////////////////////////	
	//最新商品
public String getNewProducts() {
		return newProducts;
	}
	public void setNewProducts(String newProducts) {
		this.newProducts = newProducts;
	}
	

	@Override
	/*public String toString() {
		// TODO Auto-generated method stub
		return id+":"+name+" 價格:"+ unitPrice + " 庫存:" +stock;
	}*/
	public String toString() {
		//this.getClass().getName() 抓現在這個類別
		//this.getClass().getSimpleName()
		return this.getClass().getName()
				+"\t\n[產品代號]=" + id 
				+'\n'+ "[產品名稱]=" + name
				+'\n'+"[季節分類]=" + category
				+'\n'+ "[定價]=" + unitPrice 
				+'\n'+ "[庫存]=" + stock
				+'\n'+ "[說明]=" + description 
				+'\n'+ "[圖片]=" + photoUrl 
				+'\n'+ "[上價日期]=" + shelfDate
				+'\n'+ "[產品別]=" + products_type
				+'\n'+ "[顏色清單]="+ colorList
				+'\n';
		}

//////////////////////////////////////////////
	
	@Override
	public int hashCode() {//工具產生的
		final int prime = 31;
		int result = 1;
		result = prime * result + id;
		return result;
	}
	
//////////////////////////////////////////////
	
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
//		if (!(obj instanceof Product))
//			return false;
		if(this.getClass() != obj.getClass()) //判斷是否為同一個類別 後轉型
			return false;
		Product other = (Product) obj;
		if (id != other.id) {
			return false;
		}
		return true;
	}
	
	
	
	

}
