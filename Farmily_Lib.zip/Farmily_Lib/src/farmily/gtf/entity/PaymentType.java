package farmily.gtf.entity;

public enum PaymentType {
	SHOP("園區付款"),ATM("ATM轉帳"),HOME("貨到付款",50),STORE("超商付款"),CARD("信用卡");//,LINEPAY("LINE PAY");
	
	private final String description;//blank final variable
	private double fee;
//	private PaymentType() {
//		無參數建構子 SHOP("String",int) or SHOP("String") or SHOP()無參數建構子
//	}
	private PaymentType(String description) {
		this(description,0);
	}
	
	private PaymentType(String description,double fee) {
		
		this.description = description;
		this.fee = fee;
	}
	
/////////////////////////////////////////////////	
	
	public double getFee() {
		return fee;
	}
	public void setFee(double fee) {
		this.fee = fee;
	}
	
/////////////////////////////////////////////////
	
	public String getDescription() {
		return description;
	}
/////////////////////////////////////////////////	

	@Override
	public String toString() {
		
		return description + 
				(fee==0?"":("," + fee + "元"));		
	}
	
}