-- MySQL dump 10.13  Distrib 8.0.24, for macos11 (x86_64)
--
-- Host: localhost    Database: gtf
-- ------------------------------------------------------
-- Server version	8.0.24

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `products`
--

DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `products` (
  `id` int unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `unit_price` double NOT NULL,
  `stock` int NOT NULL DEFAULT '0',
  `description` varchar(100) NOT NULL DEFAULT '',
  `photo_url` varchar(250) DEFAULT NULL,
  `shelf_date` date NOT NULL DEFAULT (curdate()),
  `category` varchar(20) NOT NULL,
  `discount` int NOT NULL DEFAULT '0',
  `products_type` varchar(15) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name_UNIQUE` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `products`
--

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'三峽上等龍井茶',6299,0,'產地：新北三峽 \n重量：600 g \n有效效日期：2 年','https://i.ibb.co/NWrP8by/greentea.png','2021-06-10','Four-seasons',21,'Collections'),(2,'信義鄉佳釀梅酒',6299,15,'產地：南投信義鄉\n容量：720 ml\n有效日期：無期限','https://i.ibb.co/r48qrVK/wine.png','2021-01-10','Four-seasons',21,'Collections'),(3,'花蓮蝶豆花茶',2999,21,'產地：花蓮瑞穗\n重量：600 g\n有效日期：3 年','https://i.ibb.co/b306Bxr/beantea.png','2021-05-10','Summer',21,'Collections'),(4,'南投魚池紅玉',3599,30,'產地：南投魚池鄉\n重量：600 g\n有效日期：2 年','https://i.ibb.co/pKB6BJN/blacktea.png','2021-04-10','Four-seasons',21,'Collections'),(5,'鹿谷凍頂烏龍茶',3599,25,'產地：南投鹿谷鄉\n重量：600 g\n有效日期：2 年','https://i.ibb.co/zrQ4gpx/oolong-Tea.png','2021-03-10','Four-seasons',21,'Collections'),(6,'松柏嶺抹茶粉',1499,55,'產地：南投名間鄉\n重量：600 g\n有效日期：1 年','https://i.ibb.co/WB60C44/matchatea.png','2021-05-10','Four-seasons',21,'Collections'),(7,'美麗田草莓果醬',1099,16,'產地：台北內湖\n容量：500 ml\n有效日期：1 年','https://i.ibb.co/d2DytVr/jam.png','2021-06-20','Winter',21,'Collections'),(8,'嘉義特級辣椒醬',1099,24,'產地：嘉義縣\n容量：500 ml\n有效日期：4 年','https://i.ibb.co/nC5tpWx/chilisauce.png','2021-03-20','Four-seasons',21,'Collections'),(9,'大岡山頂級龍眼蜜',4399,120,'產地：高雄大岡山\n容量：1200 ml\n有效日期：無期限','https://i.ibb.co/YbX0B89/honey.png','2021-03-20','Four-seasons',21,'Collections'),(10,'六龜純胡椒粒',1799,29,'產地：高雄六龜區\n重量：600 g\n有效日期：3 年','https://i.ibb.co/KKPJVZT/pepper.png','2021-05-20','Four-seasons',21,'Collections'),(11,'台東紅薑黃粉',1599,59,'產地：台東知本\n重量：600 g\n有效日期：3 年','https://i.ibb.co/0GVsDVn/turmeric.png','2021-02-20','Four-seasons',21,'Collections'),(12,'南投優等孜然粉',1359,29,'產地：南投尖石鄉\n重量：600 g\n有效日期：3 年','https://i.ibb.co/6WwWmw0/cumin.png','2021-04-20','Four-seasons',21,'Collections'),(13,'緋寒櫻',1199,210,'花季：春季\n1 月 至 4 月\n花色：緋紅','https://i.ibb.co/30TVZn1/january-cherry.png','2021-04-20','Winter',21,'Saplings'),(14,'福爾摩沙',2899,240,'花季：春季\n1 月下旬\n花色：白色','https://i.ibb.co/SQtrkR3/january-formosa.png','2021-04-20','Winter',21,'Saplings'),(15,'富士櫻',2399,251,'花季：春季\n2 月 下旬\n花色：粉白','https://i.ibb.co/JknRn2X/february-fuji.png','2021-04-20','Winter',21,'Saplings'),(16,'大漁櫻',3199,215,'花季：春季\n2 月 至 3 月\n花色：粉白','https://i.ibb.co/1nLPwf1/february-catch.png','2021-04-20','Spring',21,'Saplings'),(17,'樁寒櫻',6399,165,'花季：春季\n2 月 至 3 月\n花色：淡粉白','https://i.ibb.co/1KjJCkM/february-perfume.png','2021-04-20','Spring',21,'Saplings'),(18,'墨染櫻',3199,315,'花季：春季\n2 月 至 3 月\n花色：粉色及白色','https://i.ibb.co/2dfMYw3/february-sumizome.png','2021-04-20','Spring',21,'Saplings'),(19,'重辦八重櫻',2699,187,'花季：春季\n2 月 至 3 月\n花色：緋紅','https://i.ibb.co/2syCJYS/february-yae.png','2021-04-20','Spring',21,'Saplings'),(20,'河津櫻',1899,217,'花季：春季\n2 月 至 3 月\n花色：粉紅','https://i.ibb.co/9HghN51/march-hejin.png','2021-04-20','Spring',21,'Saplings'),(21,'霧社櫻',2499,257,'花季：春季\n2 月 至 3 月\n花色：白色','https://i.ibb.co/8YrwpWm/march-wusheh.png','2021-04-20','Spring',21,'Saplings'),(22,'紅粉佳人',2999,197,'花季：春季\n3 月 上旬\n花色：粉紅','https://i.ibb.co/Lvv355r/february-pinkgirl.png','2021-04-20','Spring',21,'Saplings'),(23,'千島櫻',4199,241,'花季：春季\n3 月 中旬\n花色：淡粉紅','https://i.ibb.co/dfWS2K9/february-thousand-Islands.png','2021-04-20','Spring',21,'Saplings'),(24,'染井吉野櫻',3799,314,'花季：春季\n3 月 至 4 月\n花色：粉色、白色','https://i.ibb.co/s67nkDL/marchto-Aprilcerasus.png','2021-04-20','Spring',21,'Saplings'),(25,'季節秋葵',199,210,'產地：台灣台南\n容量：600 g\n有效日期：3 天','https://i.ibb.co/Dph6kf0/fall-okra.png','2021-06-08','Fall',21,'Vegetables'),(26,'有機辣椒',99,18,'產地：台灣嘉義\n容量：600 g\n有效日期：3 天','https://i.ibb.co/n1MB1kZ/spring-chili.png','2021-06-08','Four-seasons',21,'Vegetables'),(27,'特級白韭菜',59,179,'產地：台灣南投\n容量：600 g\n有效日期：3 天','https://i.ibb.co/ssy1bQH/spring-chives.png','2021-06-08','Four-seasons',21,'Vegetables'),(28,'健康洋蔥',69,410,'產地：台灣宜蘭\n容量：600 g\n有效日期：3 天','https://i.ibb.co/3SXsjLn/spring-onion.png','2021-06-18','Four-seasons',21,'Vegetables'),(29,'天然玉米',109,359,'產地：台灣花蓮\n容量：600 g\n有效日期：3 天','https://i.ibb.co/rsQddJp/summer-corn.png','2021-06-04','Summer',21,'Vegetables'),(30,'有機菠菜',99,424,'產地：台灣桃園\n容量：600 g\n有效日期：3 天','https://i.ibb.co/zGNSQYZ/spring-spinach.png','2021-06-18','Fall',21,'Vegetables'),(31,'香甜黃瓜',199,267,'產地：台灣宜蘭\n容量：600 g\n有效日期：3 天','https://i.ibb.co/88rQ738/summer-cucumber.png','2021-06-21','Summer',21,'Vegetables'),(32,'季節南瓜',299,513,'產地：台灣花蓮\n容量：600 g\n有效日期：3 天','https://i.ibb.co/cJKgzWK/summer-pumpkin.png','2021-06-25','Summer',21,'Vegetables'),(33,'有機大番茄',129,411,'產地：台灣宜蘭\n容量：600 g\n有效日期：3 天','https://i.ibb.co/swL03wV/summer-tomato.png','2021-06-28','Fall',21,'Vegetables'),(34,'高山高麗菜',199,376,'產地：台灣南投\n容量：600 g\n有效日期：3 天','https://i.ibb.co/gWL6n65/winter-cabbage.png','2021-06-26','Winter',21,'Vegetables'),(35,'台灣大白菜',109,443,'產地：台灣南投\n容量：600 g\n有效日期：3 天','https://i.ibb.co/YDJKR0h/winter-chinesecabbage.png','2021-06-22','Spring',21,'Vegetables'),(36,'季節芥蘭',59,322,'產地：台灣宜蘭\n容量：600 g\n有效日期：3 天','https://i.ibb.co/fkPQ67c/winter-kale.png','2021-06-21','Spring',21,'Vegetables'),(37,'特級香蕉',109,511,'產地：台灣高雄\n容量：600 g\n有效日期：3 天','https://i.ibb.co/DkS9t1f/spring-banana.png','2021-06-08','Four-seasons',21,'Fruit'),(38,'季節芭樂',199,611,'產地：台灣高雄\n容量：600 g\n有效日期：5 天','https://i.ibb.co/92zrM37/spring-guava.png','2021-06-08','Four-seasons',21,'Fruit'),(39,'嚴選木瓜',209,524,'產地：台灣雲林\n容量：600 g\n有效日期：2 天','https://i.ibb.co/6tVVkYV/spring-papaya.png','2021-06-08','Four-seasons',21,'Fruit'),(40,'上等火龍果',219,524,'產地：台灣彰化\n容量：600 g\n有效日期：2 天','https://i.ibb.co/nQS7j0M/summer-dragonfruit.png','2021-06-08','Summer',21,'Fruit'),(41,'經典芒果',399,614,'產地：台灣台南\n容量：600 g\n有效日期：2 天','https://i.ibb.co/wNT4Dt0/summer-mango.png','2021-06-08','Summer',21,'Fruit'),(42,'金頂鳳梨',299,514,'產地：台灣屏東\n容量：600 g\n有效日期：2 天','https://i.ibb.co/6sc4vbD/summer-pineapple.png','2021-06-08','Summer',21,'Fruit'),(43,'有機紅肉李',299,714,'產地：台灣南投\n容量：600 g\n有效日期：3 天','https://i.ibb.co/Nykk3SP/summer-redplum.png','2021-06-08','Summer',21,'Fruit'),(44,'優等西瓜',199,0,'產地：台灣台東\n容量：600 g\n有效日期：2 天','https://i.ibb.co/yfC5sXX/summer-watermelon.png','2021-06-08','Summer',21,'Fruit'),(45,'好運椪柑',199,514,'產地：台灣宜蘭\n容量：600 g\n有效日期：2 天','https://i.ibb.co/F4w6N83/winter-ponkan.png','2021-06-08','Winter',21,'Fruit'),(46,'嚴選草莓',699,894,'產地：台灣苗栗\n容量：600 g\n有效日期：2 天','https://i.ibb.co/PQBKhCr/winter-strawberry.png','2021-06-08','Winter',21,'Fruit'),(47,'經典百香果',399,394,'產地：台灣台東\n容量：600 g\n有效日期：2 天','https://i.ibb.co/P53Nrxc/fall-passionfruit.png','2021-06-08','Fall',21,'Fruit'),(48,'石坎軟柿',399,394,'產地：台灣內湖\n容量：600 g\n有效日期：2 天','https://i.ibb.co/smc6Dnz/fall-Softpersimmon.png','2021-06-08','Fall',21,'Fruit');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-06-23 19:19:55
